"""Independent direct-library/serialized-table checks; no resampling rerun."""
from pathlib import Path
import argparse
import hashlib,io,json,zipfile
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score,roc_auc_score

B=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--results-dir',type=Path,default=B/'temporal_results_v1');args=parser.parse_args();O=args.results_dir
checks={};errors=[]
archive=B.parents[1]/'upload/RETURN_GC_BRB_TEMPORAL_AUDIT_20261029_165811_18b5932d.zip'
with zipfile.ZipFile(archive) as z:
    manifest=json.loads(z.read('file_manifest.json'))
    checks['all80_return_manifest_hashes']=all(len(z.read(x['path']))==x['bytes'] and hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256'] for x in manifest)
    checks['return_zip_crc']=z.testzip() is None
original=pd.read_csv(B/'frozen_inputs/frozen13603_before_temporal_filter.csv')
d=pd.read_csv(O/'primary13466_frozen_scores_and_labels.csv');excluded=pd.read_csv(O/'excluded137_previously_catalogued_groups.csv')
p=json.loads((O/'locked_protocol.json').read_text());summary=json.loads((O/'temporal_summary.json').read_text())
checks['original_prediction_table_signature']=hashlib.sha256((B/'frozen_inputs/frozen13603_before_temporal_filter.csv').read_bytes()).hexdigest()==p['SourceTableSHA256']
checks['protocol_signature']=summary['ProtocolSHA256']==hashlib.sha256((O/'locked_protocol.json').read_bytes()).hexdigest()
checks['13466_plus137_partition_old13603']=len(d)==13466 and len(excluded)==137 and not set(d.GroupID)&set(excluded.GroupID) and set(d.GroupID)|set(excluded.GroupID)==set(original.GroupID)
checks['unchanged65_positive_groups']=set(d.loc[d.LaterCatalogMembership,'GroupID'])==set(original.loc[original.IntOGenNewMembership.eq(1),'GroupID'])
metrics=pd.read_csv(O/'temporal_metrics.csv').set_index('Model');boots=pd.read_csv(O/'paired_group_bootstrap5000.csv')
top=pd.read_csv(O/'planned_topK_catalog_enrichment.csv');ranks=pd.read_csv(O/'positive65_ranks_all_models.csv')
y=d.LaterCatalogMembership.to_numpy(int)
scores_ok=points_ok=cis_ok=rank_ok=True
for name,col in p['ModelColumns'].items():
    old=original.set_index('GroupID').loc[d.GroupID,col].to_numpy();current=d[col].to_numpy()
    err=float(np.max(np.abs(old-current)));errors.append(err);scores_ok&=err<1e-15
    direct=[average_precision_score(y,current),roc_auc_score(y,current)]
    for j,key in enumerate(['AP','AUROC']):
        points_ok&=abs(direct[j]-metrics.loc[name,key])<1e-14
        q=np.quantile(boots[name+'_'+key],[.025,.975])
        cis_ok&=abs(q[0]-metrics.loc[name,key+'_CI95_Lower'])<1e-14 and abs(q[1]-metrics.loc[name,key+'_CI95_Upper'])<1e-14
    ordering=sorted(range(len(d)),key=lambda i:(-current[i],int(d.GroupID.iloc[i])))
    for k in [100,500]:
        actual=int(y[ordering[:k]].sum());row=top.loc[top.Model.eq(name)&top.K.eq(k)].iloc[0]
        rank_ok&=actual==int(row.Hits) and abs(row.Enrichment-actual/(k*y.mean()))<1e-12
    rmap={int(d.GroupID.iloc[i]):r+1 for r,i in enumerate(ordering)}
    rank_ok&=all(rmap[int(g)]==int(v) for g,v in zip(ranks.GroupID,ranks[name+'_Rank']))
checks.update(all8_score_columns_unchanged=bool(scores_ok),all16_point_metrics_direct_sklearn=bool(points_ok),all16_intervals_from_saved_draws=bool(cis_ok),all16_topK_and65_gene_ranks=bool(rank_ok))
delta=boots.GC_BRB_AP-boots.XGBOOST_37D_AP;diff=pd.read_csv(O/'planned_paired_delta_AP.csv').iloc[0]
checks['paired_delta_interval_and_zero_inclusion']=abs(diff.DeltaAP-(metrics.loc['GC_BRB','AP']-metrics.loc['XGBOOST_37D','AP']))<1e-14 and np.allclose(np.quantile(delta,[.025,.975]),[diff.CI95_Lower,diff.CI95_Upper],atol=1e-14,rtol=0) and diff.CI95_Lower<0<diff.CI95_Upper
main=top.loc[top.Role.eq('Main')];vals=main.HypergeomUpperP.to_numpy();order=np.argsort(vals)
q=np.minimum.accumulate((vals[order]*len(vals)/np.arange(1,len(vals)+1))[::-1])[::-1];back=np.empty(len(vals));back[order]=np.minimum(1,q)
checks['four_main_enrichment_BH_independent']=np.allclose(back,main.BH_q_4,atol=1e-14,rtol=0)
checks['original_Tier1_still288']=original.Tier1.sum()==288 and summary['ExistingTier1Unchanged']==288
checks['no_fitting_in_this_experiment']=summary['NewModelTraining'] is False
checks['future_catalog_complement_named_correctly']='not biological' in summary['Interpretation']
checks={k:bool(v) for k,v in checks.items()}
result=dict(Passed=all(checks.values()),Checks=checks,MaxCopiedScoreError=max(errors),
            Scope='Independent checks of received files and newly calculated temporal outputs; historical dates supported by archived publication provenance, not newly authenticated by these numerical checks')
(O/'independent_checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert result['Passed']
