# GC-BRB 时间外评价：归档和复核

本包保存结果、固定输入、代码和来源证据。本轮不训练模型，不修改主研究的30次拟合、29个高精度阈值或288项Tier-1。

先阅读同目录的中文报告。`temporal_results_v1`包含正式输出；`source_checks`和`raw_replay_checks`是来源与数值重放证据。主指标AP为后续目录收录的排序指标，不是独立未来患者预测准确率。

压缩包保留原工作目录的相对结构。所有操作应在新解压的工作副本内进行，原项目不需覆盖或移动。

## 只复核现有结果

进入 `reproduce_root/strict_temporal_20261029/phase2_return_165811` 后，运行：

```text
python verify_temporal_results.py
```

该命令读取已保存的5000次bootstrap，不再次重抽样或拟合。检查结果另写为核对JSON。

## 在新目录复现统计

以下命令仅在需要复现时使用；本轮已计算完成，不需用户再运行：

```text
python prepare_temporal_universe.py --output NEW_TEMPORAL_REPRO
python evaluate_temporal.py --results-dir NEW_TEMPORAL_REPRO
python verify_temporal_results.py --results-dir NEW_TEMPORAL_REPRO
python plot_temporal.py --results-dir NEW_TEMPORAL_REPRO
```

第一步拒绝已有输出目录；第二步拒绝覆盖已有指标表。固定随机种子及既有评分不变。这是同一实验的计算复现，不是新增独立重复试验。

需要：numpy、pandas、scipy（含false_discovery_control）、scikit-learn；画图另需matplotlib；原始H5来源核对另需h5py。本轮运行环境见 `temporal_results_v1/environment.json`。图的SVG指定Times New Roman，字体文件未嵌入。

## 原始来源核对

`official_emogi`中的六份压缩包为作者下载入口原字节副本；`historical_dates`和前一阶段的证据目录保留2021发布材料与获取记录。解压后的六个H5约11.26GB，本包不重复保存这些解压件。

`verify_historical_sources.py`在新工作副本中可从官方压缩包生成参考H5、66项哈希检查、稀疏网络及历史全局输入缓存。该脚本会向工作副本的 `source_checks` 写入结果，应保留已交付证据的原件再另建副本复核。它不访问或改写用户D盘原始项目。

若还要重放三份CPDB模型，需要用户此前已有的 `01_CPDB_MODELS_part01.zip`，将其复制到工作副本的 `recovered_models` 子目录。该70MB模型文件不在本包重复归档，其原件属于此前12份模型包之一。然后运行 `replay_raw_inputs.py`。脚本使用本包保存的原始数学模块，无重新优化。

模型重放覆盖CPDB run01–03中不属于拟合集合的身份组；本轮没有声称重新从H5重放其余27份模型。共同输入、标签、身份和评分血缘的检查见报告。

## 重要文件

- `locked_protocol.json`：在新指标计算前固定的本轮定义；后续目录此前已经看过，不是前瞻性预注册。
- `primary13466_frozen_scores_and_labels.csv`：正式背景。
- `excluded137_previously_catalogued_groups.csv`：历史目录已收录的排除项。
- `temporal_metrics.csv`：8个模型/分支的AP、AUROC及区间。
- `planned_paired_delta_AP.csv`：GC-BRB减去XGBoost的配对AP差。
- `planned_topK_catalog_enrichment.csv`：预定K=100、500；仅4项主要富集检验作BH校正。
- `positive65_ranks_all_models.csv`：全部65项后续收录基因的排名。
- `positive65_catalog_cohort_provenance.csv`：后续目录队列来源。
- `figures/Temporal_catalog_validation.svg`：英文、可编辑矢量文本、Times New Roman声明；未测试原生Visio。

`FILE_MANIFEST.json`记录归档内容SHA256。原始H5大矩阵、内部PNG预览、临时依赖和绘图缓存均未装入本包。
