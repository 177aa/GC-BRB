"""Verify the returned audit against author H5 archives; no model fitting."""
from pathlib import Path
import concurrent.futures
import hashlib
import importlib.util
import json
import re
import shutil
import tarfile

import h5py
import numpy as np
import pandas as pd
from scipy import sparse

B = Path(__file__).resolve().parent
O = B / 'source_checks'
O.mkdir(exist_ok=True)
P = B.parent / 'package/collect_temporal_inputs.py'
spec = importlib.util.spec_from_file_location('source_audit_v1', P)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
NAMES = dict(CPDB='CPDB', MULTINET='Multinet', PCNET='PCNet', STRINGdb='STRINGdb', IREF='IRefIndex', IREF_2015='IRefIndex_2015')
received = json.loads((B/'input/completion.json').read_text())


def extract(target):
    name = NAMES[target]
    archive = B/'official_emogi'/f'EMOGI_model_{name}.tar.gz'
    destination = B/'reference_h5'/f'{target}_multiomics.h5'
    destination.parent.mkdir(exist_ok=True)
    with tarfile.open(archive, 'r:gz') as t:
        matches = [x for x in t.getmembers() if x.isfile() and x.name.endswith('/'+destination.name)]
        assert len(matches) == 1
        info = matches[0]
        if not destination.exists():
            with t.extractfile(info) as src, destination.open('xb') as dst:
                shutil.copyfileobj(src, dst, 8*1024*1024)
    assert destination.stat().st_size == info.size
    print('extracted', target, info.size, flush=True)
    return dict(target=target, member=info.name, bytes=info.size, tar_mtime=info.mtime)


def txt(x):
    if isinstance(x, bytes):
        x=x.decode('utf-8')
    return str(x).replace('\x00','').strip()


if __name__ == '__main__':
    extracted = list(concurrent.futures.ThreadPoolExecutor(max_workers=2).map(extract,NAMES))
    m.save_json(O/'reference_extraction.json',extracted)
    checks=[]
    union={}
    tuples=[]
    layers={}
    canonical=[f'{o}: {c}' for o in ['MF','METH','GE','CNA'] for c in ['UCEC','BLCA','THCA','KIRC','READ','LUAD','ESCA','LUSC','BRCA','COAD','HNSC','KIRP','PRAD','LIHC','STAD','CESC']]
    for target in NAMES:
        prior=next(x for x in received['h5_files'] if x['path'].endswith('\\'+target+'_multiomics.h5'))
        with h5py.File(B/'reference_h5'/f'{target}_multiomics.h5','r') as f:
            for ds in prior['datasets']:
                name=ds['name']
                digest=m.dataset_digest(f[name],np,target if name=='network' else None)
                row=dict(Target=target,Dataset=name,ExpectedSHA256=ds['canonical_sha256_v1'],ReferenceSHA256=digest,Match=ds['canonical_sha256_v1']==digest,ShapeMatch=list(f[name].shape)==ds['shape'])
                checks.append(row)
                assert row['Match'] and row['ShapeMatch'],row
            genes=[(txt(a),txt(b)) for a,b in f['gene_names'][()]]
            g=[]
            for key in genes:
                if key not in union:
                    union[key]=len(tuples);tuples.append(key)
                g.append(union[key])
            g=np.array(g,int)
            names=[txt(v) for v in f['feature_names'][()]]
            X=np.clip(f['features'][()][:,[names.index(v) for v in canonical]],0,1)
            y=np.full(len(g),np.nan)
            masks=[]
            for split in ['train','val','test']:
                mask=f['mask_'+split][()].astype(bool).ravel()
                assert not any(np.any(mask&old) for old in masks)
                masks.append(mask)
                y[mask]=f['y_'+split][()].ravel()[mask]
            chunks=[]
            for start in range(0,len(g),256):
                chunks.append(sparse.csr_matrix(f['network'][start:start+256]!=0))
            A=sparse.vstack(chunks,format='csr').astype(float)
            A=((A+A.T)!=0).astype(float).tocsr();A.setdiag(0);A.eliminate_zeros()
            assert (A!=A.T).nnz==0
            sparse.save_npz(O/f'{target}_adjacency.npz',A)
            np.savez_compressed(O/f'{target}_local.npz',g=g,X=X,y=y)
            layers[target]=(g,X,y)
        print('verified 11 datasets and built sparse reference',target,flush=True)
        pd.DataFrame(checks).to_csv(O/'all66_dataset_hash_checks.csv',index=False)
    n=len(tuples)
    Xsum=np.zeros((n,64));Xcount=np.zeros(n);y=np.full(n,np.nan)
    presence=np.zeros((n,6),bool)
    for j,(target,(g,X,localy)) in enumerate(layers.items()):
        count=np.bincount(g,minlength=n)
        sums=np.zeros((n,64));np.add.at(sums,g,X)
        present=count>0
        Xsum[present]+=sums[present]/count[present,None]
        Xcount[present]+=1;presence[present,j]=True
        for ix,value in zip(g,localy):
            if np.isfinite(value):
                assert not np.isfinite(y[ix]) or y[ix]==value
                y[ix]=value
    X=Xsum/Xcount[:,None]
    identity_text='\n'.join(a+'\t'+b+'\t'+('NA' if np.isnan(c) else str(int(c))) for (a,b),c in zip(tuples,y))
    identity_sha=hashlib.sha256(identity_text.encode()).hexdigest()
    expected=json.loads((B/'input/current_source/reference/expected_identity.json').read_text())
    assert identity_sha==expected['IdentitySHA256']
    record=pd.read_csv(B/'input/current_protocol/identity_record_map.csv',keep_default_na=False)
    assert len(record)==n==22659
    assert list(record.EnsemblID.astype(str))==[a for a,b in tuples]
    assert list(record.GeneSymbol.astype(str))==[b for a,b in tuples]
    recorded_y=pd.to_numeric(record.Label,errors='coerce').to_numpy()
    assert np.array_equal(y,recorded_y,equal_nan=True)
    ens=[re.sub(r'\.\d+$','',a.upper()) for a,b in tuples]
    syms=[b.upper() for a,b in tuples]
    parent=np.arange(n)
    def root(i):
        while parent[i]!=i:
            parent[i]=parent[parent[i]];i=parent[i]
        return i
    for column in [ens,syms]:
        seen={}
        for i,v in enumerate(column):
            if not v:continue
            if v in seen:
                a,b=root(i),root(seen[v]);parent[max(a,b)]=min(a,b)
            else:seen[v]=i
    components=[root(i) for i in range(n)];mapping={}
    groups=np.array([mapping.setdefault(v,len(mapping)+1) for v in components],int)
    assert np.array_equal(groups,record.GroupID.to_numpy())
    assert len(mapping)==21868
    np.savez_compressed(O/'historical_global_inputs.npz',X=X,y=y,presence=presence,GroupID=groups)
    summary=dict(DatasetHashChecks=len(checks),AllDatasetHashesMatch=all(x['Match'] for x in checks),
                 GlobalRecords=n,IdentityGroups=len(mapping),PositiveRecords=int((y==1).sum()),NegativeRecords=int((y==0).sum()),UnlabelledRecords=int(np.isnan(y).sum()),
                 ReconstructedIdentitySHA256=identity_sha,MatchesOriginalFormalIdentity=True,AllSourceLabelsEqualFormal=True,GroupsEqualFormal=True,
                 HistoricalFreezeEvidence='Author model downloads linked by2021-01-20 archived README; server Last-Modified and H5 member mtime2020-10-31; exact current/reference dataset hashes',
                 HistoricalCryptographicTimestampAvailable=False,NoFittingPerformed=True)
    m.save_json(O/'source_verification_summary.json',summary)
    print(json.dumps(summary,indent=2),flush=True)
