"""Evaluate locked historical-input temporal catalog protocol; no fitting."""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.stats import hypergeom, fisher_exact, false_discovery_control
from sklearn.metrics import average_precision_score, roc_auc_score

B=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--results-dir',type=Path,default=B/'temporal_results_v1');args=parser.parse_args()
O=args.results_dir
protocol=json.loads((O/'locked_protocol.json').read_text())
source=json.loads((B/'source_checks/source_verification_summary.json').read_text())
replay=json.loads((B/'raw_replay_checks/raw_input_replay_summary.json').read_text())
assert source['AllDatasetHashesMatch'] and replay['Passed']
assert not (O/'temporal_metrics.csv').exists(),'Refuse existing result overwrite'
d=pd.read_csv(O/'primary13466_frozen_scores_and_labels.csv').sort_values('GroupID').reset_index(drop=True)
y=d.LaterCatalogMembership.to_numpy(int);P=int(y.sum());N=len(y)-P
assert len(d)==13466 and P==65 and d.GroupID.is_unique
cols=protocol['ModelColumns'];Bdraw=protocol['Bootstrap']['Draws']
def reducer(score):
    order=np.argsort(-score,kind='stable');s=score[order]
    starts=np.r_[0,np.flatnonzero(s[:-1]!=s[1:])+1]
    return order,starts
reductions={name:reducer(d[col].to_numpy(float)) for name,col in cols.items()}
def weighted(weights,name):
    order,starts=reductions[name];w=weights[:,order];yy=y[order]
    tp=np.add.reduceat(w*yy,starts,axis=1);nn=np.add.reduceat(w*(1-yy),starts,axis=1)
    ct=tp.cumsum(axis=1);cn=nn.cumsum(axis=1)
    precision=np.divide(ct,ct+cn,out=np.zeros_like(ct),where=ct+cn>0)
    ap=(precision*tp).sum(axis=1)/ct[:,-1]
    auc=(tp*(cn[:,-1,None]-cn+.5*nn)).sum(axis=1)/(ct[:,-1]*cn[:,-1])
    return ap,auc
boot={name:np.empty((Bdraw,2)) for name in cols}
rng=np.random.default_rng(protocol['Bootstrap']['Seed']);pos=np.flatnonzero(y);neg=np.flatnonzero(1-y)
expanded_checks=[]
for start in range(0,Bdraw,100):
    size=min(100,Bdraw-start);weights=[];first=[]
    for j in range(size):
        ix=np.r_[rng.choice(pos,P,replace=True),rng.choice(neg,N,replace=True)]
        weights.append(np.bincount(ix,minlength=len(y)))
        if start==0 and j<3:first.append(ix)
    weights=np.asarray(weights,float)
    for name,col in cols.items():
        ap,auc=weighted(weights,name);boot[name][start:start+size]=np.column_stack([ap,auc])
        for j,ix in enumerate(first):
            ref=[average_precision_score(y[ix],d[col].to_numpy()[ix]),roc_auc_score(y[ix],d[col].to_numpy()[ix])]
            err=max(abs(ap[j]-ref[0]),abs(auc[j]-ref[1]));expanded_checks.append(err);assert err<1e-12
    if start%1000==0:print('paired group bootstrap',start+size,'/',Bdraw,flush=True)
def role(name):
    return 'Main' if name in protocol['MainModels'] else 'Diagnostic' if name in protocol['DiagnosticModels'] else 'Exploratory'
metrics=[];bd=pd.DataFrame({'Bootstrap':np.arange(1,Bdraw+1)})
for name,col in cols.items():
    s=d[col].to_numpy(float);ap=average_precision_score(y,s);au=roc_auc_score(y,s)
    check=weighted(np.ones((1,len(y))),name)
    assert abs(check[0][0]-ap)<1e-12 and abs(check[1][0]-au)<1e-12
    intervals=np.quantile(boot[name],[.025,.975],axis=0)
    metrics.append(dict(Model=name,Role=role(name),N=len(y),LaterPositiveN=P,Prevalence=P/len(y),AP=ap,
                        AP_CI95_Lower=intervals[0,0],AP_CI95_Upper=intervals[1,0],
                        AUROC=au,AUROC_CI95_Lower=intervals[0,1],AUROC_CI95_Upper=intervals[1,1],AP_Over_Prevalence=ap/(P/len(y))))
    bd[name+'_AP']=boot[name][:,0];bd[name+'_AUROC']=boot[name][:,1]
res=pd.DataFrame(metrics);res.to_csv(O/'temporal_metrics.csv',index=False);bd.to_csv(O/'paired_group_bootstrap5000.csv',index=False)
delta=boot['GC_BRB'][:,0]-boot['XGBOOST_37D'][:,0]
diff=dict(Contrast='GC_BRB_minus_XGBOOST_37D',DeltaAP=float(res.set_index('Model').loc['GC_BRB','AP']-res.set_index('Model').loc['XGBOOST_37D','AP']),
          CI95_Lower=float(np.quantile(delta,.025)),CI95_Upper=float(np.quantile(delta,.975)),PairedBootstrap=5000)
pd.DataFrame([diff]).to_csv(O/'planned_paired_delta_AP.csv',index=False)
top=[];ranks=d.loc[y==1,['GroupID','GeneSymbolNormalized']].copy()
for name,col in cols.items():
    score=d[col].to_numpy(float);order=np.lexsort((d.GroupID.to_numpy(),-score));rank=np.empty(len(y),int);rank[order]=np.arange(1,len(y)+1)
    ranks[name+'_Rank']=rank[y==1]
    for k in [100,500]:
        selected=rank<=k;hits=int(y[selected].sum());p=float(hypergeom.sf(hits-1,len(y),P,k))
        assert abs(p-fisher_exact([[hits,k-hits],[P-hits,len(y)-P-k+hits]],alternative='greater').pvalue)<1e-12
        boundary=score[order[k-1]];inclusive=score>=boundary
        top.append(dict(Model=name,Role=role(name),K=k,Hits=hits,Precision=hits/k,Recall=hits/P,ExpectedRandomHits=k*P/len(y),
                        Enrichment=hits/(k*P/len(y)),HypergeomUpperP=p if role(name)=='Main' else np.nan,
                        BoundaryTieGroups=int((score==boundary).sum()),TieInclusiveGroups=int(inclusive.sum()),TieInclusiveHits=int(y[inclusive].sum())))
top=pd.DataFrame(top);planned=top.Role.eq('Main');assert planned.sum()==4
top.loc[planned,'BH_q_4']=false_discovery_control(top.loc[planned,'HypergeomUpperP'],method='bh')
top.to_csv(O/'planned_topK_catalog_enrichment.csv',index=False);ranks.to_csv(O/'positive65_ranks_all_models.csv',index=False)
summary=dict(Completed=True,NewModelTraining=False,Design=protocol['Design'],HistoricalCutoff=protocol['Cutoff'],
             Universe=13466,LaterCatalogPositives=65,ExcludedHistoricalCatalogGroups=137,ExistingTier1Unchanged=288,
             Metrics=metrics,PlannedPairedDifference=diff,TopK=top.replace({np.nan:None}).to_dict('records'),
             ExpandedSklearnChecks=len(expanded_checks),MaxExpandedCheckError=float(max(expanded_checks)),
             ProtocolSHA256=hashlib.sha256((O/'locked_protocol.json').read_bytes()).hexdigest(),
             ReuseQualification='All66source datasets match author data, identities/labels match formal protocol, original preparedSHA unchanged, raw-source replay87checks across3CPDBfits passed. Other27fits not replayed from raw source in this step.',
             Interpretation='Future filtered-catalog membership among historically uncatalogued benchmark-unlabelled groups. Complement is not biological ground-truth negative; retrospective methods development and source-cohort overlap limit prospective/independent-patient claims.')
(O/'temporal_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False))
print(res.to_string(index=False));print(diff)
