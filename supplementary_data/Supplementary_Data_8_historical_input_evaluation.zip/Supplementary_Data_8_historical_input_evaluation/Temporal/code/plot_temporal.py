"""One editable vector figure with Times New Roman font declarations."""
from pathlib import Path
import argparse
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

B=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--results-dir',type=Path,default=B/'temporal_results_v1');args=parser.parse_args();O=args.results_dir
F=O/'figures';F.mkdir(exist_ok=True)
names=['GC_BRB','XGBOOST_37D','RULE','LR37','LOGISTIC_37D','RANDOM_FOREST_37D','RBF_SVM_37D','SHALLOW_MLP_37x16x1']
labels=['GC-BRB','XGBoost 37D','Rule branch','LR branch','Logistic 37D','Random forest 37D','RBF-SVM 37D','Shallow MLP 37D']
m=pd.read_csv(O/'temporal_metrics.csv').set_index('Model').loc[names]
t=pd.read_csv(O/'planned_topK_catalog_enrichment.csv').set_index(['Model','K'])
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','Nimbus Roman','Liberation Serif','DejaVu Serif'],
                     'font.size':9,'axes.labelsize':9,'xtick.labelsize':8.5,'ytick.labelsize':9,'svg.fonttype':'none',
                     'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,'savefig.facecolor':'white'})
fig,(a,b)=plt.subplots(2,1,figsize=(7.5,6.2),gridspec_kw={'height_ratios':[1.5,1]},layout='constrained')
blue='#3678A3';coral='#D47A66';other='#6E9B9B'
for i,name in enumerate(names):
    row=m.loc[name];color=coral if name=='GC_BRB' else blue if name=='XGBOOST_37D' else other
    a.errorbar(row.AP,i,xerr=np.array([[row.AP-row.AP_CI95_Lower],[row.AP_CI95_Upper-row.AP]]),fmt='o',color=color,markersize=4,capsize=2,lw=1.2)
a.axvline(m.Prevalence.iloc[0],color='#333333',ls='--',lw=.8,label='Catalog prevalence')
a.set_yticks(range(8),labels);a.invert_yaxis();a.set_xlim(0,.09);a.set_xlabel('Average precision (95% confidence interval)')
a.legend(loc='upper right',frameon=False,fontsize=8.5);a.text(-.29,1.03,'A',transform=a.transAxes,fontweight='bold',fontsize=12)
x=np.arange(8);width=.34
for j,(k,c) in enumerate([(100,blue),(500,coral)]):
    vals=[int(t.loc[(name,k),'Hits']) for name in names]
    bars=b.bar(x+(j-.5)*width,vals,width,color=c,label=f'Top {k}')
    b.bar_label(bars,padding=2,fontsize=8)
b.set_xticks(x,labels,rotation=28,ha='right');b.set_ylabel('Later catalog hits');b.set_ylim(0,19)
b.yaxis.set_major_locator(MaxNLocator(integer=True));b.legend(loc='upper right',frameon=False,ncols=2,fontsize=8.5)
b.text(-.29,1.03,'B',transform=b.transAxes,fontweight='bold',fontsize=12)
path=F/'Temporal_catalog_validation.svg';fig.savefig(path)
preview=B/'work';preview.mkdir(exist_ok=True);fig.savefig(preview/'Temporal_catalog_validation_preview.png',dpi=160)
ns={'s':'http://www.w3.org/2000/svg'};tree=ET.parse(path)
ET.register_namespace('',ns['s']);ET.register_namespace('xlink','http://www.w3.org/1999/xlink')
tree.getroot().set('width','7.5in');tree.getroot().set('height','6.2in');tree.getroot().set('preserveAspectRatio','xMidYMid meet')
for node in tree.findall('.//s:text',ns):
    style=node.attrib.get('style','')
    parts=[v for v in style.split(';') if v.strip() and not v.strip().startswith(('font-family:','font:'))]
    parts.append("font-family: 'Times New Roman'")
    # Matplotlib emitted explicit font-size; keep it while setting the family.
    node.set('style',';'.join(parts));node.set('font-family','Times New Roman')
tree.write(path,encoding='utf-8',xml_declaration=True)
assert len(tree.findall('.//s:image',ns))==0
assert all(n.attrib.get('font-family')=='Times New Roman' for n in tree.findall('.//s:text',ns))
(F/'vector_font_checks.json').write_text(__import__('json').dumps(dict(TextElements=len(tree.findall('.//s:text',ns)),EmbeddedRasterImages=0,FontFamily='Times New Roman',FontEmbedded=False,NativeVisioImportTested=False),indent=2))
print('saved',path)
