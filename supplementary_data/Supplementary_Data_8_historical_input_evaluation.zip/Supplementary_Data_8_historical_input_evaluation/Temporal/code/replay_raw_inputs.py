"""Replay original non-fit predictions from author H5 data and saved fits.

Three CPDB final fits carried by original part01; no fitting or model selection.
Training rows have OOF evidence, so this check explicitly excludes fit_idx.
"""
from pathlib import Path
import hashlib
import io
import json
import sys
import zipfile
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.io import loadmat
from scipy.special import expit

B=Path(__file__).resolve().parent
SRC=B.parents[1]/'code_cleanup_20261029/deliverable/GC_BRB_CURRENT_CODE_20261029/CURRENT/02_grouped_analyses/source'
sys.path.insert(0,str(SRC))
import model_replay as mr
import graph_math as gm

S=B/'source_checks';O=B/'raw_replay_checks';O.mkdir(exist_ok=True)
data=np.load(S/'historical_global_inputs.npz')
X,y,presence,groups=[data[k] for k in ['X','y','presence','GroupID']]
n=len(y)
archive=B/'recovered_models/01_CPDB_MODELS_part01.zip'
with zipfile.ZipFile(archive) as z:
    states=[loadmat(io.BytesIO(z.read(f'run_{r:02d}/final_portable.mat')),simplify_cells=True)['state'] for r in range(1,4)]
    metadata=json.loads(z.read('protocol.json'))
expected=json.loads((B/'input/current_protocol/protocol.json').read_text())
assert metadata['BaseFingerprint']==expected['BaseFingerprint']
assert all(s['base_fingerprint']==expected['BaseFingerprint'] for s in states)
e=[];seedflags=[];check_indices=[];checks=[]
for s in states:
    flag=np.zeros(n,bool);flag[s['fit_idx'].astype(int)-1]=True;seedflags.append(flag)
    idx=np.flatnonzero(~np.isin(groups,groups[flag]));check_indices.append(idx)
    assert not set(groups[flag])&set(groups[idx])
    om=expit(X@np.asarray(s['omics']['original_beta']).ravel()+float(s['omics']['original_bias']))
    error=np.max(np.abs(om[idx]-s['evidence']['omics_score'][idx]))
    checks.append(dict(Run=int(s['run']),Field='omics_score',Network='ALL',N=len(idx),MaxAbsDiff=error))
    assert error<1e-10
    e.append(dict(omics_score=om,onehop=np.full((n,6),.5),twohop=np.full((n,6),.5),
                  diffusion=np.full((n,6),.5),confidence=np.zeros((n,6)),presence=presence.copy()))
for j,target in enumerate(mr.NETWORKS):
    local=np.load(S/f'{target}_local.npz');g=local['g']
    A=sparse.load_npz(S/f'{target}_adjacency.npz')
    counts=np.bincount(g,minlength=n);localweight=1/counts[g]
    restarts=[]
    for flag in seedflags:
        for label in [1,0]:
            mass=(flag[g]&(y[g]==label)).astype(float)*localweight
            assert mass.sum()>0
            restarts.append(mass/mass.sum())
    fields,iterations,normalizers=gm.evidence(A,np.column_stack(restarts))
    for k,(s,flag) in enumerate(zip(states,seedflags)):
        idx=check_indices[k]
        for c,name in enumerate(['onehop','twohop','diffusion','confidence']):
            pooled=np.bincount(g,weights=fields[:,k,c],minlength=n)/np.maximum(counts,1)
            e[k][name][counts>0,j]=pooled[counts>0]
            error=np.max(np.abs(e[k][name][idx,j]-s['evidence'][name][idx,j]))
            checks.append(dict(Run=int(s['run']),Field=name,Network=target,N=len(idx),MaxAbsDiff=error))
            assert error<1e-10,(target,k,name,error)
        assert int(iterations[k])==int(np.asarray(s['evidence']['rwr_iterations']).ravel()[j])
    print('raw topology replay passed',target,'RWR',iterations.tolist(),flush=True)
for k,(s,flag) in enumerate(zip(states,seedflags)):
    idx=check_indices[k];engine=mr.Replay(s)
    out=engine.score({name:v[idx] for name,v in e[k].items()})
    for output,original in [('features',s['evidence']['feature_matrix']),('BackboneProbability',s['rule_score']),
                            ('ResidualProbability',s['lr_score']),('FinalProbability',s['final_score'])]:
        error=np.max(np.abs(out[output]-original[idx]))
        checks.append(dict(Run=int(s['run']),Field=output,Network='ALL',N=len(idx),MaxAbsDiff=error))
        assert error<1e-10,(k,output,error)
pd.DataFrame(checks).to_csv(O/'all87_raw_input_replay_checks.csv',index=False)
summary=dict(FrozenFits=3,Target='CPDB',Runs=[1,2,3],SourceNetworks=6,Checks=len(checks),
             MaximumAbsoluteError=float(max(x['MaxAbsDiff'] for x in checks)),Passed=True,NewFitting=False,
             Scope='Rebuilt64D aligned features and all6 graph evidence sources, then37D/BRB/LR/final for identity groups absent from the fit sets in CPDB final runs01-03. Remaining27fits not rechecked from raw source in this step.',
             SharedPreparedSHA256=expected['PreparedSHA256'],SharedBaseFingerprint=expected['BaseFingerprint'],
             SourceFiles={name:hashlib.sha256((SRC/name).read_bytes()).hexdigest() for name in ['model_replay.py','graph_math.py','nr0b2_local_analysis.py']})
(O/'raw_input_replay_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2),flush=True)
