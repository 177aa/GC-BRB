"""Recreate the locked population in a NEW output directory; no fitting."""
import argparse,hashlib,json
from pathlib import Path
import pandas as pd

B=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
source=B/'frozen_inputs/frozen13603_before_temporal_filter.csv'
template=B/'temporal_results_v1/locked_protocol.json'
p=json.loads(template.read_text());assert hashlib.sha256(source.read_bytes()).hexdigest()==p['SourceTableSHA256']
d=pd.read_csv(source);rec=pd.read_csv(B/'input/current_protocol/identity_record_map.csv',keep_default_na=False)
catalogs={}
for year in [2020,2024]:
    path=next((B/'input/intogen_sources'/f'IntOGen_{year}').glob('*Compendium_Cancer_Genes.tsv'))
    table=pd.read_csv(path,sep='\t');catalogs[year]=set(table.SYMBOL.dropna().astype(str).str.strip().str.upper())
known=set(rec.loc[rec.SymbolNormalized.isin(catalogs[2020]),'GroupID'])
later=set(rec.loc[rec.SymbolNormalized.isin(catalogs[2024]-catalogs[2020]),'GroupID'])
d['HistoricalIntOGen2020Known']=d.GroupID.isin(known);d['LaterCatalogMembership']=d.GroupID.isin(later)
d['PrimaryTemporalEligible']=~d.HistoricalIntOGen2020Known
excluded=d.loc[~d.PrimaryTemporalEligible];eligible=d.loc[d.PrimaryTemporalEligible].sort_values('GroupID')
assert len(excluded)==p['ExcludedPreviouslyCataloguedGroups'] and len(eligible)==p['PrimaryGroups'] and eligible.LaterCatalogMembership.sum()==p['LaterCatalogPositiveGroups']
args.output.mkdir(parents=True,exist_ok=False)
(args.output/'locked_protocol.json').write_bytes(template.read_bytes())
d.to_csv(args.output/'all13603_with_historical_eligibility.csv',index=False)
excluded.to_csv(args.output/'excluded137_previously_catalogued_groups.csv',index=False)
eligible.to_csv(args.output/'primary13466_frozen_scores_and_labels.csv',index=False)
print('NEW output prepared:',args.output)
