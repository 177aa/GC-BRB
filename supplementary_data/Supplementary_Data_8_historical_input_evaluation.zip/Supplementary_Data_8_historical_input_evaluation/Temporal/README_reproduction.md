# Historical-input catalog evaluation

This archive contains the saved scores, catalog labels, results, source checks and analysis scripts for the historical-input catalog analysis.

## Verify the saved results

From the `Temporal` folder, run:

```text
python code/verify_temporal_results.py
```

The script verifies the saved scores, performance metrics, bootstrap intervals and rankings. It skips checks for the original return archive, which is not included here.

The remaining scripts use the original project structure and require additional input files, including the original H5 data and model checkpoints.