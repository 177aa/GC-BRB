Supplementary Data 8 | Historical-input catalog evaluation and source checks
Contains the original temporal frozen scores, the 65 subsequent catalog entries, 137 exclusions, catalog-source and 66 dataset-hash checks, 87 raw-input replay checks, bootstrap outputs, protocols and source receipts. The historical-input evaluation is retrospective catalog inclusion, not prospective patient validation. The original FigS14_temporal_catalog vector source uses the 29 October figure numbering and corresponds by subject to current Supplementary Fig. S13; visually verify before reuse. The full original H5 data and frozen model checkpoints are not included. Files 

File sizes and SHA-256 checksums are listed in MANIFEST.csv.
