Supplementary Data 1 | TCGA cohort feasibility and analysis status
The cohort feasibility file records expression and survival availability, events and covariate availability for 33 TCGA projects and two endpoints. The status file records planned model-fit status counts; the scope file describes the 288-candidate analysis. These are aggregate records, not individual patient data. The source is the 27 October 2026 continuation result; no model was refitted.

File-level provenance and SHA-256 checksums are in MANIFEST.csv.
