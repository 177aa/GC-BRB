# Supplementary Data 6

This archive accompanies the 29 October 2026 manuscript revision.

- Population/: saved fixed-model group/source intervention records, summary tables, locked protocol and analysis code. No models were refitted. The primary cohort is the eligible held-out test identity groups; candidate results are descriptive.
- Temporal/: frozen scores, 13,466-group evaluation, 137 exclusions, 65 positive ranks, catalog-cohort provenance, paired bootstrap draws, protocol, source and raw-input replay checks, retrieval receipts and code. Original candidate annotation uses 13,603 groups; the 288-member Tier-1 list is unchanged.
- Editable_figures/: Figures S14, S26 and S27 as SVG and EMF. Text is explicitly Times New Roman. EMF contains native text records and no bitmaps; keep the original aspect ratio when importing. These files have been checked in a document renderer; Microsoft Visio was not available for application-level validation.
- Manifest_SHA256.csv: byte-level inventory of this archive excluding the manifest itself.

Population intervals resample global identity groups conditional on 30 fixed models. Source support neutralization is not physical graph editing. Temporal outcomes are later catalog membership, not true-negative biology or independent future patients. The temporal design is retrospective; the later catalog had already been inspected before this analysis.

The large raw EMOGI model/data release archives are retained in the separate source archive already delivered; they are not duplicated here. Frozen model checkpoints needed for a complete population replay remain in the existing project master. This package supplies the full tabular records and reproducible summaries.
