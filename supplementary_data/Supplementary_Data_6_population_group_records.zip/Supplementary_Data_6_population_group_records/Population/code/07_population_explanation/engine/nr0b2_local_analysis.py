#!/usr/bin/env python3
"""Frozen CPDB run_01 perturbations faithfully transcribed from supplied MATLAB.

Dependencies: numpy, scipy, pandas, h5py. Inputs are never modified.
Each intervention changes one PPI source, retains the full vertex set,
training seed membership and restart vectors, recomputes graph evidence
(including graph-dependent 90th-percentile confidence normalizers), then
uses saved BRB, LR and fusion parameters. Isolating a neighbor retains its
restart mass and its RWR self-loop. No model is fitted in this script.
"""
from pathlib import Path
import argparse, hashlib, json, time, sys
try:
    import h5py
except ImportError:
    # This experiment loads portable v7 MAT states with scipy.io.loadmat.
    # HDF5 graph loading belongs to the unused original Analysis constructor.
    h5py = None
import numpy as np
import pandas as pd
from scipy.sparse import csc_matrix
from scipy.special import expit


def text(ds):
    return ''.join(chr(int(x)) for x in ds[()].ravel())


def chars(f, ds):
    return np.array([text(f[r]) for r in ds[()].ravel()], dtype=object)


def vec(g, name):
    return np.asarray(g[name][()]).ravel()


def feature_matrix(e):
    d,h1,h2,c,p=[np.atleast_2d(e[k]) for k in ('diffusion','onehop','twohop','confidence','presence')]
    om=np.asarray(e['omics_score']).ravel()
    den=c.sum(axis=1)
    weights=[np.divide((a*c).sum(axis=1),den,out=np.full(len(den),.5),where=den>np.finfo(float).eps) for a in (d,h1,h2)]
    def present_std(x):
        return np.array([np.std(row[pr.astype(bool)],ddof=1) if pr.sum()>=2 else 0 for row,pr in zip(x,p)])
    return np.column_stack([om,d,h1,h2,c,p,*weights,p.mean(axis=1),present_std(d),.5*(present_std(h1)+present_std(h2))])


def membership(x, refs):
    x=np.asarray(x).ravel(); ans=np.zeros((len(x),3))
    ans[x<=refs[0],0]=1;ans[x>=refs[2],2]=1
    left=(x>refs[0])&(x<=refs[1]);right=(x>refs[1])&(x<refs[2])
    t=(x[left]-refs[0])/(refs[1]-refs[0]);ans[left,0]=1-t;ans[left,1]=t
    t=(x[right]-refs[1])/(refs[2]-refs[1]);ans[right,1]=1-t;ans[right,2]=t
    bad=(ans.sum(axis=1)<=0)|~np.isfinite(ans.sum(axis=1));ans[bad]=1/3
    return ans/ans.sum(axis=1,keepdims=True)


def brb(X, refs, ants, par, eps):
    mu=[membership(X[:,j],refs[:,j]) for j in range(2)]
    aw=np.maximum(par['attributes'],0); aw=aw/aw.max() if aw.max()>eps else np.ones(2)
    matching=np.ones((len(X),len(ants)))
    for j in range(2):
        if aw[j]>eps:matching*=mu[j][:,ants[:,j]]**aw[j]
    u=matching*np.maximum(par['rules'],eps)
    den=u.sum(axis=1,keepdims=True);activation=np.divide(u,den,out=np.full_like(u,1/len(ants)),where=(den>eps)&np.isfinite(den))
    t3=np.prod(1-activation,axis=1)
    t1=np.column_stack([np.prod(activation*par['beta'][:,j]+1-activation,axis=1) for j in range(2)])
    normalizer=1/np.maximum(t1.sum(axis=1)-t3,eps)
    belief=normalizer[:,None]*(t1-t3[:,None])/np.maximum(1-normalizer*t3,eps)[:,None]
    belief=np.maximum(belief,0);s=belief.sum(axis=1)
    bad=(~np.isfinite(s))|(s<=eps)
    if bad.any():
        fallback=np.clip((activation[bad]*par['beta'][:,1]).sum(axis=1),0,1)
        belief[bad]=np.column_stack([1-fallback,fallback]);s[bad]=1
    belief/=s[:,None]
    return belief[:,1],activation


class Analysis:
    def __init__(self, inputs, out):
        self.root=inputs/'01_GCBRB';self.out=out;out.mkdir(parents=True,exist_ok=True)
        self.bdir=self.root/'results/backbone/official_exact/CPDB/run_01'
        self.fdir=self.root/'results/final/official_exact/CPDB/run_01'
        with h5py.File(self.root/'cache/prepared/multilayer_aligned_gcbrb.mat') as f:
            d=f['data'];self.symbols=chars(f,d['gene_symbols']);self.ensembl=chars(f,d['ensembl_ids']);self.keys=chars(f,d['global_keys'])
            self.y=vec(d,'y');self.presence=d['presence'][()].T.astype(bool);self.n=len(self.y)
            targets=np.flatnonzero(self.symbols=='NR0B2');assert len(targets)==1
            self.target=int(targets[0]);self.layers=[]
            for ref in d['layers'][()].ravel():
                g=f[ref];a=g['A'];size=int(a.attrs['MATLAB_sparse'])
                A=csc_matrix((vec(a,'data'),vec(a,'ir'),vec(a,'jc')),shape=(size,size)).tocsr()
                ltg=vec(g,'local_to_global').astype(int)-1
                assert len(np.unique(ltg))==len(ltg),'Duplicate local rows need explicit pooling support'
                degree=vec(g,'degree');assert np.array_equal(degree,np.asarray(A.sum(axis=1)).ravel())
                local=np.flatnonzero(ltg==self.target);assert len(local)==1
                self.layers.append(dict(name=text(g['name']),A=A,degree=degree,g=ltg,target=int(local[0])))
        with h5py.File(self.bdir/'brb_model_v3layer.mat') as f:
            self.train=vec(f['split'],'train_idx').astype(int)-1
            self.val=vec(f['split'],'val_idx').astype(int)-1;self.test=vec(f['split'],'test_idx').astype(int)-1
            self.seed=int(vec(f['split'],'seed')[0]);self.eps=float(vec(f['model'],'eps')[0])
            self.cfg={k:float(vec(f['cfg'],k)[0]) for k in ['rwr_restart','rwr_max_iterations','rwr_tolerance','neighbor_smoothing','eps']}
            x=np.clip(vec(f,'xbest'),0,1);self.par=[]
            for j in range(3):
                chunk=x[j*29:(j+1)*29];beta=chunk[:18].reshape(9,2).copy()
                sums=beta.sum(axis=1);beta[sums<=self.eps]=.5;sums=beta.sum(axis=1);beta/=sums[:,None]
                self.par.append(dict(beta=beta,rules=chunk[18:27],attributes=chunk[27:29]))
            self.reliability=x[87:93];self.refs=f['model/references'][()].T;self.ants=f['model/rule_antecedents'][()].T.astype(int)-1
        with h5py.File(self.bdir/'evidence_v3layer.mat') as f:
            e=f['evidence'];self.e={k:e[k][()].T for k in ('onehop','twohop','diffusion','confidence','presence')}
            self.e['omics_score']=vec(e,'omics_score');self.F=e['feature_matrix'][()].T
            for k,idx in [('train_idx',self.train),('val_idx',self.val),('test_idx',self.test)]:assert np.array_equal(vec(f['split'],k).astype(int)-1,idx)
        with h5py.File(self.fdir/'fusion_model.mat') as f:
            self.alpha=float(vec(f['selection'],'alpha')[0])
            for k,idx in [('train_idx',self.train),('val_idx',self.val),('test_idx',self.test)]:assert np.array_equal(vec(f['split'],k).astype(int)-1,idx)
        coeff=pd.read_csv(self.fdir/'residual_linear_coefficients.csv');self.beta=coeff['OriginalScaleCoefficient'].to_numpy()
        self.feature_names=coeff['Feature'].tolist();self.bias=pd.read_csv(self.fdir/'residual_linear_intercept.csv')['OriginalScaleIntercept'].iloc[0]
        assert self.n==22659 and self.target==1547 and self.target not in self.train
        self.seedflag=np.zeros(self.n,dtype=bool);self.seedflag[self.train]=True
        self.baseline_e={k:np.atleast_2d(v[self.target]) if k!='omics_score' else np.array([v[self.target]]) for k,v in self.e.items()}
        self.baseline_scores=self.score(self.baseline_e)
        self.feature_names=coeff['Feature'].tolist()
        self.base_graph=[]

    def score(self,e):
        n=len(e['omics_score']);s=len(self.layers)
        local=np.zeros((n,s));net=np.zeros((n,s))
        for j in range(s):
            local[:,j],_=brb(np.column_stack([e['onehop'][:,j],e['twohop'][:,j]]),self.refs,self.ants,self.par[0],self.eps)
            net[:,j],_=brb(np.column_stack([e['diffusion'][:,j],local[:,j]]),self.refs,self.ants,self.par[1],self.eps)
        w=np.clip(e['confidence']*e['presence']*self.reliability,0,1)
        m0=np.zeros(n);m1=np.zeros(n);mu=np.ones(n);conf=np.zeros(n)
        for j in range(s):
            z0=w[:,j]*(1-net[:,j]);z1=w[:,j]*net[:,j];zu=1-w[:,j]
            k=m0*z1+m1*z0;den=np.maximum(1-k,self.eps)
            m0,m1,mu=(m0*z0+m0*zu+mu*z0)/den,(m1*z1+m1*zu+mu*z1)/den,mu*zu/den
            conf=np.maximum(conf,k)
        fused=np.clip(m1+.5*mu,0,1)
        quality=np.clip((.35+.65*np.mean(e['presence'],axis=1))*(1-.5*np.clip(conf,0,1))*(1-.5*np.clip(mu,0,1)),0,1)
        adjusted=np.clip(.5+quality*(fused-.5),0,1)
        rule,activation=brb(np.column_stack([e['omics_score'],adjusted]),self.refs,self.ants,self.par[2],self.eps)
        F=feature_matrix(e);lr=expit(F@self.beta+self.bias)
        final=(1-self.alpha)*rule+self.alpha*lr
        return dict(BackboneProbability=rule,ResidualProbability=lr,FinalProbability=final,ERFusedTopology=fused,
                    EvidenceQuality=quality,QualityAdjustedTopology=adjusted,ERMaxConflict=conf,UnknownMass=mu,
                    local_topology=local,network_score=net,BRB3Activation=activation,features=F)

    def topology(self, j, kind='baseline', neighbor=None):
        layer=self.layers[j];A=layer['A'];g=layer['g'];n=len(g);degree=layer['degree'].copy()
        focal=layer['target'];changed=None
        if kind=='edge':
            degree[focal]-=1;degree[neighbor]-=1
            def multiply(x):
                y=A@x;y[focal]-=x[neighbor];y[neighbor]-=x[focal];return y
        elif kind=='node_isolation':
            changed=A.indices[A.indptr[neighbor]:A.indptr[neighbor+1]]
            degree[changed]-=1;degree[neighbor]=0
            def multiply(x):
                y=A@x;y[neighbor]-=x[changed].sum(axis=0);y[changed]-=x[neighbor];return y
        else:multiply=lambda x:A@x
        # Clamp cancellation roundoff from subtracting removed nonnegative edges.
        def walk(x):return np.maximum(multiply(x),0)
        ps=(self.seedflag[g]&(self.y[g]==1)).astype(float);ns=(self.seedflag[g]&(self.y[g]==0)).astype(float)
        ps/=ps.sum();ns/=ns.sum();restart=np.column_stack([ps,ns]);r=restart.copy()
        inv=1/(degree+1);a=self.cfg['rwr_restart']
        for iteration in range(1,int(self.cfg['rwr_max_iterations'])+1):
            nxt=a*restart+(1-a)*(walk(r*inv[:,None])+r*inv[:,None])
            delta=np.abs(nxt-r).sum(axis=0).max();r=nxt
            if delta<self.cfg['rwr_tolerance']:break
        mass=r.sum(axis=1);diffusion=np.divide(r[:,0],mass,out=np.full(n,.5),where=mass>self.eps)
        scale=1/np.maximum(degree,1)
        hop1=walk(restart*scale[:,None]);hop2=walk(hop1*scale[:,None])
        h1sum=hop1.sum(axis=1);h2sum=hop2.sum(axis=1)
        h1=np.divide(hop1[:,0],h1sum,out=np.full(n,.5),where=h1sum>self.cfg['neighbor_smoothing'])
        h2=np.divide(hop2[:,0],h2sum,out=np.full(n,.5),where=h2sum>self.cfg['neighbor_smoothing'])
        qdeg=np.quantile(degree,.9,method='linear');degree_conf=np.minimum(1,np.log1p(degree)/np.log1p(qdeg)) if qdeg>0 else np.zeros(n)
        qmass=np.quantile(mass[mass>0],.9,method='linear') if np.any(mass>0) else 0
        mass_conf=np.minimum(1,mass/max(qmass,self.eps)) if qmass>0 else np.zeros(n)
        support=h1sum+h2sum;qsupport=np.quantile(support[support>0],.9,method='linear') if np.any(support>0) else 0
        support_conf=np.minimum(1,support/max(qsupport,self.eps)) if qsupport>0 else np.zeros(n)
        confidence=np.clip(.10+.20*degree_conf+.35*mass_conf+.35*support_conf,0,1)
        return dict(onehop=h1,twohop=h2,diffusion=np.clip(diffusion,0,1),confidence=confidence,
                    mass=mass,h1mass=hop1,h2mass=hop2,iterations=iteration,q_degree=qdeg,q_mass=qmass,q_support=qsupport)

    def baseline(self):
        checks=[];graph_rows=[];t=time.time()
        with h5py.File(self.fdir/'frozen_backbone_outputs.mat') as f:
            frozen=vec(f['base_cache'],'score');frozenq=vec(f['base_cache'],'quality')
        current=self.score(self.e)
        checks.append(dict(Check='Frozen backbone all rows',MaxAbsDiff=float(np.max(np.abs(current['BackboneProbability']-frozen)))))
        checks.append(dict(Check='Frozen evidence quality all rows',MaxAbsDiff=float(np.max(np.abs(current['EvidenceQuality']-frozenq)))))
        checks.append(dict(Check='Saved 37-D feature assembly',MaxAbsDiff=float(np.max(np.abs(current['features']-self.F)))))
        with h5py.File(self.fdir/'residual_linear.mat') as f:
            full=vec(f['residual'],'full_training_score')
        checks.append(dict(Check='Frozen LR full-training scores',MaxAbsDiff=float(np.max(np.abs(current['ResidualProbability']-full)))))
        trace=pd.read_csv(self.root/'results/nr0b2_real_forward_trace/official_exact/NR0B2_TRACE_ALL_30RUNS.csv').iloc[0]
        for key in ('BackboneProbability','ResidualProbability','FinalProbability','EvidenceQuality','QualityAdjustedTopology'):
            checks.append(dict(Check='NR0B2 trace '+key,MaxAbsDiff=float(abs(self.baseline_scores[key][0]-trace[key]))))
        nottrain=~self.seedflag
        neighbors=[]
        for j,layer in enumerate(self.layers):
            top=self.topology(j);self.base_graph.append(top)
            g=layer['g'];compare=nottrain[g]
            for field in ('onehop','twohop','diffusion','confidence'):
                diff=np.max(np.abs(top[field][compare]-self.e[field][g[compare],j]))
                checks.append(dict(Check=layer['name']+' non-training '+field,MaxAbsDiff=float(diff)))
            A=layer['A'];row=A.indices[A.indptr[layer['target']]:A.indptr[layer['target']+1]]
            for local in row:
                gi=int(g[local]);label=self.y[gi]
                neighbors.append(dict(Network=layer['name'],NeighborGlobalIndex=gi+1,NeighborLocalIndex=int(local)+1,
                                      EnsemblID=self.ensembl[gi],GeneSymbol=self.symbols[gi],Degree=int(layer['degree'][local]),
                                      IsTrainingSeed=bool(self.seedflag[gi]),BenchmarkLabel=int(label) if np.isfinite(label) else '',
                                      PositiveTrainingSeed=bool(self.seedflag[gi] and label==1),NegativeTrainingSeed=bool(self.seedflag[gi] and label==0)))
            with np.load(self.root/f'results/sefgnn_same_benchmark/03_adapter_cache/global_edge_index/{layer["name"]}_edge_index.npz') as z:
                edge=z['edge_index'].astype(np.int64)
            coo=A.tocoo();actual=np.sort(g[coo.row].astype(np.int64)*self.n+g[coo.col])
            cached=np.sort(edge[0]*self.n+edge[1])
            assert np.array_equal(actual,cached),layer['name']+' global edge mismatch'
            graph_rows.append(dict(Network=layer['name'],Nodes=len(g),UndirectedEdges=A.nnz//2,NR0B2Degree=len(row),
                                   LocalGlobalMappingUnique=True,GlobalEdgeCacheMatches=True,RWRIterations=top['iterations']))
            print('baseline',layer['name'],'degree',len(row),'RWR',top['iterations'],flush=True)
        checks=pd.DataFrame(checks);checks.to_csv(self.out/'baseline_validation.csv',index=False)
        pd.DataFrame(graph_rows).to_csv(self.out/'network_mapping_audit.csv',index=False)
        pd.DataFrame(neighbors).to_csv(self.out/'NR0B2_direct_neighbors.csv',index=False)
        maxdiff=checks.MaxAbsDiff.max();assert maxdiff<1e-10,checks.to_string(index=False)
        baseline={k:float(v[0]) for k,v in self.baseline_scores.items() if v.ndim==1}
        summary=dict(checkpoint='CPDB run_01',seed=self.seed,global_index=self.target+1,ensembl_id=self.ensembl[self.target],gene_symbol='NR0B2',
                     alpha=self.alpha,baseline=baseline,max_validation_abs_diff=float(maxdiff),
                     neighbor_network_pairs=len(neighbors),unique_neighbor_pairs=len(set(r['NeighborGlobalIndex'] for r in neighbors)),
                     baseline_seconds=time.time()-t,configuration=self.cfg)
        (self.out/'baseline_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
        self.path_support(neighbors)
        print('VALIDATED',json.dumps(summary,ensure_ascii=False),flush=True)

    def path_support(self, neighbors):
        rows=[];paths=[]
        for j,layer in enumerate(self.layers):
            A=layer['A'];g=layer['g'];degree=layer['degree'];top=self.base_graph[j]
            poscount=int(np.sum(self.seedflag[g]&(self.y[g]==1)));negcount=int(np.sum(self.seedflag[g]&(self.y[g]==0)))
            for info in neighbors:
                if info['Network']!=layer['name']:continue
                u=info['NeighborLocalIndex']-1
                adjacent=A.indices[A.indptr[u]:A.indptr[u+1]]
                seed=adjacent[self.seedflag[g[adjacent]]]
                row=dict(info)
                for cl,name,count in [(1,'Positive',poscount),(0,'Negative',negcount)]:
                    node=seed[self.y[g[seed]]==cl]
                    contributions=1/(count*np.maximum(degree[node],1)*max(degree[u],1))
                    row[name+'TwoHopSeedCount']=len(node);row[name+'TwoHopMass']=float(contributions.sum())
                    order=np.argsort(-contributions,kind='stable')[:5]
                    row[name+'TopSeedSymbols']=';'.join(str(self.symbols[g[node[k]]]) for k in order)
                    for k in order:
                        gi=int(g[node[k]])
                        paths.append(dict(Network=layer['name'],Target='NR0B2',Intermediate=info['GeneSymbol'],
                                          IntermediateGlobalIndex=info['NeighborGlobalIndex'],SeedGeneSymbol=self.symbols[gi],
                                          SeedEnsemblID=self.ensembl[gi],SeedGlobalIndex=gi+1,SeedClass=cl,
                                          TwoHopWalkMass=float(contributions[k])))
                rows.append(row)
        pd.DataFrame(rows).to_csv(self.out/'NR0B2_neighbor_training_support.csv',index=False)
        pd.DataFrame(paths).to_csv(self.out/'NR0B2_twohop_top_seed_paths.csv',index=False)

    def perturb(self):
        allrows=[];changed_features=[];activations=[];t=time.time()
        neigh=pd.read_csv(self.out/'NR0B2_direct_neighbors.csv',keep_default_na=False)
        for j,layer in enumerate(self.layers):
            saved=self.out/f'perturbations_{layer["name"]}.csv'
            fsaved=self.out/f'feature_deltas_{layer["name"]}.csv'
            asaved=self.out/f'activation_deltas_{layer["name"]}.csv'
            if all(p.exists() for p in (saved,fsaved,asaved)):
                allrows.extend(pd.read_csv(saved,keep_default_na=False).to_dict('records'));continue
            rows=[];frows=[];arows=[]
            members=neigh[neigh.Network==layer['name']].to_dict('records')
            for kind in ('edge','node_isolation'):
                for i,info in enumerate(members):
                    local=info['NeighborLocalIndex']-1;top=self.topology(j,kind,local);q=layer['target']
                    e={k:v.copy() for k,v in self.baseline_e.items()}
                    for field in ('onehop','twohop','diffusion','confidence'):e[field][0,j]=top[field][q]
                    scores=self.score(e)
                    row=dict(info,Intervention=kind,RemovedUndirectedEdges=1 if kind=='edge' else int(layer['degree'][local]),
                             RWRIterations=top['iterations'],DegreeQ90=top['q_degree'],MassQ90=top['q_mass'],SupportQ90=top['q_support'])
                    for field in ('onehop','twohop','diffusion','confidence'):
                        row[field]=float(top[field][q]);row['Delta_'+field]=float(top[field][q]-self.baseline_e[field][0,j])
                    for field,values in scores.items():
                        if values.ndim==1:
                            row[field]=float(values[0]);row['Delta_'+field]=float(values[0]-self.baseline_scores[field][0])
                    row['AbsDeltaFinal']=abs(row['Delta_FinalProbability']);rows.append(row)
                    for fi,name in enumerate(self.feature_names):
                        delta=scores['features'][0,fi]-self.baseline_scores['features'][0,fi]
                        if delta!=0:
                            frows.append(dict(Network=layer['name'],Intervention=kind,NeighborGlobalIndex=info['NeighborGlobalIndex'],
                                              GeneSymbol=info['GeneSymbol'],Feature=name,BaselineValue=float(self.baseline_scores['features'][0,fi]),
                                              PerturbedValue=float(scores['features'][0,fi]),DeltaValue=float(delta),
                                              LRLogitContribution=float(delta*self.beta[fi])))
                    for ri in range(9):
                        arows.append(dict(Network=layer['name'],Intervention=kind,NeighborGlobalIndex=info['NeighborGlobalIndex'],GeneSymbol=info['GeneSymbol'],
                                          Rule=ri+1,BaselineActivation=float(self.baseline_scores['BRB3Activation'][0,ri]),
                                          PerturbedActivation=float(scores['BRB3Activation'][0,ri]),
                                          DeltaActivation=float(scores['BRB3Activation'][0,ri]-self.baseline_scores['BRB3Activation'][0,ri])))
                    if i%50==0:print('perturb',layer['name'],kind,i+1,'/',len(members),'elapsed',round(time.time()-t,1),flush=True)
            pd.DataFrame(rows).to_csv(saved,index=False);pd.DataFrame(frows).to_csv(fsaved,index=False);pd.DataFrame(arows).to_csv(asaved,index=False)
            allrows.extend(rows)
            print('finished',layer['name'],len(rows),'elapsed',round(time.time()-t,1),flush=True)
        df=pd.DataFrame(allrows);df.to_csv(self.out/'NR0B2_frozen_local_perturbations.csv',index=False)
        pd.concat([pd.read_csv(self.out/f'feature_deltas_{l["name"]}.csv') for l in self.layers]).to_csv(self.out/'NR0B2_37D_feature_deltas.csv',index=False)
        pd.concat([pd.read_csv(self.out/f'activation_deltas_{l["name"]}.csv') for l in self.layers]).to_csv(self.out/'NR0B2_BRB3_activation_deltas.csv',index=False)
        summaries=[]
        for (kind,network),d in df.groupby(['Intervention','Network'],sort=False):
            d=d.sort_values('AbsDeltaFinal',ascending=False)
            summaries.append(dict(Intervention=kind,Network=network,N=len(d),MinDelta=d.Delta_FinalProbability.min(),MaxDelta=d.Delta_FinalProbability.max(),
                                  MeanAbsDelta=d.AbsDeltaFinal.mean(),MedianAbsDelta=d.AbsDeltaFinal.median(),
                                  LargestAbsDelta=d.AbsDeltaFinal.max(),LargestGene=d.GeneSymbol.iloc[0],LargestSignedDelta=d.Delta_FinalProbability.iloc[0],
                                  PositiveDeltaCount=int((d.Delta_FinalProbability>1e-12).sum()),NegativeDeltaCount=int((d.Delta_FinalProbability< -1e-12).sum())))
        pd.DataFrame(summaries).to_csv(self.out/'NR0B2_perturbation_network_summary.csv',index=False)
        tops=pd.concat([d.sort_values('AbsDeltaFinal',ascending=False).head(20) for _,d in df.groupby('Intervention')])
        tops.to_csv(self.out/'NR0B2_top20_per_intervention.csv',index=False)
        print('ALL DONE',len(df),'seconds',time.time()-t,flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--baseline-only',action='store_true');a=p.parse_args()
    engine=Analysis(a.inputs,a.out);engine.baseline()
    if not a.baseline_only:engine.perturb()


if __name__=='__main__':main()
