"""Portable GG_OOF_1_0 replay using the previously audited BRB/ER arithmetic."""
from pathlib import Path
import importlib.util
import numpy as np
from scipy.io import loadmat

ROOT=Path(__file__).resolve().parent.parent
PREVIOUS=Path(__file__).resolve().parent/'nr0b2_local_analysis.py'
spec=importlib.util.spec_from_file_location('audited_local_math',PREVIOUS)
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
NETWORKS=['CPDB','MULTINET','PCNET','STRINGdb','IREF','IREF_2015']

def feature_matrix(e):
    d,h1,h2,c,p=[np.atleast_2d(e[k]) for k in ('diffusion','onehop','twohop','confidence','presence')]
    p=p.astype(bool);om=np.asarray(e['omics_score']).ravel();den=c.sum(axis=1)
    weights=[np.divide((a*c).sum(axis=1),den,out=np.full(len(den),.5),where=den>np.finfo(float).eps) for a in (d,h1,h2)]
    count=p.sum(axis=1)
    def present_std(x):
        mean=np.divide((x*p).sum(axis=1),count,out=np.zeros(len(x)),where=count>0)
        variance=np.divide(((x-mean[:,None])**2*p).sum(axis=1),count-1,out=np.zeros(len(x)),where=count>1)
        return np.sqrt(np.maximum(variance,0))
    return np.column_stack([om,d,h1,h2,c,p,*weights,p.mean(axis=1),present_std(d),.5*(present_std(h1)+present_std(h2))])

old.feature_matrix=feature_matrix

class Replay(old.Analysis):
    def __init__(self,state):
        self.state=state;self.layers=[dict(name=n) for n in NETWORKS]
        model=state['brb_model'];self.eps=float(model['eps'])
        self.refs=model['references'];self.ants=model['rule_antecedents'].astype(int)-1
        x=np.clip(state['brb_x'].ravel(),0,1);self.par=[]
        for j in range(3):
            chunk=x[j*29:(j+1)*29];beta=chunk[:18].reshape(9,2).copy()
            sums=beta.sum(axis=1);beta[sums<=self.eps]=.5;sums=beta.sum(axis=1);beta/=sums[:,None]
            self.par.append(dict(beta=beta,rules=chunk[18:27],attributes=chunk[27:29]))
        self.reliability=x[87:93]
        self.beta=np.asarray(state['lr']['original_beta']).ravel();self.bias=float(state['lr']['original_bias'])
        self.alpha=float(state.get('fusion_alpha_lr_weight',0))
        self.e={k:np.asarray(state['evidence'][k]) for k in ['omics_score','onehop','twohop','diffusion','confidence','presence']}
        self.e['presence']=self.e['presence'].astype(bool)
        self.F=state['evidence']['feature_matrix']
        self.train=state['fit_idx'].astype(int)-1;self.val=state['stop_idx'].astype(int)-1;self.test=state['held_idx'].astype(int)-1
        self.seed=int(state['seed']);self.n=len(self.e['omics_score'])

    def subset(self,idx):
        return {k:v[idx].copy() for k,v in self.e.items()}

def load_state(target,run,pipeline='final'):
    return loadmat(ROOT/'models'/target/f'run_{run:02d}'/f'{pipeline}_portable.mat',simplify_cells=True)['state']
