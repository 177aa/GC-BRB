#!/usr/bin/env python3
"""Locked population-explanation statistics; fixed models, identity-group clusters."""
import os
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix

HERE = Path(__file__).resolve().parent
PRIMARY = 'Insertion_vs_Uniform_Final'
SECONDARY = ['Insertion_vs_Confidence_Final', 'Trace_vs_Uniform_Rule',
             'Trace_vs_Discount_Rule', 'Trace_vs_Confidence_Rule']
METRICS = [PRIMARY, *SECONDARY]
STRATA = ['All', 'Ordinary', 'ConflictOnly', 'DisagreementOnly', 'BothHigh']


def macro(frame, columns):
    return frame.groupby(['Target', 'Run'])[columns].mean().groupby('Target').mean().mean()


def macro_array(values, run_targets):
    result = []
    for target in np.unique(run_targets):
        selected = values[:, run_targets == target]
        valid = np.isfinite(selected)
        count = valid.sum(axis=1)
        total = np.where(valid, selected, 0).sum(axis=1)
        result.append(np.divide(total, count, out=np.full(len(values), np.nan), where=count > 0))
    arr = np.column_stack(result)
    valid = np.isfinite(arr)
    return np.divide(np.where(valid, arr, 0).sum(axis=1), valid.sum(axis=1),
                     out=np.full(len(values), np.nan), where=valid.sum(axis=1) > 0)


def clustered_intervals(frame, metrics, replicates, seed):
    genes, gi = np.unique(frame.GroupID.to_numpy(), return_inverse=True)
    run_keys = list(frame[['Target', 'Run']].drop_duplicates().sort_values(['Target', 'Run']).itertuples(index=False, name=None))
    lookup = {key: j for j, key in enumerate(run_keys)}
    ri = np.array([lookup[x] for x in frame[['Target', 'Run']].itertuples(index=False, name=None)])
    shape = (len(genes), len(run_keys))
    denominator = coo_matrix((np.ones(len(frame)), (gi, ri)), shape=shape).tocsr()
    numerators = [coo_matrix((frame[col].to_numpy(), (gi, ri)), shape=shape).tocsr() for col in metrics]
    targets = np.array([x[0] for x in run_keys])
    n0 = np.asarray(denominator.sum(axis=0)).ravel()
    point = []
    for mat in numerators:
        value = np.asarray(mat.sum(axis=0)).ravel()
        means = np.divide(value, n0, out=np.full(len(n0), np.nan), where=n0 > 0)
        point.append(float(macro_array(means[None, :], targets)[0]))
    observed = macro(frame, metrics).to_numpy()
    if np.max(np.abs(np.array(point) - observed)) > 1e-12:
        raise ValueError('Sparse cluster statistic differs from task/run macro statistic')
    rng = np.random.default_rng(seed)
    samples = np.zeros((replicates, len(metrics)))
    for start in range(0, replicates, 100):
        count = min(100, replicates - start)
        weights = rng.multinomial(len(genes), np.full(len(genes), 1 / len(genes)), size=count)
        denom = np.asarray(weights @ denominator)
        for j, mat in enumerate(numerators):
            total = np.asarray(weights @ mat)
            means = np.divide(total, denom, out=np.full_like(total, np.nan), where=denom > 0)
            samples[start:start + count, j] = macro_array(means, targets)
    return {col: (point[j], float(np.nanquantile(samples[:, j], .025)),
                  float(np.nanquantile(samples[:, j], .975))) for j, col in enumerate(metrics)}


def cluster_sign_flip(frame, metric, replicates, seed):
    # Reference test under identity-group paired-sign exchangeability;
    # task/run records of a group receive the SAME sign in each permutation.
    run_counts = frame.groupby(['Target', 'Run']).size()
    runs_per_target = frame[['Target', 'Run']].drop_duplicates().groupby('Target').size()
    n_targets = frame.Target.nunique()
    row_weight = np.array([1 / (n_targets * runs_per_target[t] * run_counts[t, r])
                           for t, r in frame[['Target', 'Run']].itertuples(index=False, name=None)])
    contributions = pd.Series(frame[metric].to_numpy() * row_weight).groupby(frame.GroupID.to_numpy()).sum().to_numpy()
    observed = float(contributions.sum())
    if abs(observed - float(macro(frame, [metric]).iloc[0])) > 1e-12:
        raise ValueError('Permutation contribution weights do not reproduce the macro statistic')
    rng = np.random.default_rng(seed)
    exceed = 0
    for start in range(0, replicates, 200):
        count = min(200, replicates - start)
        sign = 2 * rng.integers(0, 2, size=(count, len(contributions)), dtype=np.int8) - 1
        values = sign @ contributions
        exceed += int(np.sum(np.abs(values) >= abs(observed) - 1e-15))
    return (1 + exceed) / (1 + replicates)


def bh(values):
    p = np.asarray(values, dtype=float)
    order = np.argsort(p)
    adj = np.minimum.accumulate((p[order] * len(p) / np.arange(1, len(p) + 1))[::-1])[::-1]
    out = np.empty_like(p)
    out[order] = np.clip(adj, 0, 1)
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, required=True)
    args = parser.parse_args()
    root = args.results.resolve()
    completion = json.loads((root / 'completion.json').read_text())
    if not completion['Completed'] or completion['Models'] != 30:
        raise ValueError('Do not summarize a partial30-model experiment')
    protocol = json.loads((root / 'locked_protocol.json').read_text())
    unit = pd.read_csv(root / 'all_group_units.csv')
    source = pd.read_csv(root / 'all_source_evidence.csv')
    folder = root / 'summary'
    folder.mkdir(exist_ok=True)
    bounds = []
    for cohort_no, cohort in enumerate(['test', 'candidate288']):
        for stratum_no, stratum in enumerate(STRATA):
            part = unit[(unit.Cohort == cohort) & unit.Eligible]
            if stratum != 'All':
                part = part[part.Stratum == stratum]
            if part.empty:
                continue
            estimate = clustered_intervals(part, METRICS, protocol['Inference']['ClusterBootstrap'],
                protocol['Inference']['Seed'] + cohort_no * 100 + stratum_no)
            for metric, (point, low, high) in estimate.items():
                bounds.append({'Cohort': cohort, 'Stratum': stratum, 'Metric': metric,
                               'MacroMeanPairedDifference': point, 'ClusterCI95Low': low, 'ClusterCI95High': high,
                               'IdentityGroups': part.GroupID.nunique(), 'ModelGroupObservations': len(part),
                               'Models': part[['Target', 'Run']].drop_duplicates().shape[0],
                               'Tasks': part.Target.nunique(), 'InferenceRole': 'primary' if cohort == 'test' and stratum == 'All' and metric == PRIMARY else 'secondary' if cohort == 'test' and stratum == 'All' else 'descriptive'})
            print('cluster intervals completed:', cohort, stratum, len(part), flush=True)
    estimates = pd.DataFrame(bounds)
    estimates['SignFlipReferenceP'] = np.nan
    estimates['SecondaryFamilyBHq'] = np.nan
    test = unit[(unit.Cohort == 'test') & unit.Eligible].copy()
    for j, metric in enumerate(METRICS):
        value = cluster_sign_flip(test, metric, protocol['Inference']['ClusterSignFlip'],
                                  protocol['Inference']['Seed'] + 1000 + j)
        select = (estimates.Cohort == 'test') & (estimates.Stratum == 'All') & (estimates.Metric == metric)
        estimates.loc[select, 'SignFlipReferenceP'] = value
    secondary = (estimates.Cohort == 'test') & (estimates.Stratum == 'All') & estimates.Metric.isin(SECONDARY)
    estimates.loc[secondary, 'SecondaryFamilyBHq'] = bh(estimates.loc[secondary, 'SignFlipReferenceP'])
    estimates.to_csv(folder / 'planned_comparisons_cluster_intervals.csv', index=False)

    diagnostic_columns = ['FinalUniformImpact', 'FinalInsertionImpact', 'FinalTraceImpact',
                          'FinalConfidenceImpact', 'FinalDiscountImpact', 'RuleUniformImpact',
                          'RuleInsertionImpact', 'RuleTraceImpact', 'RuleConfidenceImpact', 'RuleDiscountImpact',
                          'FinalRankConcordance', 'RuleRankConcordance', 'FinalSignAgreement', 'RuleSignAgreement',
                          'ERMaxConflict', 'BranchDisagreement', 'EvidenceQuality', 'UnknownMass',
                          'AlphaLR', 'CoverageFraction']
    diagnostic_rows = []
    for (cohort, stratum), part in unit[unit.Eligible].groupby(['Cohort', 'Stratum']):
        value = macro(part, diagnostic_columns).to_dict()
        diagnostic_rows.append({'Cohort': cohort, 'Stratum': stratum, 'Observations': len(part),
                                'UniqueGroups': part.GroupID.nunique(), **value})
    for cohort, part in unit[unit.Eligible].groupby('Cohort'):
        diagnostic_rows.append({'Cohort': cohort, 'Stratum': 'All', 'Observations': len(part),
                                'UniqueGroups': part.GroupID.nunique(), **macro(part, diagnostic_columns).to_dict()})
    pd.DataFrame(diagnostic_rows).to_csv(folder / 'group_trace_and_intervention_descriptions.csv', index=False)
    run_metrics = unit[unit.Eligible].groupby(['Cohort', 'Stratum', 'Target', 'Run'])[METRICS].mean().reset_index()
    run_metrics.to_csv(folder / 'per_run_planned_comparisons.csv', index=False)
    task = unit[unit.Eligible].groupby(['Cohort', 'Target', 'Run'])[METRICS].mean().groupby(['Cohort', 'Target']).mean().reset_index()
    task.to_csv(folder / 'task_planned_comparisons.csv', index=False)

    activation_cols = [c for c in unit if '_MeanActivation_' in c or '_Activation_' in c]
    rules = unit[unit.Eligible].groupby(['Cohort', 'Stratum', 'Target', 'Run'])[activation_cols].mean().groupby(['Cohort', 'Stratum', 'Target']).mean().groupby(['Cohort', 'Stratum']).mean()
    rules.to_csv(folder / 'macro_rule_activations_by_stratum.csv')
    # Informative five-seed explanations only; flat/tied-all priorities are explicitly excluded.
    stability = []
    for (target, cohort, gid), frame in source[source.Eligible].groupby(['Target', 'Cohort', 'GroupID']):
        per_run = frame.groupby('Run').InsertionInformative.first()
        if len(per_run) != 5 or not per_run.all():
            continue
        pivot = frame.pivot(index='Run', columns='Source', values='InsertionTopWeight').fillna(0)
        average = pivot.mean(axis=0)
        available_n = int(frame.groupby('Source').PresentFraction.max().gt(0).sum())
        agreement = [1 - .5 * np.abs(a - b).sum() for i, a in enumerate(pivot.to_numpy()) for b in pivot.to_numpy()[i+1:]]
        stability.append({'Target': target, 'Cohort': cohort, 'GroupID': gid,
                          'GeneSymbol': frame.GeneSymbol.iloc[0], 'AvailableSources': available_n,
                          'TopChoiceConcentration': float(average.max()), 'UniformChoiceConcentration': 1 / available_n,
                          'MeanPairwiseTopWeightAgreement': float(np.mean(agreement)),
                          'DominantSource': ';'.join(average.index[np.abs(average - average.max()) <= 1e-12])})
    stability = pd.DataFrame(stability)
    stability.to_csv(folder / 'five_seed_explanation_consistency.csv', index=False)

    examples = []
    selected = unit[(unit.Target == 'CPDB') & (unit.Run == 1) & unit.Eligible]
    for (cohort, stratum), frame in selected.groupby(['Cohort', 'Stratum']):
        frame = frame.copy()
        frame['SelectionHash'] = frame.GroupID.map(lambda g: hashlib.sha256(('20261029|' + str(g)).encode()).hexdigest())
        examples.extend(frame.sort_values('SelectionHash').GroupID.head(2).tolist())
    nr = selected.loc[selected.GeneSymbol.str.split(';').apply(lambda a: 'NR0B2' in a), 'GroupID'].tolist()
    examples = sorted(set(examples + nr))
    selected[selected.GroupID.isin(examples)].to_csv(folder / 'deterministically_selected_examples.csv', index=False)
    source[(source.Target == 'CPDB') & (source.Run == 1) & source.GroupID.isin(examples)].to_csv(folder / 'selected_example_source_traces.csv', index=False)

    counts = unit.groupby(['Cohort', 'Stratum']).agg(Observations=('GroupID', 'size'),
                 UniqueGroups=('GroupID', 'nunique'), EligibleObservations=('Eligible', 'sum')).reset_index()
    counts.to_csv(folder / 'stratum_counts.csv', index=False)
    validation = pd.read_csv(root / 'all_run_validation_and_cutoffs.csv')
    summary = {'CompleteModels': 30, 'TotalGroupModelObservations': len(unit),
               'TestModelGroupObservations': int((unit.Cohort == 'test').sum()),
               'UniqueTestGroups': int(unit.loc[unit.Cohort == 'test', 'GroupID'].nunique()),
               'EligibleTestObservations': int(((unit.Cohort == 'test') & unit.Eligible).sum()),
               'EligibleUniqueTestGroups': int(test.GroupID.nunique()),
               'CandidateModelGroupObservations': int((unit.Cohort == 'candidate288').sum()),
               'UniqueCandidates': int(unit.loc[unit.Cohort == 'candidate288', 'GroupID'].nunique()),
               'SourceGroupModelRows': len(source),
               'MaxSavedReplayError': float(validation.CleanSavedScoreAndFeatureMaxError.max()),
               'MaxFusionDecompositionError': float(validation.BranchDecompositionMaxError.max()),
               'ModelRefitting': False, 'RawGraphEditing': False,
               'PrimaryComparison': estimates[(estimates.Cohort == 'test') & (estimates.Stratum == 'All') & (estimates.Metric == PRIMARY)].iloc[0].to_dict(),
               'ConsistencyGroups': len(stability),
               'InferenceScope': 'identity-group resampling/sign-flip conditional on the fixed30 models and benchmark/network'}
    for key, value in summary['PrimaryComparison'].items():
        if isinstance(value, float) and not np.isfinite(value):
            summary['PrimaryComparison'][key] = None
    (folder / 'population_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False))


if __name__ == '__main__':
    main()
