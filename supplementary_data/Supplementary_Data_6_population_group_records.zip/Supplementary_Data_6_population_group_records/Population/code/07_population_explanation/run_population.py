#!/usr/bin/env python3
"""Population explanation using fixed GG_OOF_1_0 portable models; no fitting."""
import os
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
from pathlib import Path
import argparse
import hashlib
import io
import json
import re
import sys
import time
import zipfile

import numpy as np
import pandas as pd
from scipy.io import loadmat
from scipy.stats import rankdata

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'engine'))
from model_replay import Replay, NETWORKS, old

SCORES = [('Final', 'FinalProbability', 'final_score'),
          ('Rule', 'BackboneProbability', 'rule_score'),
          ('LR', 'ResidualProbability', 'lr_score')]
FIELDS = ('onehop', 'twohop', 'diffusion')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    os.replace(temporary, path)


def group_mean(values, inverse, n):
    values = np.asarray(values)
    shape = values.shape[1:]
    flat = values.reshape(len(values), -1)
    out = np.zeros((n, flat.shape[1]), dtype=float)
    np.add.at(out, inverse, flat)
    out /= np.bincount(inverse, minlength=n)[:, None]
    return out.reshape((n,) + shape)


def top_weights(priority, available):
    priority = np.asarray(priority, dtype=float)
    masked = np.where(available, priority, -np.inf)
    maxima = np.max(masked, axis=1, keepdims=True)
    selected = available & (np.abs(masked - maxima) <= 1e-12)
    count = selected.sum(axis=1)
    return np.divide(selected, count[:, None], out=np.zeros_like(priority), where=count[:, None] > 0)


def selected_mean(priority, impact, available):
    return np.sum(top_weights(priority, available) * impact, axis=1)


def rank_concordance(a, b, available):
    aa = rankdata(np.where(available, a, np.nan), axis=1, nan_policy='omit')
    bb = rankdata(np.where(available, b, np.nan), axis=1, nan_policy='omit')
    count = available.sum(axis=1)
    aa = np.where(available, aa - (count[:, None] + 1) / 2, 0)
    bb = np.where(available, bb - (count[:, None] + 1) / 2, 0)
    numerator = np.sum(aa * bb, axis=1)
    denominator = np.sqrt(np.sum(aa ** 2, axis=1) * np.sum(bb ** 2, axis=1))
    return np.divide(numerator, denominator, out=np.full(len(a), np.nan), where=denominator > 0)


class Archives:
    def __init__(self, directory, protocol):
        self.models = {}
        self.identity = None
        self.identity_hash = None
        self.validation = []
        protocol_targets = set()
        for path in sorted(directory.glob('*_MODELS_part*.zip')):
            target = re.match(r'^\d+_(.+)_MODELS_part\d+\.zip$', path.name).group(1)
            if target not in NETWORKS:
                continue
            with zipfile.ZipFile(path) as z:
                metadata_present = 'protocol.json' in z.namelist()
                if metadata_present:
                    manifest = json.loads(z.read('protocol.json'))
                    if manifest['BaseFingerprint'] != protocol['BaseFingerprint'] or manifest['CodeSHA256'] != protocol['CodeSHA256']:
                        raise ValueError('Unexpected scientific protocol: ' + path.name)
                    protocol_targets.add(target)
                    identity_bytes = z.read('identity_record_map.csv')
                    if self.identity_hash is None:
                        self.identity_hash = digest(identity_bytes)
                        self.identity = pd.read_csv(io.BytesIO(identity_bytes))
                    elif self.identity_hash != digest(identity_bytes):
                        raise ValueError('Identity record mapping differs: ' + path.name)
                for name in z.namelist():
                    match = re.fullmatch(r'run_(\d\d)/final_portable\.mat', name)
                    if match:
                        key = (target, int(match.group(1)))
                        if key in self.models:
                            raise ValueError('Duplicate portable final model: ' + str(key))
                        self.models[key] = (path, name)
                self.validation.append({'archive': path.name, 'bytes': path.stat().st_size,
                                        'protocol_metadata_present': metadata_present,
                                        'metadata_protocol_ok': True if metadata_present else None,
                                        'identity_mapping_sha256': self.identity_hash})
        expected = {(t, r) for t in NETWORKS for r in range(1, 6)}
        if set(self.models) != expected:
            raise ValueError('Expected all30 models; missing=' + str(expected - set(self.models)))
        if protocol_targets != set(NETWORKS):
            raise ValueError('Protocol metadata missing for one or more tasks')
        if not np.array_equal(self.identity.GlobalIndex.to_numpy(), np.arange(1, len(self.identity) + 1)):
            raise ValueError('Identity order is not the original GlobalIndex order')

    def load(self, target, run):
        path, member = self.models[target, run]
        with zipfile.ZipFile(path) as z:
            data = z.read(member)  # zipfile verifies this member's CRC.
        state = loadmat(io.BytesIO(data), simplify_cells=True)['state']
        return state, {'archive': path.name, 'member': member, 'member_sha256': digest(data)}


def process_one(target, run, state, identity, candidates, folder, protocol):
    engine = Replay(state)
    if state['base_fingerprint'] != protocol['BaseFingerprint']:
        raise ValueError('Portable state has another scientific fingerprint')
    ids = identity.GroupID.to_numpy(dtype=int)
    labels = identity.Label.to_numpy(dtype=float)
    test = engine.test
    validation = engine.val
    if not np.isfinite(labels[test]).all() or not set(np.unique(labels[test])) <= {0., 1.}:
        raise ValueError('Held-out primary cohort contains missing/invalid labels')
    if set(ids[engine.train]) & set(ids[test]) or set(ids[validation]) & set(ids[test]) or set(ids[engine.train]) & set(ids[validation]):
        raise ValueError('Identity groups overlap across Fit/Stop/Test')
    candidate_rows = np.flatnonzero(np.isin(ids, candidates.GroupID))
    if np.isfinite(labels[candidate_rows]).any():
        raise ValueError('Fixed candidate list contains labelled records')
    selection = np.unique(np.r_[test, candidate_rows])
    clean_e = engine.subset(selection)
    clean = engine.score(clean_e)
    validation_e = engine.subset(validation)
    val = engine.score(validation_e)
    errors = []
    for _, output, saved in SCORES:
        errors.append(float(np.max(np.abs(clean[output] - np.asarray(state[saved]).ravel()[selection]))))
        errors.append(float(np.max(np.abs(val[output] - np.asarray(state[saved]).ravel()[validation]))))
    errors.append(float(np.max(np.abs(clean['features'] - engine.F[selection]))))
    errors.append(float(np.max(np.abs(val['features'] - engine.F[validation]))))
    if max(errors) > 1e-10:
        raise ValueError('Saved-score/37D replay failed: ' + str(max(errors)))

    groups, inverse = np.unique(ids[selection], return_inverse=True)
    n = len(groups)
    gm = lambda values: group_mean(values, inverse, n)
    record_count = np.bincount(inverse)
    member_present = np.asarray(clean_e['presence'], dtype=bool)
    presence = gm(member_present)
    available = presence > 0
    source_count = available.sum(axis=1)
    cohort = np.where(np.isin(groups, ids[test]), 'test', 'candidate288')
    if np.sum(cohort == 'candidate288') != 288:
        raise ValueError('Expected288 current candidate groups')
    # Aggregate validation records BEFORE determining group-level cutoffs.
    vg, vi = np.unique(ids[validation], return_inverse=True)
    vm = lambda values: group_mean(values, vi, len(vg))
    vpresence = vm(validation_e['presence']) > 0
    veligible = vpresence.sum(axis=1) >= 2
    vconflict = vm(val['ERMaxConflict'])
    vdisagreement = np.abs(vm(val['BackboneProbability']) - vm(val['ResidualProbability']))
    if not veligible.any():
        raise ValueError('No eligible validation identity groups')
    cut_conflict = float(np.quantile(vconflict[veligible], .8, method='linear'))
    cut_disagreement = float(np.quantile(vdisagreement[veligible], .8, method='linear'))
    conflict = gm(clean['ERMaxConflict'])
    disagreement = np.abs(gm(clean['BackboneProbability']) - gm(clean['ResidualProbability']))
    high_c = conflict > cut_conflict
    high_d = disagreement > cut_disagreement
    stratum = np.select([high_c & high_d, high_c, high_d],
                        ['BothHigh', 'ConflictOnly', 'DisagreementOnly'], default='Ordinary')

    reference_e = {k: v.copy() for k, v in clean_e.items()}
    for field in FIELDS:
        reference_e[field][:, :] = .5
    reference = engine.score(reference_e)
    insertion = {name: np.zeros((n, 6)) for name, _, _ in SCORES}
    deletion = {name: np.zeros((n, 6)) for name, _, _ in SCORES}
    for j, source in enumerate(NETWORKS):
        restored = {k: v.copy() for k, v in reference_e.items()}
        removed = {k: v.copy() for k, v in clean_e.items()}
        for field in FIELDS:
            restored[field][:, j] = clean_e[field][:, j]
            removed[field][:, j] = .5
        ins = engine.score(restored)
        rem = engine.score(removed)
        for name, output, _ in SCORES:
            insertion[name][:, j] = gm(ins[output] - reference[output])
            deletion[name][:, j] = gm(clean[output] - rem[output])
    alpha = float(engine.alpha)
    fusion_errors = [float(np.max(np.abs(v['Final'] - (1 - alpha) * v['Rule'] - alpha * v['LR']))) for v in (insertion, deletion)]
    if max(fusion_errors) > 1e-10:
        raise ValueError('Branch decomposition failed')
    for values in [*insertion.values(), *deletion.values()]:
        if np.max(np.abs(values[~available]), initial=0.) > 1e-10:
            raise ValueError('Absent source unexpectedly affected support intervention')

    discount_record = np.clip(clean_e['confidence'] * member_present * engine.reliability, 0, 1)
    strength = gm(discount_record * np.abs(clean['network_score'] - .5))
    discount = gm(discount_record)
    confidence = gm(clean_e['confidence'])
    acts1 = np.zeros((len(selection), 6, 9))
    acts2 = np.zeros_like(acts1)
    for j in range(6):
        local, a1 = old.brb(np.column_stack([clean_e['onehop'][:, j], clean_e['twohop'][:, j]]),
                           engine.refs, engine.ants, engine.par[0], engine.eps)
        network, a2 = old.brb(np.column_stack([clean_e['diffusion'][:, j], local]),
                             engine.refs, engine.ants, engine.par[1], engine.eps)
        if np.max(np.abs(network - clean['network_score'][:, j])) > 1e-12:
            raise ValueError('Activation replay mismatch')
        acts1[:, j], acts2[:, j] = a1, a2
    grouped_a1, grouped_a2, grouped_a3 = gm(acts1), gm(acts2), gm(clean['BRB3Activation'])
    unit = pd.DataFrame({'Target': target, 'Run': run, 'FinalPipelineSeed': engine.seed,
                         'GroupID': groups, 'Cohort': cohort, 'RecordCount': record_count,
                         'PresentSourcesN': source_count, 'CoverageFraction': presence.mean(axis=1),
                         'Eligible': source_count >= 2, 'Stratum': stratum,
                         'HighConflict': high_c, 'HighDisagreement': high_d,
                         'ERMaxConflict': conflict, 'BranchDisagreement': disagreement,
                         'UnknownMass': gm(clean['UnknownMass']), 'EvidenceQuality': gm(clean['EvidenceQuality']),
                         'AlphaLR': alpha})
    symbol_map = identity.groupby('GroupID').SymbolNormalized.agg(lambda x: ';'.join(sorted(set(x.dropna().astype(str)))))
    ensembl_n = identity.groupby('GroupID').EnsemblID.agg(lambda x: len(set(x.dropna().astype(str))))
    unit['GeneSymbol'] = unit.GroupID.map(symbol_map)
    unit['MultiEnsemblGroup'] = unit.GroupID.map(ensembl_n).gt(1)
    unit['Label'] = pd.Series(labels[selection]).groupby(inverse).first().to_numpy()
    for name, output, _ in SCORES:
        impact = np.abs(deletion[name])
        uniform = np.sum(impact * available, axis=1) / np.maximum(source_count, 1)
        chosen_insertion = selected_mean(np.abs(insertion[name]), impact, available)
        chosen_strength = selected_mean(strength, impact, available)
        chosen_discount = selected_mean(discount, impact, available)
        chosen_confidence = selected_mean(confidence, impact, available)
        unit[name + 'Clean'] = gm(clean[output])
        unit[name + 'Reference'] = gm(reference[output])
        for label, value in [('UniformImpact', uniform), ('InsertionImpact', chosen_insertion),
                             ('TraceImpact', chosen_strength), ('DiscountImpact', chosen_discount),
                             ('ConfidenceImpact', chosen_confidence)]:
            unit[name + label] = value
        unit[name + 'RankConcordance'] = rank_concordance(np.abs(insertion[name]), impact, available)
        valid_sign = available & (np.abs(insertion[name]) > 1e-8) & (np.abs(deletion[name]) > 1e-8)
        sign_n = valid_sign.sum(axis=1)
        agree_n = ((np.sign(insertion[name]) == np.sign(deletion[name])) & valid_sign).sum(axis=1)
        unit[name + 'SignN'] = sign_n
        unit[name + 'SignAgreement'] = np.divide(agree_n, sign_n, out=np.full(n, np.nan), where=sign_n > 0)
    unit['Insertion_vs_Uniform_Final'] = unit.FinalInsertionImpact - unit.FinalUniformImpact
    unit['Insertion_vs_Confidence_Final'] = unit.FinalInsertionImpact - unit.FinalConfidenceImpact
    unit['Trace_vs_Uniform_Rule'] = unit.RuleTraceImpact - unit.RuleUniformImpact
    unit['Trace_vs_Discount_Rule'] = unit.RuleTraceImpact - unit.RuleDiscountImpact
    unit['Trace_vs_Confidence_Rule'] = unit.RuleTraceImpact - unit.RuleConfidenceImpact
    unit['Trace_vs_Uniform_Final_descriptive'] = unit.FinalTraceImpact - unit.FinalUniformImpact
    for k in range(9):
        for layer, activation in [('BRB1', grouped_a1), ('BRB2', grouped_a2)]:
            unit[layer + '_MeanActivation_' + str(k + 1)] = np.sum(activation[:, :, k] * presence, axis=1) / np.maximum(presence.sum(axis=1), 1e-12)
        unit['BRB3_Activation_' + str(k + 1)] = grouped_a3[:, k]

    top_i = top_weights(np.abs(insertion['Final']), available)
    top_t = top_weights(strength, available)
    max_i = np.max(np.where(available, np.abs(insertion['Final']), -np.inf), axis=1)
    min_i = np.min(np.where(available, np.abs(insertion['Final']), np.inf), axis=1)
    unit['InsertionInformative'] = (max_i - min_i) > 1e-12
    source_rows = []
    for j, source in enumerate(NETWORKS):
        d = unit[['Target', 'Run', 'GroupID', 'Cohort', 'GeneSymbol', 'Eligible', 'Stratum', 'InsertionInformative']].copy()
        d['Source'] = source
        d['PresentFraction'] = presence[:, j]
        d['Confidence'] = confidence[:, j]
        d['ReliabilityParameter'] = float(engine.reliability[j])
        d['EffectiveDiscount'] = discount[:, j]
        d['BRB1Score'] = gm(clean['local_topology'])[:, j]
        d['BRB2Score'] = gm(clean['network_score'])[:, j]
        d['TraceStrength'] = strength[:, j]
        d['InsertionTopWeight'] = top_i[:, j]
        d['TraceTopWeight'] = top_t[:, j]
        for name, _, _ in SCORES:
            d[name + 'InsertionDelta'] = insertion[name][:, j]
            d[name + 'DeletionDelta'] = deletion[name][:, j]
        source_rows.append(d)
    folder.mkdir(parents=True, exist_ok=True)
    unit.to_csv(folder / 'group_units.csv', index=False)
    pd.concat(source_rows, ignore_index=True).to_csv(folder / 'source_evidence.csv', index=False)
    np.savez_compressed(folder / 'activations_and_interventions.npz', GroupID=groups,
                        Cohort=cohort, SourceOrder=np.array(NETWORKS),
                        BRB1Activation=grouped_a1, BRB2Activation=grouped_a2, BRB3Activation=grouped_a3,
                        RuleAntecedents=engine.ants + 1, PresentFraction=presence,
                        FinalInsertion=insertion['Final'], FinalDeletion=deletion['Final'],
                        RuleInsertion=insertion['Rule'], RuleDeletion=deletion['Rule'],
                        LRInsertion=insertion['LR'], LRDeletion=deletion['LR'])
    info = {'Target': target, 'Run': run, 'FinalPipelineSeed': engine.seed,
            'ValidationGroups': len(vg), 'EligibleValidationGroups': int(veligible.sum()),
            'ConflictCutoff': cut_conflict, 'DisagreementCutoff': cut_disagreement,
            'TestGroups': int(np.sum(cohort == 'test')), 'CandidateGroups': int(np.sum(cohort == 'candidate288')),
            'EligibleTestGroups': int(np.sum((cohort == 'test') & (source_count >= 2))),
            'CleanSavedScoreAndFeatureMaxError': max(errors), 'BranchDecompositionMaxError': max(fusion_errors),
            'FinalAlphaLR': alpha, 'ModelRefitting': False}
    return info


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archives', type=Path, required=True, help='Directory holding the12 original *_MODELS_part*.zip files')
    parser.add_argument('--output', type=Path, required=True, help='NEW experiment result directory')
    parser.add_argument('--resume', action='store_true', help='Resume only the same locked protocol and runner')
    parser.add_argument('--limit', type=int, help='Implementation validation only; partial output is never marked complete')
    args = parser.parse_args()
    protocol_bytes = (HERE / 'protocol.json').read_bytes()
    protocol = json.loads(protocol_bytes)
    for name, expected in protocol['EngineSourceSHA256'].items():
        if digest((HERE / 'engine' / name).read_bytes()) != expected:
            raise ValueError('Audited replay engine has changed')
    signature = {'ProtocolSHA256': digest(protocol_bytes), 'RunnerSHA256': digest(Path(__file__).read_bytes()),
                 'CandidatesSHA256': digest((HERE / 'candidates_288.csv').read_bytes())}
    out = args.output.resolve()
    if out.exists() and not args.resume:
        raise FileExistsError('Use a NEW output directory, or explicitly resume this same experiment')
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'experiment_signature.json').exists():
        if json.loads((out / 'experiment_signature.json').read_text()) != signature:
            raise ValueError('This output belongs to different code/protocol/inputs')
    else:
        write_json(out / 'experiment_signature.json', signature)
        (out / 'locked_protocol.json').write_bytes(protocol_bytes)
    catalog = Archives(args.archives.resolve(), protocol)
    write_json(out / 'input_archive_validation.json', catalog.validation)
    candidates = pd.read_csv(HERE / 'candidates_288.csv')
    if len(candidates) != 288 or candidates.GroupID.duplicated().any():
        raise ValueError('Invalid fixed288 candidate list')
    completed = []
    start = time.monotonic()
    keys = [(target, run) for target in NETWORKS for run in range(1, 6)]
    for number, (target, run) in enumerate(keys, 1):
        if args.limit and number > args.limit:
            break
        folder = out / 'per_run' / target / ('run_%02d' % run)
        checkpoint = folder / 'completed.json'
        if checkpoint.exists():
            info = json.loads(checkpoint.read_text())
            state_path, member = catalog.models[target, run]
            with zipfile.ZipFile(state_path) as z:
                current_sha = digest(z.read(member))
            if info['input']['member_sha256'] != current_sha:
                raise ValueError('Saved model bytes changed since the checkpoint')
        else:
            t = time.monotonic()
            state, provenance = catalog.load(target, run)
            info = process_one(target, run, state, catalog.identity, candidates, folder, protocol)
            info['input'] = provenance
            info['seconds'] = round(time.monotonic() - t, 3)
            write_json(checkpoint, info)
            del state
        completed.append(info)
        write_json(out / 'progress.json', {'CompletedModels': len(completed), 'ExpectedModels': 30,
                                          'ModelTrainingPerformed': False, 'LastModel': [target, run]})
        print('%s run_%02d complete: test=%d, candidates=%d, replay_error=%.3g, %.1fs' %
              (target, run, info['TestGroups'], info['CandidateGroups'], info['CleanSavedScoreAndFeatureMaxError'], info['seconds']), flush=True)
    pd.DataFrame([{k: v for k, v in r.items() if k != 'input'} for r in completed]).to_csv(out / 'all_run_validation_and_cutoffs.csv', index=False)
    if len(completed) == 30:
        unit = pd.concat([pd.read_csv(p) for p in sorted((out / 'per_run').glob('*/*/group_units.csv'))], ignore_index=True)
        source = pd.concat([pd.read_csv(p) for p in sorted((out / 'per_run').glob('*/*/source_evidence.csv'))], ignore_index=True)
        if unit.duplicated(['Target', 'Run', 'Cohort', 'GroupID']).any():
            raise ValueError('Duplicate model/group observations')
        unit.to_csv(out / 'all_group_units.csv', index=False)
        source.to_csv(out / 'all_source_evidence.csv', index=False)
    write_json(out / 'completion.json', {'Completed': len(completed) == 30, 'Models': len(completed),
        'ModelTrainingPerformed': False, 'OriginalScientificFilesWritten': False,
        'Seconds': round(time.monotonic() - start, 3), 'ProtocolSHA256': signature['ProtocolSHA256']})
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
