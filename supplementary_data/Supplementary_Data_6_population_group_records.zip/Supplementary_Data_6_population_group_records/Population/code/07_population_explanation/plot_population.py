#!/usr/bin/env python3
"""Exact scientific SVGs. All editable text explicitly specifies Times New Roman."""
from pathlib import Path
import argparse
import logging
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

BLUE = '#4C9AC9'
CORAL = '#E2745E'
INK = '#161616'
logging.getLogger('matplotlib.font_manager').setLevel(logging.ERROR)
plt.rcParams.update({'font.family': 'Times New Roman', 'font.size': 8.5,
                     'axes.titlesize': 9, 'axes.labelsize': 8.5,
                     'svg.fonttype': 'none', 'axes.labelcolor': INK, 'text.color': INK,
                     'xtick.color': INK, 'ytick.color': INK, 'axes.edgecolor': INK,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.unicode_minus': False, 'savefig.facecolor': 'white'})


def save(fig, path, preview):
    fig.savefig(path, format='svg', bbox_inches='tight', metadata={'Creator': 'GC-BRB population explanation; deterministic saved data'})
    # Preview is internal QA; it uses the renderer's available font fallback.
    fig.savefig(preview, dpi=180, bbox_inches='tight')
    plt.close(fig)


def forest(ax, data, metrics, labels, color):
    for i, metric in enumerate(metrics):
        row = data[data.Metric == metric].iloc[0]
        point, low, high = row.MacroMeanPairedDifference, row.ClusterCI95Low, row.ClusterCI95High
        ax.errorbar(point, i, xerr=[[point-low], [high-point]], fmt='o', color=color,
                    ecolor=color, capsize=3, markersize=5, linewidth=1.5)
    ax.axvline(0, color=INK, lw=.8)
    ax.set_yticks(range(len(labels)), labels)
    ax.invert_yaxis()
    ax.set_xlabel('Paired difference in |score change|')
    ax.grid(axis='x', color='#E2E2E2', lw=.5)
    ax.set_axisbelow(True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--results', type=Path, required=True)
    p.add_argument('--preview-dir', type=Path, required=True)
    a = p.parse_args()
    s = a.results / 'summary'
    output = a.results / 'figures'
    output.mkdir(exist_ok=True)
    a.preview_dir.mkdir(parents=True, exist_ok=True)
    comparisons = pd.read_csv(s / 'planned_comparisons_cluster_intervals.csv')
    data = comparisons[(comparisons.Cohort == 'test') & (comparisons.Stratum == 'All')]
    unit = pd.read_csv(a.results / 'all_group_units.csv')
    strata = ['Ordinary', 'ConflictOnly', 'DisagreementOnly', 'BothHigh']
    names = ['Ordinary', 'High conflict only', 'High disagreement only', 'Both high']
    fig, axes = plt.subplots(2, 2, figsize=(7.5, 6.3))
    fig.subplots_adjust(left=.21, right=.98, bottom=.15, top=.94, wspace=.85, hspace=.62)
    proportions = []
    d = unit[(unit.Cohort == 'test') & unit.Eligible]
    for stratum in strata:
        m = d.assign(flag=d.Stratum.eq(stratum)).groupby(['Target', 'Run']).flag.mean().groupby('Target').mean().mean()
        proportions.append(m)
    ax = axes[0, 0]
    ax.barh(np.arange(4), proportions, color=[BLUE, CORAL, '#8BBBD5', '#EDAA9B'], edgecolor=INK, linewidth=.4)
    ax.set_yticks(np.arange(4), names)
    ax.invert_yaxis()
    ax.set_xlabel('Macro fraction of eligible test groups')
    ax.set_xlim(0, max(proportions) * 1.18)
    for i, value in enumerate(proportions):
        ax.text(value + .007, i, '%.1f%%' % (100*value), va='center', color=INK)
    ax.set_title('A  Validation-defined strata', loc='left', fontweight='bold')
    forest(axes[0, 1], data,
           ['Insertion_vs_Uniform_Final', 'Insertion_vs_Confidence_Final'],
           ['vs uniform', 'vs confidence'], BLUE)
    axes[0, 1].set_title('B  Final-score source priority', loc='left', fontweight='bold')
    forest(axes[1, 0], data,
           ['Trace_vs_Uniform_Rule', 'Trace_vs_Discount_Rule', 'Trace_vs_Confidence_Rule'],
           ['vs uniform', 'vs discount', 'vs confidence'], CORAL)
    axes[1, 0].set_title('C  Rule trace strength', loc='left', fontweight='bold')
    task = pd.read_csv(s / 'task_planned_comparisons.csv')
    task = task[task.Cohort == 'test'].set_index('Target').loc[['CPDB','MULTINET','PCNET','STRINGdb','IREF','IREF_2015']]
    ax = axes[1, 1]
    ax.barh(np.arange(6)-.18, task.Insertion_vs_Uniform_Final, height=.34,
            color=BLUE, edgecolor=INK, linewidth=.4, label='Insertion vs uniform (final)')
    ax.barh(np.arange(6)+.18, task.Trace_vs_Discount_Rule, height=.34,
            color=CORAL, edgecolor=INK, linewidth=.4, label='Trace vs discount (rule)')
    ax.set_yticks(np.arange(6), task.index)
    ax.invert_yaxis()
    ax.axvline(0, color=INK, lw=.8)
    ax.set_xlabel('Paired difference in |score change|')
    ax.legend(frameon=False, fontsize=8, loc='upper right', bbox_to_anchor=(1,-.3))
    ax.set_title('D  Task-level paired contrasts', loc='left', fontweight='bold')
    save(fig, output / 'Population_explanation_FigA.svg', a.preview_dir / 'FigA.png')

    rules = pd.read_csv(s / 'macro_rule_activations_by_stratum.csv')
    rules = rules[rules.Cohort == 'test'].set_index('Stratum').reindex(strata)
    cmap = LinearSegmentedColormap.from_list('gcbrb_blue', ['#FFFFFF', '#D4E7F2', BLUE, '#225573'])
    fig, axes = plt.subplots(3, 1, figsize=(7.5, 6.0))
    fig.subplots_adjust(left=.25, right=.91, bottom=.12, top=.95, hspace=.52)
    first_activation = next((a.results/'per_run').glob('*/*/activations_and_interventions.npz'))
    with np.load(first_activation,allow_pickle=False) as z:
        antecedents=z['RuleAntecedents']
    states={1:'L',2:'M',3:'H'}
    labels=[states[int(left)]+'/'+states[int(right)] for left,right in antecedents]
    for j, layer in enumerate(['BRB1', 'BRB2', 'BRB3']):
        cols = [(layer + '_MeanActivation_' if layer != 'BRB3' else layer + '_Activation_') + str(i) for i in range(1,10)]
        value = rules[cols].to_numpy()
        image = axes[j].pcolormesh(np.arange(10)-.5, np.arange(5)-.5, value,
                                   vmin=0, vmax=1, cmap=cmap, shading='flat',
                                   edgecolors='none', rasterized=False)
        axes[j].set_xlim(-.5,8.5)
        axes[j].set_ylim(3.5,-.5)
        axes[j].set_xticks(np.arange(9), labels)
        axes[j].set_yticks(np.arange(4), names)
        axes[j].set_title(layer, fontweight='bold',loc='left')
        for row in range(4):
            for col in range(9):
                axes[j].text(col, row, '%.2f' % value[row,col], ha='center',va='center',
                             fontsize=8, color='white' if value[row,col] > .6 else INK)
    axes[-1].set_xlabel('Antecedent states (L: low, M: medium, H: high)')
    cax = fig.add_axes([.935,.19,.015,.65])
    bar = fig.colorbar(image,cax=cax)
    bar.solids.set_rasterized(False)
    bar.set_label('Mean rule activation')
    save(fig, output / 'Population_explanation_FigB.svg', a.preview_dir / 'FigB.png')


if __name__ == '__main__':
    main()
