#!/usr/bin/env python3
"""Independent saved-table checks; no models fitted or forward inference run."""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.stats import false_discovery_control
from xml.etree import ElementTree as ET


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, required=True)
    args = parser.parse_args()
    root = args.results
    key = ['Target', 'Run', 'Cohort', 'GroupID']
    u = pd.read_csv(root / 'all_group_units.csv').sort_values(key).reset_index(drop=True)
    s = pd.read_csv(root / 'all_source_evidence.csv').sort_values(key + ['Source']).reset_index(drop=True)
    checks = {}
    checks['one_unit_per_model_cohort_identity'] = not u.duplicated(key).any()
    checks['six_source_rows_per_unit'] = len(s) == 6 * len(u) and bool(s.groupby(key).size().eq(6).all())
    source_keys = s[key].iloc[::6].reset_index(drop=True)
    checks['source_and_unit_pairing'] = source_keys.equals(u[key])
    a = s.PresentFraction.to_numpy().reshape(-1,6) > 0
    choose = lambda score, effect: np.sum(
        np.isclose(np.where(a,score,-np.inf),np.max(np.where(a,score,-np.inf),axis=1)[:,None],rtol=0,atol=1e-12)
        * a * effect,axis=1) / np.sum(
        np.isclose(np.where(a,score,-np.inf),np.max(np.where(a,score,-np.inf),axis=1)[:,None],rtol=0,atol=1e-12) * a,axis=1)
    df = np.abs(s.FinalDeletionDelta.to_numpy().reshape(-1,6))
    dr = np.abs(s.RuleDeletionDelta.to_numpy().reshape(-1,6))
    ins = np.abs(s.FinalInsertionDelta.to_numpy().reshape(-1,6))
    strength = s.TraceStrength.to_numpy().reshape(-1,6)
    conf = s.Confidence.to_numpy().reshape(-1,6)
    discount = s.EffectiveDiscount.to_numpy().reshape(-1,6)
    uniform_f = np.sum(df*a,axis=1)/a.sum(axis=1)
    uniform_r = np.sum(dr*a,axis=1)/a.sum(axis=1)
    independent = {
        'Insertion_vs_Uniform_Final':choose(ins,df)-uniform_f,
        'Insertion_vs_Confidence_Final':choose(ins,df)-choose(conf,df),
        'Trace_vs_Uniform_Rule':choose(strength,dr)-uniform_r,
        'Trace_vs_Discount_Rule':choose(strength,dr)-choose(discount,dr),
        'Trace_vs_Confidence_Rule':choose(strength,dr)-choose(conf,dr)}
    errors={col:float(np.max(np.abs(value-u[col].to_numpy()))) for col,value in independent.items()}
    checks['all_five_paired_metrics_recomputed_from_long_source_table']=max(errors.values())<1e-12
    checks['eligibility_matches_available_sources']=bool(np.array_equal(u.Eligible.to_numpy(),a.sum(axis=1)>=2))
    signatures=json.loads((root/'experiment_signature.json').read_text())
    checks['locked_protocol_hash']=hashlib.sha256((root/'locked_protocol.json').read_bytes()).hexdigest()==signatures['ProtocolSHA256']
    validation=pd.read_csv(root/'all_run_validation_and_cutoffs.csv')
    checks['all30_replays_below_1e10']=len(validation)==30 and validation.CleanSavedScoreAndFeatureMaxError.max()<1e-10
    checks['fusion_branch_identity_below_1e10']=validation.BranchDecompositionMaxError.max()<1e-10
    alpha=np.repeat(u.AlphaLR.to_numpy(),6)
    fusion=[]
    for kind in ['Insertion','Deletion']:
        fusion.append(float(np.max(np.abs(s['Final'+kind+'Delta']-(1-alpha)*s['Rule'+kind+'Delta']-alpha*s['LR'+kind+'Delta']))))
    checks['long_table_branch_decomposition']=max(fusion)<1e-12
    activation_error=0.
    nfiles=0
    antecedents=[]
    for path in sorted((root/'per_run').glob('*/*/activations_and_interventions.npz')):
        with np.load(path,allow_pickle=False) as z:
            antecedents.append(z['RuleAntecedents'].tolist())
            for column in ['BRB1Activation','BRB2Activation','BRB3Activation']:
                activation_error=max(activation_error,float(np.max(np.abs(z[column].sum(axis=-1)-1))))
        nfiles+=1
    checks['all30_rule_activation_files_normalized']=nfiles==30 and activation_error<1e-12
    checks['rule_antecedent_labels_identical_in30_models']=nfiles==30 and all(a==antecedents[0] for a in antecedents)
    comparisons=pd.read_csv(root/'summary/planned_comparisons_cluster_intervals.csv')
    full=comparisons[(comparisons.Cohort=='test')&(comparisons.Stratum=='All')]
    primary=u[(u.Cohort=='test')&u.Eligible]
    macro_errors=[]
    for col in independent:
        means=[]
        for target,d in primary.groupby('Target'):
            means.append(np.mean([r[col].mean() for _,r in d.groupby('Run')]))
        recorded=float(full.loc[full.Metric==col,'MacroMeanPairedDifference'].iloc[0])
        macro_errors.append(abs(float(np.mean(means))-recorded))
    checks['equal_task_equal_run_macro_recomputed']=max(macro_errors)<1e-12
    secondary=full[full.Metric!='Insertion_vs_Uniform_Final']
    checks['four_secondary_BH_values']=bool(np.allclose(false_discovery_control(secondary.SignFlipReferenceP.to_numpy()),secondary.SecondaryFamilyBHq.to_numpy(),atol=1e-12,rtol=0))
    cohort= u[u.Cohort=='candidate288']
    checks['fixed288_each_of30_models']=bool(cohort.groupby(['Target','Run']).GroupID.nunique().eq(288).all())
    checks['four_strata_partition_eligible_test']=int(primary.groupby('Stratum').size().sum())==len(primary)
    svg_checks={}
    for path in sorted((root/'figures').glob('*.svg')):
        tree=ET.parse(path)
        text=tree.findall('.//{http://www.w3.org/2000/svg}text')
        svg_checks[path.name]={'text_elements':len(text),'all_times_new_roman':all('Times New Roman' in node.attrib.get('style','') for node in text),
                               'embedded_raster_images':len(tree.findall('.//{http://www.w3.org/2000/svg}image'))}
    if svg_checks:
        checks['editable_roman_text_and_vector_figures']=all(v['all_times_new_roman'] and v['embedded_raster_images']==0 for v in svg_checks.values())
    result={'checks':{k:bool(v) for k,v in checks.items()},'all_passed':all(checks.values()),
            'maximum_metric_recomputation_errors':errors,'activation_sum_max_error':activation_error,
            'branch_table_max_error':max(fusion),'macro_recomputation_max_error':max(macro_errors),
            'svg_checks':svg_checks,'scope':'Saved numerical records only; no refitting or new model inference'}
    (root/'summary/independent_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))
    if not result['all_passed']:
        raise SystemExit(1)


if __name__=='__main__':
    main()
