Supplementary Data 7 | Source-level intervention records
Contains the complete source-level population evidence and intervention records from the original 29 October Supplementary Data 6 archive, with its saved protocol and completion record. Group-level outputs, analysis code and summary tables are in Supplementary Data 6. The intervention neutralizes support evidence in fixed models; it does not refit models or physically edit network edges. Source bytes are unchanged.

File-level provenance and SHA-256 checksums are in MANIFEST.csv.
