Supplementary Data 5 | Candidate thresholds and sensitivity
The 13,603-row saved candidate table includes support counts, scores, database flags and later-catalog membership. The 288-member S7 list matches it exactly. The 30-run results include 29 valid high-precision thresholds. The seven rows of S84 were independently checked against the stored candidate table for candidate counts, overlap, Jaccard index, three-database union and later-catalog counts. S61 and S6 are transcribed from the current Supplement; the S6 thresholds were checked against saved runs. The 9,600 source-missing records are per model/run/source mask metrics, not per-gene predictions. Analyses were not rerun.

File-level provenance and SHA-256 checksums are in MANIFEST.csv.
