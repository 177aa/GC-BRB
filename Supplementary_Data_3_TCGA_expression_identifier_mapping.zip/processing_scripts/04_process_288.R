# Called only in the isolated child process; all out() paths are new outputs.
source('00_config.R')
genes <- readRDS(out('input','candidates.rds'))
clinical <- readRDS(out('clinical','clinical.rds'))
stopifnot(nrow(genes)==288L,!anyDuplicated(genes$GeneSymbol),!anyDuplicated(genes$EnsemblID))
qc <- list(); annotation_rows <- list()
for(project in PROJECTS) {

 # Reuse only complete checkpoints produced by the same scientific code and
 # unchanged raw inputs; missing or half-written projects are computed normally.
 previous_files <- file.path(RESUME_PROCESSED_ROOT,paste0(project,c('.rds','_expression288.csv.gz','_clinical.csv','_gene_mapping.csv','_normalization.csv','_sample_selection.csv')))
 if(all(file.exists(previous_files))) {
  source_md5 <- tools::md5sum(previous_files)
  obj <- readRDS(previous_files[1])
  stopifnot(is.matrix(obj$expression),is.data.frame(obj$clinical),is.data.frame(obj$mapping),
   identical(colnames(obj$expression),as.character(genes$GeneSymbol)),
   identical(as.character(obj$mapping$GeneSymbol),as.character(genes$GeneSymbol)),
   identical(as.character(obj$mapping$EnsemblID),as.character(genes$EnsemblID)),
   identical(rownames(obj$expression),as.character(obj$clinical$patient)),
   !anyDuplicated(obj$clinical$patient),all(as.character(obj$clinical$project)==project))
  portable_x <- read.csv(previous_files[2],stringsAsFactors=FALSE,check.names=FALSE)
  portable_cl <- read.csv(previous_files[3],stringsAsFactors=FALSE,check.names=FALSE)
  portable_map <- read.csv(previous_files[4],stringsAsFactors=FALSE,check.names=FALSE)
  portable_norm <- read.csv(previous_files[5],stringsAsFactors=FALSE,check.names=FALSE)
  portable_selection <- read.csv(previous_files[6],stringsAsFactors=FALSE,check.names=FALSE)
  stopifnot(identical(names(portable_x),c('patient',colnames(obj$expression))),
   identical(as.character(portable_x$patient),rownames(obj$expression)),
   isTRUE(all.equal(unname(as.matrix(portable_x[,-1,drop=FALSE])),unname(obj$expression),tolerance=1e-12,check.attributes=FALSE)),
   identical(names(portable_cl),names(obj$clinical)),identical(as.character(portable_cl$patient),as.character(obj$clinical$patient)),
   all(portable_cl$project==project),identical(names(portable_map),names(obj$mapping)),
   identical(as.character(portable_map$GeneSymbol),as.character(obj$mapping$GeneSymbol)),
   identical(as.character(portable_map$EnsemblID),as.character(obj$mapping$EnsemblID)),
   identical(as.character(portable_map$status),as.character(obj$mapping$status)),
   identical(as.character(portable_norm$patient),as.character(obj$clinical$patient)),
   all(is.finite(portable_norm$library_size) & portable_norm$library_size>0),
   all(is.finite(portable_norm$TMM_factor) & portable_norm$TMM_factor>0),
   is.logical(portable_selection$selected),!anyNA(portable_selection$selected),
   sum(portable_selection$selected)==nrow(obj$clinical),
   setequal(portable_selection$patient[portable_selection$selected],obj$clinical$patient))
  rm(portable_x,portable_cl,portable_map,portable_norm,portable_selection)
  for(k in seq_along(previous_files))
   if(!file.copy(previous_files[k],out('processed',basename(previous_files[k])),overwrite=FALSE)) stop('Checkpoint copy failed: ',previous_files[k])
  dest_md5 <- tools::md5sum(file.path(ROOT,'processed',basename(previous_files)))
  source_after <- tools::md5sum(previous_files)
  stopifnot(identical(unname(source_md5),unname(source_after)),identical(unname(source_md5),unname(dest_md5)))
  write_csv(data.frame(project=project,source=names(source_md5),source_md5=unname(source_md5),copied_md5=unname(dest_md5)),out('logs',paste0(project,'_reused_expression_checkpoint.csv')))
  x <- obj$expression;cl <- obj$clinical;mapping <- obj$mapping
 annotation_rows[[project]] <- cbind(project=project,mapping)
 qc[[project]] <- do.call(rbind,lapply(ENDPOINTS,function(ep) {
  ok <- !is.na(cl[[ep]]) & is.finite(cl[[paste0(ep,'.time')]]) & cl[[paste0(ep,'.time')]]>0
  data.frame(project=project,endpoint=ep,n_expression=nrow(cl),n_survival=sum(ok),events=sum(cl[[ep]][ok]),
   eligible_genes=sum(mapping$status=='eligible'),n_with_age=sum(ok & !is.na(cl$age)),n_with_stage=sum(ok & !is.na(cl$stage)))
 }))

  try(write_csv(data.frame(stage='expression',project=project,state='reused_complete_checkpoint'),out('logs','progress_current.csv')),silent=TRUE)
  rm(obj,x,cl,mapping);gc()
  message('Reused complete expression checkpoint: ',project)
  next
 }
 try(write_csv(data.frame(stage='expression',project=project,state='computing'),out('logs','progress_current.csv')),silent=TRUE)

 raw <- readRDS(file.path(CACHE_ROOT,'expression',paste0(project,'.rds')))
 stopifnot(length(raw$ensembl)==nrow(raw$counts),length(raw$symbol)==nrow(raw$counts))
 raw_id <- as.character(raw$ensembl)
 raw_symbol <- toupper(trimws(as.character(raw$symbol)))
 expression_ids <- rep(NA_character_,nrow(genes));method <- rep('',nrow(genes))
 for(i in seq_len(nrow(genes))) {
  hit <- which(!is.na(raw_id) & raw_id==genes$EnsemblID[i])
  if(length(hit)) {
   symbols <- unique(raw_symbol[hit])
   if(length(symbols)==1L && !is.na(symbols) && symbols==genes$GeneSymbol[i]) {
    expression_ids[i] <- genes$EnsemblID[i];method[i] <- 'exact_Ensembl_and_symbol'
   } else method[i] <- 'Ensembl_symbol_conflict'
  } else {
   symbol_hit <- which(!is.na(raw_symbol) & raw_symbol==genes$GeneSymbol[i])
   possible <- unique(raw_id[symbol_hit]);possible <- possible[!is.na(possible) & nzchar(possible)]
   if(length(possible)==1L) {
    expression_ids[i] <- possible;method[i] <- 'unique_exact_symbol_crosswalk'
   } else if(length(possible)>1L) method[i] <- 'ambiguous_symbol_crosswalk'
   else method[i] <- 'not_in_raw_annotation'
  }
 }
 collision <- !is.na(expression_ids) & (duplicated(expression_ids) | duplicated(expression_ids,fromLast=TRUE))
 method[collision] <- 'expression_ID_collision';expression_ids[collision] <- NA_character_
 counts <- raw$counts;barcode <- colnames(counts)
 if(any(!grepl('^TCGA-[^-]+-[^-]+-',barcode))) stop('Unexpected sample barcode: ',project)
 patient <- substr(barcode,1,12);sample_code <- substr(barcode,14,15)
 expected <- if(project=='TCGA-LAML') '03' else '01'
 valid <- sample_code==expected & patient %in% clinical$patient[clinical$project==project]
 libs <- colSums(counts);ord <- order(patient,-libs,barcode)
 ix <- ord[valid[ord] & is.finite(libs[ord]) & libs[ord]>0]
 ix <- ix[!duplicated(patient[ix])]
 if(!length(ix)) stop('No eligible expression samples: ',project)
 write_csv(data.frame(barcode=barcode,patient=patient,sample_code=sample_code,library_size=libs,
  selected=seq_along(barcode) %in% ix),out('processed',paste0(project,'_sample_selection.csv')))
 counts <- counts[,ix,drop=FALSE]
 if(anyNA(counts) || any(counts<0)) stop('Invalid raw counts: ',project)
 counts <- rowsum(counts,group=raw$ensembl,reorder=FALSE)
 counts <- counts[rowSums(counts)>0,,drop=FALSE]
 # TMM is fitted on the same full count matrix, never only the288 candidates.
 dge <- edgeR::calcNormFactors(edgeR::DGEList(counts=counts),method='TMM')
 cpm <- edgeR::cpm(dge,log=FALSE);logcpm <- edgeR::cpm(dge,log=TRUE,prior.count=2)
 idx <- match(expression_ids,rownames(logcpm));found <- !is.na(idx)
 x <- matrix(NA_real_,nrow=length(ix),ncol=nrow(genes),dimnames=list(patient[ix],genes$GeneSymbol))
 x[,found] <- t(logcpm[idx[found],,drop=FALSE])
 fraction <- rep(NA_real_,nrow(genes));fraction[found] <- rowMeans(cpm[idx[found],,drop=FALSE]>=MIN_CPM)
 sds <- apply(x,2,sd,na.rm=TRUE)
 mapping <- data.frame(GeneSymbol=genes$GeneSymbol,EnsemblID=genes$EnsemblID,
  expression_EnsemblID=expression_ids,matching_method=method,
  GDC_symbol=raw$symbol[match(expression_ids,raw$ensembl)],expressed_fraction=fraction,sd_logCPM=sds,
  status=ifelse(!found,'not_measured_or_all_zero',ifelse(fraction<MIN_EXPRESSED_FRACTION,
   'low_expression',ifelse(!is.finite(sds)|sds<1e-8,'no_variation','eligible'))))
 conflict <- method %in% c('Ensembl_symbol_conflict','ambiguous_symbol_crosswalk','expression_ID_collision','not_in_raw_annotation')
 mapping$status[conflict] <- method[conflict]
 cl <- clinical[match(rownames(x),clinical$patient),,drop=FALSE]
 stopifnot(identical(rownames(x),cl$patient))
 saveRDS(list(expression=x,clinical=cl,mapping=mapping),out('processed',paste0(project,'.rds')))
 write_csv(mapping,out('processed',paste0(project,'_gene_mapping.csv')))
 write_csv(data.frame(patient=cl$patient,library_size=dge$samples$lib.size,TMM_factor=dge$samples$norm.factors),
  out('processed',paste0(project,'_normalization.csv')))
 # Portable patient-level tables support later targeted common-case/PH checks.
 con <- gzfile(out('processed',paste0(project,'_expression288.csv.gz')),'wt')
 write_csv(data.frame(patient=rownames(x),x,check.names=FALSE),con);close(con)
 write_csv(cl,out('processed',paste0(project,'_clinical.csv')))
 annotation_rows[[project]] <- cbind(project=project,mapping)
 qc[[project]] <- do.call(rbind,lapply(ENDPOINTS,function(ep) {
  ok <- !is.na(cl[[ep]]) & is.finite(cl[[paste0(ep,'.time')]]) & cl[[paste0(ep,'.time')]]>0
  data.frame(project=project,endpoint=ep,n_expression=nrow(cl),n_survival=sum(ok),events=sum(cl[[ep]][ok]),
   eligible_genes=sum(mapping$status=='eligible'),n_with_age=sum(ok & !is.na(cl$age)),n_with_stage=sum(ok & !is.na(cl$stage)))
 }))
 rm(raw,counts,dge,cpm,logcpm,x);gc()
 try(write_csv(data.frame(stage='expression',project=project,state='completed'),out('logs','progress_current.csv')),silent=TRUE)
 message('Prepared new288: ',project)
}
write_csv(do.call(rbind,qc),out('results','cohort_feasibility.csv'))
write_csv(do.call(rbind,annotation_rows),out('results','all288_expression_ID_mapping.csv'))
record_session('04_new288')
