# Run all scripts from the directory containing this file and your workbook.
options(timeout = 3600, stringsAsFactors = FALSE)
PROJECTS <- paste0('TCGA-', c('ACC','BLCA','BRCA','CESC','CHOL','COAD',
 'DLBC','ESCA','GBM','HNSC','KICH','KIRC','KIRP','LAML','LGG','LIHC',
 'LUAD','LUSC','MESO','OV','PAAD','PCPG','PRAD','READ','SARC','SKCM',
 'STAD','TGCT','THCA','THYM','UCEC','UCS','UVM'))
# For a pilot, use PROJECTS <- c('TCGA-LUAD','TCGA-KIRC') BEFORE running steps.
ENDPOINTS <- c('OS', 'PFI')
ROOT <- "D:/TCGA_BRB_validation/tcga_brb_output_GG288_CONTINUED_20261027_103151_5cb9c9"
for (p in c('input','clinical','queries','expression','processed','results','plots','logs'))
 dir.create(file.path(ROOT,p), recursive=TRUE, showWarnings=FALSE)
out <- function(folder, name) file.path(ROOT,folder,name)
GENE_FILE <- NULL # Or set an explicit filename, e.g. 'GC_BRB_gene(1).xlsx'.
EXPECTED_GENES <- 288L
# Feasibility guardrails, not formal power guarantees.
MIN_PATIENTS <- 50L
MIN_EVENTS <- 20L
MIN_EVENTS_PER_PARAMETER <- 10L
MIN_CPM <- 1
MIN_EXPRESSED_FRACTION <- 0.20
FDR_ALPHA <- 0.05
# FALSE prevents a partial download from masquerading as a complete pan-cancer run.
ALLOW_PARTIAL <- FALSE
# Age/sex adjustment is prespecified. Stage is an additional sensitivity analysis.
# No generic stage adjustment for cancers lacking a comparable AJCC stage system.
NO_STAGE <- c('TCGA-LAML','TCGA-GBM','TCGA-LGG','TCGA-OV','TCGA-SARC',
              'TCGA-DLBC','TCGA-PCPG')
CDR_URL <- 'https://api.gdc.cancer.gov/data/1b5f413e-a8d1-4d10-92eb-7c4ae739ed81'
write_csv <- function(x,path) utils::write.csv(x,path,row.names=FALSE,na='')
num <- function(x) suppressWarnings(as.numeric(as.character(x)))
record_session <- function(step) capture.output(sessionInfo(),file=out('logs',paste0(step,'_session.txt')))
