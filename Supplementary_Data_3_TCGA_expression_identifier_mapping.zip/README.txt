Supplementary Data 3 | TCGA expression identifier mapping and processing
The combined file provides 288 candidates x 33 projects (9,504 records), including original candidate and expression identifiers, matching method, expression fraction, dispersion and status. It contains 132 unique exact-symbol crosswalk records. Thirty-three project-specific source mappings, the recorded processing script/configuration and the recorded R session are supplied for traceability. The candidate list is unchanged. Raw GDC expression counts and individual sample-selection records are not included in this package.

File-level provenance and SHA-256 checksums are in MANIFEST.csv.
