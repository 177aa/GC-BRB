Supplementary Data 2 | TCGA association and gene-level results
The full association file contains 57,024 planned records: 288 candidates x 33 projects x two endpoints x three model settings. It retains missing estimates and recorded fit statuses. q_global_BH is the BH-adjusted value within each endpoint-by-model family; PH_gene_p and PH_global_p are the recorded diagnostic values. Gene-level values and the numbers of estimable cancer types are in gene_level_any_cancer_tests.csv. Other files supply the supported subset and summary. Separate families do not provide combined OS-or-PFI FDR control. Values are original saved output; no Cox model or p-value was recomputed.

File-level provenance and SHA-256 checksums are in MANIFEST.csv.
