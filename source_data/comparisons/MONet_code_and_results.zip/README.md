# MONet comparison

This archive contains the paper-based MONet reimplementation and saved test results for six network tasks with five runs per task.

The v4 script was used for the 25 non-PCNET runs. The memory-safe v5 script was used for the five PCNET runs. The scripts retain their original paths and require the original project layout, prepared input data, split manifests, and metric files for training.

Each run contains its saved test predictions and run summary.
