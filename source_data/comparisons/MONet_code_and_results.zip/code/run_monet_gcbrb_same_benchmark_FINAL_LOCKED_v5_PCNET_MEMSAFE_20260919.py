# -*- coding: utf-8 -*-
"""
MONet same-benchmark adaptation on the frozen GC-BRB benchmark — PCNET memory-safe backend
==============================================================

Scope lock
----------
- Clean benchmark only: 6 targets x 5 runs.
- Do NOT rerun or alter GC-BRB.
- Use the exact frozen Train/Validation/Test identities from audited manifests.
- Test is fixed across the five runs for each target; Train/Validation differ by run.
- No source-corruption experiments are performed by this script.

Interpretation lock
-------------------
This is a paper-based MONet reimplementation / same-benchmark adaptation.
It is NOT an exact reproduction of verified author-released official code.

The original MONet paper trains on genes present in each target PPI. For the
GC-BRB same-benchmark comparison, this adapter instead keeps the full global
22,659-node feature universe and ALL formal supervision identities. Edges come
only from the current target PPI. Nodes absent from that target PPI therefore
have no external PPI edges, retain their 64-D features, and receive model
self-loops from PyG GCNConv/GATConv. This is an explicit benchmark adaptation.

Paper-derived architecture / optimization
-----------------------------------------
Input: 64-D multi-omics features.
GCN branch: 64 -> 300 -> 100 -> 16.
GAT branch: 64 -> (100 x 5 heads) -> 16.
Concatenate -> 32-D Graph Enhanced feature.
MLP: 32 -> 16 -> 1 logit.
Adam lr=1e-3, weight_decay=5e-4, dropout=0.5, max 2000 epochs.
Weighted BCE; positive weight is computed from the FULL formal training split
as train_neg/train_pos (train-only benchmark adaptation).
Checkpoint selection: minimum weighted Validation BCE loss, evaluated EVERY epoch.
Classification threshold: selected on Validation only, maximizing MCC exactly
as core/select_threshold.m (ties -> threshold closest to 0.5).
Metrics: exact Python port of core/binary_metrics.m, including average-precision
AUPRC (stepwise AP, not trapezoidal PR AUC).

Leakage guard
-------------
--mode smoke:
    * trains for 5 epochs by default,
    * evaluates Validation,
    * MAY select a Validation MCC threshold to exercise the metric code,
    * NEVER runs model inference on Test,
    * NEVER writes Test predictions or Test performance metrics.
--mode formal:
    * freezes the best Validation-loss checkpoint,
    * selects the threshold on Validation only,
    * evaluates Test exactly once after checkpoint+threshold freeze.

Recommended first command
-------------------------
python run_monet_gcbrb_same_benchmark.py --target CPDB --run 1 --mode smoke

Then, only after smoke passes:
python run_monet_gcbrb_same_benchmark.py --target CPDB --run 1 --mode formal

PCNET execution-backend exception
--------------------------------
PCNET has 5,449,448 directed edges. Standard PyG GATConv materializes an
[E, heads, channels] message tensor in gat1 and exceeded the available 8 GiB
GPU. This file changes only the aggregation execution backend to sparse COO
SpMM. It does NOT change nodes, edges, features, model dimensions, attention
formula, self-loops, loss, split, seed, checkpoint rule, threshold or metrics.
A mandatory forward/backward numerical equivalence guard against PyG GATConv
runs before formal PCNET training. The 25 already-completed non-PCNET v4 runs
are intentionally not regenerated.

Final protocol lock
-------------------
Formal Validation is evaluated every epoch (val_every=1). Results are written to
results/monet_same_benchmark/02_clean_final_locked so earlier protocol-precheck
runs are never mixed with final runs. Resume/completion/Test-cache reuse is
permitted only when the protocol fingerprint matches.

Resume behavior
---------------
Training progress is crash-safe. The script atomically overwrites
latest_training_state.pt after every completed epoch, including model, optimizer,
best Validation-loss checkpoint, early-stopping state, history, accumulated
runtime, and Python/NumPy/PyTorch RNG states. Re-running the identical command
automatically resumes from the next epoch. Completed runs are detected and
skipped so a finished formal Test is not repeated. Use --fresh only to discard
an INCOMPLETE training checkpoint and restart that unfinished run from epoch 1.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
import random
import time
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv, GCNConv
from torch_geometric.utils import add_self_loops, remove_self_loops, softmax


# =============================================================================
# PATHS / FROZEN BENCHMARK CONSTANTS
# =============================================================================

PROJECT_ROOT = Path(
    os.environ.get("GCBRB_ROOT", r"D:\PyCharm 2024.1\data_h5\GC_BRB_3LAYER_FINAL")
).resolve()

PREPARED_MAT = PROJECT_ROOT / "cache" / "prepared" / "multilayer_aligned_gcbrb.mat"
CORE_BINARY_METRICS = PROJECT_ROOT / "core" / "binary_metrics.m"
CORE_SELECT_THRESHOLD = PROJECT_ROOT / "core" / "select_threshold.m"

DEFAULT_MANIFEST_CANDIDATES = [
    PROJECT_ROOT / "results" / "monet_same_benchmark" / "00_exact_30run_manifests" / "manifests",
    PROJECT_ROOT / "results" / "sefgnn_same_benchmark" / "02_exact_30run_manifests" / "manifests",
]

OUT_BASE = PROJECT_ROOT / "results" / "monet_same_benchmark" / "02_clean_final_locked"

VIEWS = ["CPDB", "MULTINET", "PCNET", "STRINGdb", "IREF", "IREF_2015"]
EXPECTED_LOCAL_N = {
    "CPDB": 13627,
    "MULTINET": 14398,
    "PCNET": 19781,
    "STRINGdb": 13179,
    "IREF": 17013,
    "IREF_2015": 12129,
}
EXPECTED_DIRECTED_EDGES = {
    "CPDB": 504378,
    "MULTINET": 219134,
    "PCNET": 5449448,
    "STRINGdb": 673096,
    "IREF": 738722,
    "IREF_2015": 183618,
}
EXPECTED_SPLITS = {
    "CPDB":      dict(train=7104, val=790, test=746,  test_pos=199),
    "MULTINET":  dict(train=6763, val=752, test=1125, test_pos=198),
    "PCNET":     dict(train=6349, val=705, test=1586, test_pos=215),
    "STRINGdb":  dict(train=7056, val=784, test=800,  test_pos=196),
    "IREF":      dict(train=6675, val=742, test=1223, test_pos=209),
    "IREF_2015": dict(train=7155, val=795, test=690,  test_pos=196),
}

N_GLOBAL = 22659
N_LABELLED = 8640
N_POS = 887
N_NEG = 7753

# Paper-derived defaults.
PAPER_LR = 1e-3
PAPER_WEIGHT_DECAY = 5e-4
PAPER_DROPOUT = 0.5
PAPER_EPOCHS = 2000

# Paper states validation-loss early stopping but does not report patience.
# Therefore patience/min_epochs are explicitly logged adaptation choices.
DEFAULT_PATIENCE = 100
DEFAULT_MIN_EPOCHS = 100

# Model randomness only. Formal split identity is NEVER generated from this seed.
# For provenance, reuse the exact split.seed saved in each frozen GC-BRB model
# as the stochastic seed anchor for the paired MONet run. The 30 frozen models
# were audited as: seed = 20260712 + 1000*(target_index_1based) + run.
FROZEN_SEED_BASE = 20260712

def frozen_run_seed(target: str, run: int) -> int:
    return int(FROZEN_SEED_BASE + 1000 * (VIEWS.index(target) + 1) + int(run))

# Uploaded/frozen GC-BRB metric-function hashes audited on 2026-09-19.
EXPECTED_BINARY_METRICS_SHA256 = (
    "fc518775696dafd27d704e590008f9a58dc047b47ea0c7f9bc2a1d10540ee948"
)
EXPECTED_SELECT_THRESHOLD_SHA256 = (
    "80398f7a99b437fc5e5dfee98fdd32993bbb8a062654a52b0b16bdca16eb3156"
)


# =============================================================================
# REPRODUCIBILITY / UTILITIES
# =============================================================================

def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    # Exact CUDA determinism may require a slower backend and is not guaranteed
    # by the MONet paper. Keep algorithm choice unchanged and log the seed.
    try:
        torch.use_deterministic_algorithms(False)
    except Exception:
        pass


PROTOCOL_VERSION = "MONET_GCBRB_SAME_BENCHMARK_FINAL_V1_20260919_PCNET_MEMSAFE_EQUIV"
RESUME_SCHEMA_VERSION = 2


def _capture_rng_state():
    state = {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch_cpu": torch.get_rng_state().cpu(),
        "torch_cuda": None,
    }
    if torch.cuda.is_available():
        state["torch_cuda"] = [x.cpu() for x in torch.cuda.get_rng_state_all()]
    return state


def _restore_rng_state(state):
    if not state:
        return
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch_cpu"].cpu())
    if torch.cuda.is_available() and state.get("torch_cuda") is not None:
        torch.cuda.set_rng_state_all([x.cpu() for x in state["torch_cuda"]])


def _atomic_torch_save(payload, path: Path):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    torch.save(payload, tmp)
    os.replace(tmp, path)


def _torch_load_full(path: Path):
    # PyTorch >=2.6 defaults weights_only=True; resume checkpoints intentionally
    # contain optimizer/history/RNG Python objects, so request full loading.
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def _optimizer_to_device(optimizer, device):
    for state in optimizer.state.values():
        for key, value in list(state.items()):
            if torch.is_tensor(value):
                state[key] = value.to(device)


def _resume_signature(target, run, mode, seed, epochs, patience, min_epochs, val_every, protocol_fingerprint):
    return {
        "target": str(target),
        "run": int(run),
        "mode": str(mode),
        "seed": int(seed),
        "epochs": int(epochs),
        "patience": int(patience),
        "min_epochs": int(min_epochs),
        "val_every": int(val_every),
        "protocol_fingerprint": str(protocol_fingerprint),
    }


def _validate_resume_signature(saved, expected):
    for key, value in expected.items():
        if saved.get(key) != value:
            raise RuntimeError(
                f"Resume checkpoint mismatch for {key}: "
                f"saved={saved.get(key)!r}, requested={value!r}. "
                "Use the identical command, or use --fresh to restart an "
                "incomplete run from epoch 1."
            )


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def json_safe(x):
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    raise TypeError(type(x).__name__)


def _canonical_json_sha256(obj) -> str:
    payload = json.dumps(
        obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True, default=json_safe
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def build_protocol_lock(target, run, mode, seed, epochs, patience, min_epochs, val_every, split, metric_source_audit):
    script_path = Path(__file__).resolve()
    spec = {
        "ProtocolVersion": PROTOCOL_VERSION,
        "ScriptSHA256": file_sha256(script_path),
        "PreparedMATSHA256": file_sha256(PREPARED_MAT),
        "TrainManifestSHA256": file_sha256(split["train"]["path"]),
        "ValidationManifestSHA256": file_sha256(split["validation"]["path"]),
        "TestManifestSHA256": file_sha256(split["test"]["path"]),
        "BinaryMetricsSHA256": metric_source_audit["binary_metrics.m"]["SHA256"],
        "SelectThresholdSHA256": metric_source_audit["select_threshold.m"]["SHA256"],
        "Target": str(target),
        "Run": int(run),
        "Mode": str(mode),
        "Seed": int(seed),
        "GlobalNodes": N_GLOBAL,
        "LabeledUniverse": N_LABELLED,
        "Architecture": {
            "Input": 64,
            "GCN": [300, 100, 16],
            "GATHiddenPerHead": 100,
            "GATHeads": 5,
            "GATOutput": 16,
            "GATOutputHeads": 1,
            "MLP": [32, 16, 1],
            "PyGSelfLoops": True,
            "GATMathematics": "PyG GATConv-equivalent",
            "GATExecutionBackend": "Sparse COO SpMM aggregation; no edge/node/model/sampling changes",
        },
        "Optimization": {
            "AdamLR": PAPER_LR,
            "WeightDecay": PAPER_WEIGHT_DECAY,
            "Dropout": PAPER_DROPOUT,
            "EpochBudget": int(epochs),
            "PatienceEpochs": int(patience),
            "MinEpochs": int(min_epochs),
            "ValidationEveryEpochs": int(val_every),
            "PositiveWeight": "formal_train_neg/formal_train_pos",
        },
        "CheckpointRule": "minimum weighted Validation BCE loss",
        "ThresholdRule": "Validation-only MCC; ties closest to 0.5",
        "MetricRule": "GC-BRB binary_metrics.m exact Python port; AP-style AUPRC",
        "PopulationRule": (
            "22659 global nodes; target PPI edges only; ALL formal supervision kept; "
            "target-PPI-absent nodes retain 64-D features and model self-loops"
        ),
        "TestRule": "formal only; after checkpoint and Validation threshold freeze",
    }
    return {
        "Version": PROTOCOL_VERSION,
        "FingerprintSHA256": _canonical_json_sha256(spec),
        "Spec": spec,
    }


def resolve_manifest_root(cli_value: str | None) -> Path:
    if cli_value:
        root = Path(cli_value).resolve()
        if not root.exists():
            raise FileNotFoundError(f"--manifest-root does not exist: {root}")
        return root

    env = os.environ.get("GCBRB_MANIFEST_ROOT")
    if env:
        root = Path(env).resolve()
        if not root.exists():
            raise FileNotFoundError(f"GCBRB_MANIFEST_ROOT does not exist: {root}")
        return root

    for root in DEFAULT_MANIFEST_CANDIDATES:
        if root.exists():
            return root.resolve()

    tried = "\n".join(f"  - {p}" for p in DEFAULT_MANIFEST_CANDIDATES)
    raise FileNotFoundError(
        "No exact-manifest root found. Extract the audited manifest package or "
        "pass --manifest-root.\nTried:\n" + tried
    )


# =============================================================================
# MATLAB v7.3 / HDF5 HELPERS
# =============================================================================

def _is_ref_dtype(ds):
    return isinstance(ds, h5py.Dataset) and h5py.check_dtype(ref=ds.dtype) is not None


def _resolve_dataset(h, ds):
    arr = ds[()]
    if _is_ref_dtype(ds):
        refs = np.asarray(arr).reshape(-1)
        out = []
        for ref in refs:
            if not ref:
                continue
            obj = h[ref]
            if isinstance(obj, h5py.Dataset):
                out.append(np.asarray(obj[()]))
            else:
                out.append(obj)
        return out
    return np.asarray(arr)


def _resolve_to_group(h, obj):
    if isinstance(obj, h5py.Group):
        return obj
    if isinstance(obj, h5py.Dataset) and _is_ref_dtype(obj):
        refs = [r for r in np.asarray(obj[()]).reshape(-1) if r]
        if len(refs) != 1:
            raise RuntimeError(f"Expected one group reference, got {len(refs)}")
        target = h[refs[0]]
        if not isinstance(target, h5py.Group):
            raise RuntimeError("Reference did not resolve to a group")
        return target
    raise RuntimeError(f"Cannot resolve object to group: {type(obj)}")


def _get_struct_group(h, name: str):
    if name not in h:
        raise KeyError(f"{name} missing from {PREPARED_MAT}")
    return _resolve_to_group(h, h[name])


def _get_group_field_numeric(h, group, field: str):
    key = field if field in group else next(
        (k for k in group.keys() if k.lower() == field.lower()), None
    )
    if key is None:
        raise KeyError(f"{field} not found in {group.name}")
    obj = group[key]
    if not isinstance(obj, h5py.Dataset):
        raise RuntimeError(f"{group.name}/{key} is not a dataset")
    val = _resolve_dataset(h, obj)
    if isinstance(val, list) or isinstance(val, h5py.Group):
        raise RuntimeError(f"{group.name}/{key} did not resolve to numeric array")
    return np.asarray(val).squeeze()


def load_prepared_alignment():
    if not PREPARED_MAT.exists():
        raise FileNotFoundError(PREPARED_MAT)

    with h5py.File(PREPARED_MAT, "r") as h:
        data = _get_struct_group(h, "data")
        X = np.asarray(_get_group_field_numeric(h, data, "X"), dtype=np.float64)
        y = np.asarray(_get_group_field_numeric(h, data, "y"), dtype=float).reshape(-1)
        presence = np.asarray(_get_group_field_numeric(h, data, "presence"))

        if X.shape == (64, N_GLOBAL):
            X = X.T
        elif X.shape != (N_GLOBAL, 64):
            raise RuntimeError(f"Unexpected data.X shape: {X.shape}")
        if not np.all(np.isfinite(X)):
            raise RuntimeError("data.X contains NaN/Inf")

        if y.size != N_GLOBAL:
            raise RuntimeError(f"Unexpected data.y length: {y.size}")

        if presence.shape == (len(VIEWS), N_GLOBAL):
            presence = presence.T
        elif presence.shape != (N_GLOBAL, len(VIEWS)):
            raise RuntimeError(f"Unexpected data.presence shape: {presence.shape}")
        presence = presence.astype(bool)

        layers_obj = data["layers"]
        if not _is_ref_dtype(layers_obj):
            raise RuntimeError("data.layers is not a MATLAB cell/reference dataset")
        refs = [r for r in np.asarray(layers_obj[()]).reshape(-1) if r]
        if len(refs) != len(VIEWS):
            raise RuntimeError(f"Expected 6 layer references, found {len(refs)}")

        local_to_global = {}
        for view, ref in zip(VIEWS, refs):
            layer_group = _resolve_to_group(h, h[ref])
            ltg = np.asarray(
                _get_group_field_numeric(h, layer_group, "local_to_global")
            ).reshape(-1)
            if not np.allclose(ltg, np.round(ltg)):
                raise RuntimeError(f"{view}: non-integer local_to_global")
            ltg = np.round(ltg).astype(np.int64)
            if len(ltg) != EXPECTED_LOCAL_N[view]:
                raise RuntimeError(
                    f"{view}: local_to_global length {len(ltg)} != "
                    f"expected {EXPECTED_LOCAL_N[view]}"
                )
            if np.any(ltg < 1) or np.any(ltg > N_GLOBAL):
                raise RuntimeError(f"{view}: local_to_global out of bounds")
            if len(np.unique(ltg)) != len(ltg):
                raise RuntimeError(f"{view}: duplicate local_to_global entries")
            local_to_global[view] = ltg

    if int(np.isfinite(y).sum()) != N_LABELLED:
        raise RuntimeError("Global labeled count audit failed")
    if int((y == 1).sum()) != N_POS or int((y == 0).sum()) != N_NEG:
        raise RuntimeError("Global positive/negative count audit failed")

    for j, view in enumerate(VIEWS):
        implied = np.zeros(N_GLOBAL, dtype=bool)
        implied[local_to_global[view] - 1] = True
        if not np.array_equal(implied, presence[:, j]):
            raise RuntimeError(f"{view}: presence/local_to_global mismatch")

    return X.astype(np.float32), y, presence, local_to_global


def load_target_global_edge_index(view: str):
    """
    Read the frozen MATLAB sparse adjacency directly from
    multilayer_aligned_gcbrb.mat and map local PPI node indices to global
    0-based node indices. The stored adjacency is binary, symmetric, and has
    no self-loops in the frozen prepared file. PyG layers add self-loops.
    """
    if view not in VIEWS:
        raise ValueError(view)

    with h5py.File(PREPARED_MAT, "r") as h:
        data = _get_struct_group(h, "data")
        refs = [r for r in np.asarray(data["layers"][()]).reshape(-1) if r]
        layer = _resolve_to_group(h, h[refs[VIEWS.index(view)]])

        ltg = np.asarray(
            _get_group_field_numeric(h, layer, "local_to_global")
        ).reshape(-1)
        ltg = np.round(ltg).astype(np.int64) - 1
        n = len(ltg)

        A = layer["A"]
        if not isinstance(A, h5py.Group):
            raise RuntimeError(f"{view}: layer.A is not MATLAB sparse group")
        for key in ("ir", "jc", "data"):
            if key not in A:
                raise RuntimeError(f"{view}: sparse A missing {key}")

        ir = np.asarray(A["ir"][()]).reshape(-1).astype(np.int64)
        jc = np.asarray(A["jc"][()]).reshape(-1).astype(np.int64)
        values = np.asarray(A["data"][()]).reshape(-1)

    if len(jc) != n + 1:
        raise RuntimeError(f"{view}: sparse jc length mismatch")
    if int(jc[-1]) != len(ir) or len(values) != len(ir):
        raise RuntimeError(f"{view}: sparse A pointer/nnz mismatch")
    if len(ir) != EXPECTED_DIRECTED_EDGES[view]:
        raise RuntimeError(
            f"{view}: directed edge count {len(ir)} != "
            f"{EXPECTED_DIRECTED_EDGES[view]}"
        )
    if np.any(ir < 0) or np.any(ir >= n):
        raise RuntimeError(f"{view}: sparse row index out of bounds")
    if not np.all(values == 1):
        raise RuntimeError(f"{view}: expected binary adjacency values only")

    col_counts = np.diff(jc)
    if np.any(col_counts < 0):
        raise RuntimeError(f"{view}: non-monotone sparse column pointer")
    col = np.repeat(np.arange(n, dtype=np.int64), col_counts)
    row = ir
    if np.any(row == col):
        raise RuntimeError(f"{view}: unexpected self-loop in frozen adjacency")

    # A[row, col] => message edge col -> row. Since frozen A is symmetric,
    # either orientation convention yields the same bidirectional edge set.
    src_global = ltg[col]
    dst_global = ltg[row]
    edge_index = np.vstack([src_global, dst_global]).astype(np.int64, copy=False)

    if np.any(edge_index < 0) or np.any(edge_index >= N_GLOBAL):
        raise RuntimeError(f"{view}: global edge index out of bounds")
    return edge_index, ltg


# =============================================================================
# EXACT FORMAL SPLITS / FAMILY AUDIT
# =============================================================================

def read_manifest(manifest_root: Path, target: str, run: int, split_name: str):
    path = (
        manifest_root / target / f"run_{run:02d}" /
        f"{split_name.lower()}_identity.csv"
    )
    if not path.exists():
        raise FileNotFoundError(path)
    df = pd.read_csv(path)

    if "GlobalIndex_1based" in df.columns:
        idx1 = pd.to_numeric(df["GlobalIndex_1based"], errors="raise").astype(np.int64).to_numpy()
    elif "GlobalIndex" in df.columns:
        # Legacy exact manifests used GlobalIndex for 1-based MATLAB identities.
        idx1 = pd.to_numeric(df["GlobalIndex"], errors="raise").astype(np.int64).to_numpy()
    else:
        raise RuntimeError(f"{path}: global-index column missing")

    if "Label" not in df.columns:
        raise RuntimeError(f"{path}: Label column missing")
    lab = pd.to_numeric(df["Label"], errors="raise").astype(np.int64).to_numpy()

    if np.any(idx1 < 1) or np.any(idx1 > N_GLOBAL):
        raise RuntimeError(f"{path}: global index out of bounds")
    if len(np.unique(idx1)) != len(idx1):
        raise RuntimeError(f"{path}: duplicate global identities inside split")
    if not np.all(np.isin(lab, [0, 1])):
        raise RuntimeError(f"{path}: non-binary label")

    return path, idx1 - 1, lab


def load_exact_target_split(
    manifest_root: Path,
    target: str,
    run: int,
    global_y: np.ndarray,
):
    exp = EXPECTED_SPLITS[target]
    result = {}
    for split_name, expected_n in [
        ("train", exp["train"]),
        ("validation", exp["val"]),
        ("test", exp["test"]),
    ]:
        path, idx0, labels = read_manifest(manifest_root, target, run, split_name)
        if len(idx0) != expected_n:
            raise RuntimeError(
                f"{target} run_{run:02d} {split_name}: "
                f"{len(idx0)} != {expected_n}"
            )
        gy = global_y[idx0]
        if np.any(~np.isfinite(gy)):
            raise RuntimeError(
                f"{target} run_{run:02d} {split_name}: unlabeled gene present"
            )
        if not np.array_equal(gy.astype(np.int64), labels):
            raise RuntimeError(
                f"{target} run_{run:02d} {split_name}: manifest/global-y mismatch"
            )
        result[split_name] = {
            "path": path,
            "idx0": idx0,
            "labels": labels,
        }

    tr = result["train"]["idx0"]
    va = result["validation"]["idx0"]
    te = result["test"]["idx0"]
    all_idx = np.concatenate([tr, va, te])

    if len(np.unique(all_idx)) != N_LABELLED:
        raise RuntimeError(
            f"{target} run_{run:02d}: Train/Validation/Test overlap or union != 8640"
        )
    if int(result["test"]["labels"].sum()) != exp["test_pos"]:
        raise RuntimeError(
            f"{target} run_{run:02d}: frozen Test positive-count audit failed"
        )
    return result


def audit_all_manifests(manifest_root: Path, global_y: np.ndarray):
    """
    Re-audit the full 6 x 5 family before training:
      - exact expected split sizes,
      - label agreement with frozen prepared MAT,
      - disjoint Train/Validation/Test with union=8640,
      - fixed Test identity/order across the five runs per target,
      - five distinct Train arrays and five distinct Validation arrays,
      - same 8640 labeled-gene universe across all targets/runs.
    This uses no model predictions and computes no Test performance metric.
    """
    rows = []
    reference_universe = None

    for target in VIEWS:
        target_tests = []
        train_signatures = []
        val_signatures = []

        for run in range(1, 6):
            split = load_exact_target_split(
                manifest_root, target, run, global_y
            )
            tr = split["train"]["idx0"]
            va = split["validation"]["idx0"]
            te = split["test"]["idx0"]
            universe = np.sort(np.concatenate([tr, va, te]))

            if reference_universe is None:
                reference_universe = universe
            elif not np.array_equal(reference_universe, universe):
                raise RuntimeError(
                    f"{target} run_{run:02d}: 8640-gene universe differs"
                )

            target_tests.append(te.copy())
            train_signatures.append(hashlib.sha256(tr.tobytes()).hexdigest())
            val_signatures.append(hashlib.sha256(va.tobytes()).hexdigest())

            rows.append({
                "Target": target,
                "Run": run,
                "TrainN": len(tr),
                "ValidationN": len(va),
                "TestN": len(te),
                "TrainPositive": int(split["train"]["labels"].sum()),
                "ValidationPositive": int(split["validation"]["labels"].sum()),
                "TestPositive": int(split["test"]["labels"].sum()),
            })

        if not all(np.array_equal(target_tests[0], x) for x in target_tests[1:]):
            raise RuntimeError(f"{target}: Test identity/order is not fixed across runs")
        if len(set(train_signatures)) != 5:
            raise RuntimeError(f"{target}: Train does not contain five distinct run identities")
        if len(set(val_signatures)) != 5:
            raise RuntimeError(f"{target}: Validation does not contain five distinct run identities")

    return pd.DataFrame(rows)


# =============================================================================
# TARGET-PPI PRESENCE DIAGNOSTIC (NO FILTERING)
# =============================================================================

def split_presence_diagnostic(split, target_presence):
    rows = []
    for name in ["train", "validation", "test"]:
        idx = split[name]["idx0"]
        lab = split[name]["labels"]
        present = target_presence[idx]
        rows.append({
            "Split": name,
            "FullFormalN": int(len(idx)),
            "FullPositive": int(lab.sum()),
            "TargetPPIPresentN": int(present.sum()),
            "TargetPPIAbsentN": int((~present).sum()),
            "TargetPPIPresentFraction": float(present.mean()),
            "TargetPPIPresentPositive": int(lab[present].sum()),
            "TargetPPIAbsentPositive": int(lab[~present].sum()),
            "SupervisionKeptN": int(len(idx)),   # lock: NO filtering
        })
    return pd.DataFrame(rows)


# =============================================================================
# MONET MODEL
# =============================================================================

class SparseSpMMGATConv(GATConv):
    """
    Memory-safe execution backend for the exact homogeneous, no-edge-feature
    GATConv configuration used by this MONet reimplementation.

    Mathematical operation is unchanged relative to PyG GATConv:
      1) same inherited linear projections / attention parameters / bias;
      2) same remove+add self-loop behavior;
      3) same LeakyReLU attention logits;
      4) same destination-wise PyG softmax;
      5) same attention dropout;
      6) same sum aggregation.

    The only implementation change is aggregation. Standard MessagePassing
    materializes x_j with shape [E, heads, channels], which is >10 GiB for
    PCNET gat1. Here each attention head is aggregated with sparse COO SpMM,
    avoiding the [E, H, C] message tensor. No edges are removed or sampled.

    This subclass calls GATConv.__init__ unchanged, so parameter creation,
    initialization and state_dict schema remain the PyG GATConv ones.
    """

    def forward(
        self,
        x,
        edge_index,
        edge_attr=None,
        size=None,
        return_attention_weights=None,
    ):
        if not torch.is_tensor(x) or x.dim() != 2:
            raise TypeError(
                "SparseSpMMGATConv is intentionally locked to homogeneous 2-D "
                "Tensor node features, matching this MONet benchmark."
            )
        if not torch.is_tensor(edge_index):
            raise TypeError(
                "SparseSpMMGATConv requires dense COO edge_index Tensor."
            )
        if edge_attr is not None:
            raise ValueError(
                "This MONet benchmark has no edge features; edge_attr must be None."
            )

        H, C = int(self.heads), int(self.out_channels)
        n_src = int(x.size(0))

        # Keep compatibility across PyG GATConv versions. In the homogeneous
        # configuration used here, current PyG exposes self.lin. Older variants
        # may expose lin_src/lin_dst instead.
        residual = None
        res_module = getattr(self, "res", None)
        if res_module is not None:
            residual = res_module(x)

        lin = getattr(self, "lin", None)
        if lin is not None:
            x_src = lin(x).view(-1, H, C)
            x_dst = x_src
        else:
            lin_src = getattr(self, "lin_src", None)
            lin_dst = getattr(self, "lin_dst", None)
            if lin_src is None:
                raise RuntimeError("Unsupported PyG GATConv parameter layout: no lin/lin_src")
            x_src = lin_src(x).view(-1, H, C)
            if lin_dst is None:
                x_dst = x_src
            else:
                x_dst = lin_dst(x).view(-1, H, C)

        alpha_src = (x_src * self.att_src).sum(dim=-1)
        alpha_dst = (x_dst * self.att_dst).sum(dim=-1)

        if bool(self.add_self_loops):
            num_nodes = min(int(x_src.size(0)), int(x_dst.size(0)))
            if size is not None:
                known = [int(v) for v in size if v is not None]
                if known:
                    num_nodes = min(num_nodes, min(known))
            edge_index, _ = remove_self_loops(edge_index, None)
            edge_index, _ = add_self_loops(
                edge_index,
                None,
                fill_value=getattr(self, "fill_value", "mean"),
                num_nodes=num_nodes,
            )

        src = edge_index[0]
        dst = edge_index[1]

        alpha = alpha_src[src] + alpha_dst[dst]
        alpha = F.leaky_relu(alpha, float(self.negative_slope))
        alpha = softmax(alpha, dst, num_nodes=int(x_dst.size(0)))
        alpha = F.dropout(alpha, p=float(self.dropout), training=self.training)

        # A_{target, source} @ X_source gives the same sum aggregation as
        # MessagePassing(flow='source_to_target'). Loop over attention heads so
        # the huge [E, H, C] message tensor is never materialized.
        sparse_indices = torch.stack((dst, src), dim=0)
        out_heads = []
        sparse_size = (int(x_dst.size(0)), n_src)
        for h in range(H):
            adj_h = torch.sparse_coo_tensor(
                sparse_indices,
                alpha[:, h],
                size=sparse_size,
                dtype=x_src.dtype,
                device=x_src.device,
            )
            out_h = torch.sparse.mm(adj_h, x_src[:, h, :])
            out_heads.append(out_h)

        out = torch.stack(out_heads, dim=1)
        if bool(self.concat):
            out = out.reshape(-1, H * C)
        else:
            out = out.mean(dim=1)

        if residual is not None:
            out = out + residual
        if self.bias is not None:
            out = out + self.bias

        if isinstance(return_attention_weights, bool):
            return out, (edge_index, alpha)
        return out


def verify_sparse_gat_equivalence(device=None):
    """Numerical forward/backward equivalence guard against standard PyG GATConv."""
    # CPU double precision makes the semantic test stable and tiny; formal
    # PCNET training may still run on CUDA after this guard passes.
    dev = torch.device("cpu") if device is None else torch.device(device)
    old_rng = torch.get_rng_state()
    try:
        torch.manual_seed(913731)
        n = 17
        in_dim = 11
        # Include duplicates, asymmetric edges and existing self-loops so the
        # self-loop normalization path is exercised.
        edge_index = torch.tensor([
            [0, 0, 1, 2, 2, 3, 4, 4, 5, 6, 6, 7, 8, 8, 9, 10, 11, 12, 13, 14, 15, 16, 2, 2],
            [1, 1, 2, 0, 2, 4, 3, 5, 4, 7, 6, 8, 9, 8, 10, 11, 12, 13, 14, 15, 16, 0, 5, 5],
        ], dtype=torch.long, device=dev)

        configs = [
            dict(in_channels=in_dim, out_channels=7, heads=3, concat=True),
            dict(in_channels=in_dim, out_channels=5, heads=1, concat=False),
        ]

        worst = {
            "forward_max_abs": 0.0,
            "x_grad_max_abs": 0.0,
            "param_grad_max_abs": 0.0,
        }

        for cfg in configs:
            torch.manual_seed(77123)
            ref = GATConv(
                **cfg, dropout=0.0, add_self_loops=True
            ).double().to(dev)
            torch.manual_seed(77123)
            safe = SparseSpMMGATConv(
                **cfg, dropout=0.0, add_self_loops=True
            ).double().to(dev)

            # Constructor/state schema should be identical because safe inherits
            # GATConv unchanged; load explicitly as a second hard guard.
            safe.load_state_dict(ref.state_dict(), strict=True)

            x0 = torch.randn(n, in_dim, dtype=torch.float64, device=dev)
            xr = x0.detach().clone().requires_grad_(True)
            xs = x0.detach().clone().requires_grad_(True)

            ref.eval()
            safe.eval()
            yr = ref(xr, edge_index)
            ys = safe(xs, edge_index)

            fwd = float((yr - ys).abs().max().item())
            worst["forward_max_abs"] = max(worst["forward_max_abs"], fwd)

            # Nonlinear scalar objective ensures gradients through attention,
            # projections, aggregation and bias are all exercised.
            wr = torch.linspace(
                0.3, 1.7, yr.numel(), dtype=yr.dtype, device=dev
            ).reshape_as(yr)
            loss_r = ((yr * wr).sin().square()).mean()
            loss_s = ((ys * wr).sin().square()).mean()
            loss_r.backward()
            loss_s.backward()

            xg = float((xr.grad - xs.grad).abs().max().item())
            worst["x_grad_max_abs"] = max(worst["x_grad_max_abs"], xg)

            ref_params = dict(ref.named_parameters())
            safe_params = dict(safe.named_parameters())
            if set(ref_params) != set(safe_params):
                raise RuntimeError(
                    "Safe GAT parameter schema differs from PyG GATConv: "
                    f"ref={sorted(ref_params)}, safe={sorted(safe_params)}"
                )
            pg = 0.0
            for name in ref_params:
                gr = ref_params[name].grad
                gs = safe_params[name].grad
                if gr is None and gs is None:
                    continue
                if gr is None or gs is None:
                    raise RuntimeError(f"Gradient presence mismatch for {name}")
                pg = max(pg, float((gr - gs).abs().max().item()))
            worst["param_grad_max_abs"] = max(worst["param_grad_max_abs"], pg)

        # Double-precision CPU reductions should be much tighter than this;
        # tolerances only accommodate harmless sparse/dense summation ordering.
        if worst["forward_max_abs"] > 1e-9:
            raise RuntimeError(f"Safe GAT forward equivalence FAILED: {worst}")
        if worst["x_grad_max_abs"] > 1e-8 or worst["param_grad_max_abs"] > 1e-8:
            raise RuntimeError(f"Safe GAT backward equivalence FAILED: {worst}")

        print("Memory-safe GAT numerical equivalence guard: PASS")
        print(
            "  forward max|Δ|={:.3e}, x-grad max|Δ|={:.3e}, param-grad max|Δ|={:.3e}".format(
                worst["forward_max_abs"],
                worst["x_grad_max_abs"],
                worst["param_grad_max_abs"],
            )
        )
        return worst
    finally:
        torch.set_rng_state(old_rng)


class MONet(nn.Module):
    def __init__(self, in_dim=64, dropout=PAPER_DROPOUT):
        super().__init__()
        self.dropout = float(dropout)

        self.gcn1 = GCNConv(in_dim, 300)
        self.gcn2 = GCNConv(300, 100)
        self.gcn3 = GCNConv(100, 16)

        self.gat1 = SparseSpMMGATConv(
            in_dim, 100, heads=5, concat=True,
            dropout=self.dropout, add_self_loops=True
        )
        self.gat2 = SparseSpMMGATConv(
            100 * 5, 16, heads=1, concat=False,
            dropout=self.dropout, add_self_loops=True
        )

        self.mlp1 = nn.Linear(32, 16)
        self.mlp2 = nn.Linear(16, 1)

    def forward(self, x, edge_index):
        g = self.gcn1(x, edge_index)
        g = F.relu(g)
        g = F.dropout(g, p=self.dropout, training=self.training)
        g = self.gcn2(g, edge_index)
        g = F.relu(g)
        g = F.dropout(g, p=self.dropout, training=self.training)
        g = self.gcn3(g, edge_index)

        a = F.dropout(x, p=self.dropout, training=self.training)
        a = self.gat1(a, edge_index)
        a = F.elu(a)
        a = F.dropout(a, p=self.dropout, training=self.training)
        a = self.gat2(a, edge_index)

        h = torch.cat([g, a], dim=1)
        h = self.mlp1(h)
        h = F.relu(h)
        h = F.dropout(h, p=self.dropout, training=self.training)
        return self.mlp2(h).squeeze(-1)


# =============================================================================
# EXACT GC-BRB METRICS / THRESHOLD PORT
# =============================================================================

def binary_metrics_gcbrb(truth, score, threshold=0.5):
    """
    Exact semantic port of core/binary_metrics.m.
    AUPRC is average precision:
        sum(delta_recall * precision)
    evaluated at unique score tie endpoints.
    """
    truth = np.asarray(truth).reshape(-1).astype(bool)
    score = np.asarray(score, dtype=float).reshape(-1)

    if truth.size != score.size:
        raise ValueError("truth and score must have the same length")
    if truth.size == 0:
        raise ValueError("empty truth/score")
    if np.any(~np.isfinite(score)):
        raise ValueError("score contains NaN or Inf")

    prediction = score >= float(threshold)

    TP = int(np.count_nonzero(prediction & truth))
    TN = int(np.count_nonzero((~prediction) & (~truth)))
    FP = int(np.count_nonzero(prediction & (~truth)))
    FN = int(np.count_nonzero((~prediction) & truth))

    eps = np.finfo(float).eps

    def safe_divide(a, b):
        return float(a) / max(float(b), eps)

    precision = safe_divide(TP, TP + FP)
    recall = safe_divide(TP, TP + FN)
    specificity = safe_divide(TN, TN + FP)
    accuracy = safe_divide(TP + TN, truth.size)
    balanced_accuracy = 0.5 * (recall + specificity)
    F1 = safe_divide(2.0 * precision * recall, precision + recall)

    mcc_den = math.sqrt(
        float(TP + FP) * float(TP + FN) *
        float(TN + FP) * float(TN + FN)
    )
    if mcc_den <= 0:
        MCC = 0.0
    else:
        MCC = (
            float(TP) * float(TN) - float(FP) * float(FN)
        ) / mcc_den

    order = np.argsort(-score, kind="mergesort")
    sorted_score = score[order]
    sorted_truth = truth[order]

    positive_count = int(np.count_nonzero(sorted_truth))
    negative_count = int(np.count_nonzero(~sorted_truth))

    tp_all = np.cumsum(sorted_truth, dtype=np.int64)
    fp_all = np.cumsum(~sorted_truth, dtype=np.int64)
    tie_ends = np.r_[sorted_score[:-1] != sorted_score[1:], True]
    tp_curve = tp_all[tie_ends].astype(float)
    fp_curve = fp_all[tie_ends].astype(float)

    if positive_count > 0 and negative_count > 0:
        tpr = np.r_[0.0, tp_curve / positive_count]
        fpr = np.r_[0.0, fp_curve / negative_count]
        AUROC = float(np.trapz(tpr, fpr))
    else:
        AUROC = float("nan")

    if positive_count > 0:
        recall_curve = tp_curve / positive_count
        precision_curve = tp_curve / np.maximum(tp_curve + fp_curve, eps)
        AUPRC = float(
            np.sum(np.diff(np.r_[0.0, recall_curve]) * precision_curve)
        )
    else:
        AUPRC = float("nan")

    return {
        "Threshold": float(threshold),
        "TP": TP,
        "TN": TN,
        "FP": FP,
        "FN": FN,
        "Accuracy": accuracy,
        "BalancedAccuracy": balanced_accuracy,
        "Precision": precision,
        "Recall": recall,
        "Specificity": specificity,
        "F1": F1,
        "MCC": MCC,
        "AUROC": AUROC,
        "AUPRC": AUPRC,
        "Brier": float(np.mean((score - truth.astype(float)) ** 2)),
        "MAE": float(np.mean(np.abs(score - truth.astype(float)))),
        "N": int(truth.size),
        "Positive": positive_count,
    }


def select_threshold_gcbrb(truth, score, metric_name="MCC"):
    """
    Exact semantic port of core/select_threshold.m.
    Candidate thresholds are the unique observed scores. On exact objective
    ties (<=1e-12), choose the candidate threshold closest to 0.5.
    """
    truth = np.asarray(truth).reshape(-1).astype(bool)
    score = np.asarray(score, dtype=float).reshape(-1)
    metric_name = str(metric_name).upper()

    if truth.size != score.size:
        raise ValueError("truth and score must have the same length")
    if truth.size == 0:
        return 0.5, float("nan")
    if np.any(~np.isfinite(score)):
        raise ValueError("score contains NaN or Inf")

    order = np.argsort(-score, kind="mergesort")
    sorted_score = score[order]
    sorted_truth = truth[order]

    tp = np.cumsum(sorted_truth, dtype=np.int64)
    fp = np.cumsum(~sorted_truth, dtype=np.int64)
    P = int(np.count_nonzero(truth))
    N = int(np.count_nonzero(~truth))
    fn = P - tp
    tn = N - fp

    last_of_tie = np.r_[sorted_score[:-1] != sorted_score[1:], True]
    idx = np.flatnonzero(last_of_tie)

    tp = tp[idx].astype(float)
    fp = fp[idx].astype(float)
    fn = fn[idx].astype(float)
    tn = tn[idx].astype(float)
    candidate_thresholds = sorted_score[idx]

    eps = np.finfo(float).eps

    if metric_name == "MCC":
        denominator = np.sqrt(
            (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)
        )
        values = np.zeros_like(tp, dtype=float)
        valid = denominator > 0
        values[valid] = (
            tp[valid] * tn[valid] - fp[valid] * fn[valid]
        ) / denominator[valid]
    elif metric_name == "F1":
        precision = tp / np.maximum(tp + fp, eps)
        recall = tp / np.maximum(tp + fn, eps)
        values = 2.0 * precision * recall / np.maximum(
            precision + recall, eps
        )
    elif metric_name == "BALANCEDACCURACY":
        recall = tp / np.maximum(tp + fn, eps)
        specificity = tn / np.maximum(tn + fp, eps)
        values = 0.5 * (recall + specificity)
    else:
        raise ValueError(f"Unsupported threshold metric: {metric_name}")

    best_value = float(np.max(values))
    ties = np.flatnonzero(np.abs(values - best_value) <= 1e-12)
    closest_local = int(np.argmin(np.abs(candidate_thresholds[ties] - 0.5)))
    selected = int(ties[closest_local])
    threshold = float(candidate_thresholds[selected])

    if not np.isfinite(threshold):
        return 0.5, float("nan")
    return threshold, best_value


def audit_metric_source_files():
    out = {}
    for label, path, expected_hash in [
        ("binary_metrics.m", CORE_BINARY_METRICS, EXPECTED_BINARY_METRICS_SHA256),
        ("select_threshold.m", CORE_SELECT_THRESHOLD, EXPECTED_SELECT_THRESHOLD_SHA256),
    ]:
        if path.exists():
            actual = file_sha256(path)
            out[label] = {
                "Path": str(path),
                "SHA256": actual,
                "MatchesAudited20260919": bool(actual == expected_hash),
            }
            if actual != expected_hash:
                raise RuntimeError(
                    f"{label} hash differs from the audited 2026-09-19 file. "
                    "Do not silently proceed with a changed metric definition."
                )
        else:
            out[label] = {
                "Path": str(path),
                "SHA256": None,
                "MatchesAudited20260919": None,
                "Note": "File absent; Python port remains pinned to audited 2026-09-19 semantics.",
            }
    return out


# =============================================================================
# TRAINING / EVALUATION
# =============================================================================

def weighted_bce(logits, labels, pos_weight):
    return F.binary_cross_entropy_with_logits(
        logits,
        labels.float(),
        pos_weight=torch.tensor(
            float(pos_weight),
            dtype=logits.dtype,
            device=logits.device,
        ),
    )


@torch.no_grad()
def infer_subset(model, x, edge_index, idx, labels, pos_weight):
    model.eval()
    logits = model(x, edge_index)
    sel = torch.as_tensor(idx, dtype=torch.long, device=logits.device)
    y = torch.as_tensor(labels, dtype=torch.float32, device=logits.device)
    sub_logits = logits[sel]
    loss = float(weighted_bce(sub_logits, y, pos_weight).item())
    score = torch.sigmoid(sub_logits).detach().cpu().numpy()
    return loss, score


def train_one(
    target,
    run,
    mode,
    device,
    epochs,
    patience,
    min_epochs,
    val_every,
    manifest_root,
    fresh=False,
):
    seed = frozen_run_seed(target, run)
    set_seed(seed)

    out_dir = OUT_BASE / mode / target / f"run_{run:02d}"
    out_dir.mkdir(parents=True, exist_ok=True)
    resume_path = out_dir / "latest_training_state.pt"
    history_path = out_dir / "training_history.csv"
    completion_path = (
        out_dir / "SMOKE_STATUS_NO_TEST.json"
        if mode == "smoke"
        else out_dir / "FINAL_MONET_STATUS.json"
    )

    print("=" * 100)
    print("MONet GC-BRB same-benchmark adaptation")
    print("Paper-based reimplementation; NOT verified official-code reproduction")
    print("=" * 100)
    print(f"Target        : {target}")
    print(f"Run           : {run}")
    print(f"Model seed    : {seed}")
    print(f"Mode          : {mode}")
    print(f"Device        : {device}")
    print(f"Manifest root : {manifest_root}")

    if fresh and resume_path.exists():
        resume_path.unlink()
        print(f"\n--fresh: removed incomplete resume checkpoint: {resume_path}")

    X, global_y, presence, _ = load_prepared_alignment()

    # Full 30-run family audit: no model predictions, no Test performance.
    family_audit = audit_all_manifests(manifest_root, global_y)
    split = load_exact_target_split(manifest_root, target, run, global_y)

    metric_source_audit = audit_metric_source_files()

    protocol_lock = build_protocol_lock(
        target=target, run=run, mode=mode, seed=seed, epochs=epochs,
        patience=patience, min_epochs=min_epochs, val_every=val_every,
        split=split, metric_source_audit=metric_source_audit,
    )
    protocol_fingerprint = protocol_lock["FingerprintSHA256"]
    print(f"Protocol lock  : {PROTOCOL_VERSION}")
    print(f"Protocol SHA256: {protocol_fingerprint}")
    print("GAT backend     : sparse COO SpMM (PyG-GAT mathematically equivalent)")

    # A completed run is immutable only when its protocol fingerprint matches
    # the current locked protocol. Never silently reuse results from a changed
    # script/data/manifest/metric configuration.
    if completion_path.exists():
        with open(completion_path, "r", encoding="utf-8") as f:
            completed = json.load(f)
        completed_fp = (completed.get("ProtocolLock") or {}).get("FingerprintSHA256")
        if completed_fp != protocol_fingerprint:
            raise RuntimeError(
                "Completion marker exists but protocol fingerprint differs. "
                "Do not mix results across protocols; use the locked output directory "
                "or explicitly archive/remove the conflicting incomplete experiment."
            )
        print("\nRun completion marker already exists and protocol fingerprint matches.")
        print(f"Completed output : {completion_path}")
        if mode == "formal":
            print("Test inference    : NOT REPEATED")
        print("STATUS            : ALREADY COMPLETE")
        return completed

    edge_np, target_ltg0 = load_target_global_edge_index(target)
    target_presence = presence[:, VIEWS.index(target)]

    if not np.array_equal(
        np.sort(np.flatnonzero(target_presence)),
        np.sort(target_ltg0),
    ):
        raise RuntimeError(f"{target}: adjacency-node mapping/presence mismatch")

    presence_df = split_presence_diagnostic(split, target_presence)
    print("\nFormal supervision identity diagnostic (NO filtering):")
    print(presence_df.to_string(index=False))

    # Lock: ALL formal Train identities supervise training, whether or not the
    # gene is present in the current target PPI.
    train_idx0 = split["train"]["idx0"]
    train_labels = split["train"]["labels"]
    val_idx0 = split["validation"]["idx0"]
    val_labels = split["validation"]["labels"]

    train_pos = int(train_labels.sum())
    train_neg = int(len(train_labels) - train_pos)
    if train_pos <= 0:
        raise RuntimeError("No positive formal training labels")
    pos_weight = train_neg / train_pos
    print(f"\nFull formal Train pos_weight = neg/pos = {pos_weight:.12f}")

    x = torch.from_numpy(X).float().to(device)
    edge_index = torch.from_numpy(edge_np).long().to(device)
    train_idx = torch.as_tensor(train_idx0, dtype=torch.long, device=device)
    train_y = torch.as_tensor(
        train_labels, dtype=torch.float32, device=device
    )

    model = MONet(in_dim=64, dropout=PAPER_DROPOUT).to(device)
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=PAPER_LR,
        weight_decay=PAPER_WEIGHT_DECAY,
    )

    family_audit.to_csv(out_dir / "all_30run_manifest_audit.csv", index=False)
    presence_df.to_csv(out_dir / "ppi_presence_diagnostic_no_filtering.csv", index=False)

    best_val_loss = math.inf
    best_epoch = 0
    best_state = None
    no_improve_epochs = 0
    history = []
    last_completed_epoch = 0
    runtime_before_sec = 0.0
    training_loop_finished = False

    signature = _resume_signature(
        target, run, mode, seed, epochs, patience, min_epochs, val_every,
        protocol_fingerprint
    )

    if resume_path.exists() and not fresh:
        ckpt = _torch_load_full(resume_path)
        if ckpt.get("resume_schema_version") != RESUME_SCHEMA_VERSION:
            raise RuntimeError(
                f"Unsupported resume checkpoint schema: "
                f"{ckpt.get('resume_schema_version')}"
            )
        _validate_resume_signature(ckpt.get("signature", {}), signature)
        model.load_state_dict(ckpt["model_state"])
        optimizer.load_state_dict(ckpt["optimizer_state"])
        _optimizer_to_device(optimizer, device)
        best_val_loss = float(ckpt["best_val_loss"])
        best_epoch = int(ckpt["best_epoch"])
        best_state = ckpt["best_state"]
        no_improve_epochs = int(ckpt["no_improve_epochs"])
        history = list(ckpt["history"])
        last_completed_epoch = int(ckpt["last_completed_epoch"])
        runtime_before_sec = float(ckpt.get("runtime_seconds_completed", 0.0))
        training_loop_finished = bool(ckpt.get("training_loop_finished", False))
        _restore_rng_state(ckpt.get("rng_state"))

        print("\nRESUME checkpoint found and validated.")
        print(f"Last completed epoch : {last_completed_epoch}")
        print(f"Best epoch so far    : {best_epoch}")
        print(f"Accumulated runtime  : {runtime_before_sec:.1f} s")
        if training_loop_finished:
            print("Training loop status : FINISHED; continuing post-training finalization")
        else:
            print(f"Next epoch           : {last_completed_epoch + 1}")

    segment_t0 = time.time()

    def save_resume_state(epoch, loop_finished):
        elapsed_total = runtime_before_sec + (time.time() - segment_t0)
        payload = {
            "resume_schema_version": RESUME_SCHEMA_VERSION,
            "signature": signature,
            "last_completed_epoch": int(epoch),
            "training_loop_finished": bool(loop_finished),
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "best_val_loss": float(best_val_loss),
            "best_epoch": int(best_epoch),
            "best_state": best_state,
            "no_improve_epochs": int(no_improve_epochs),
            "history": history,
            "runtime_seconds_completed": float(elapsed_total),
            "rng_state": _capture_rng_state(),
        }
        _atomic_torch_save(payload, resume_path)
        pd.DataFrame(history).to_csv(history_path, index=False)
        return elapsed_total

    if not training_loop_finished:
        start_epoch = last_completed_epoch + 1
        try:
            for epoch in range(start_epoch, epochs + 1):
                model.train()
                optimizer.zero_grad(set_to_none=True)

                logits = model(x, edge_index)
                tr_logits = logits[train_idx]
                train_loss = weighted_bce(tr_logits, train_y, pos_weight)
                train_loss.backward()
                optimizer.step()

                rec = {
                    "Epoch": epoch,
                    "TrainLoss": float(train_loss.item()),
                }
                stop_now = False

                do_val = (epoch == 1) or (epoch % val_every == 0) or (epoch == epochs)
                if do_val:
                    try:
                        val_loss, val_score = infer_subset(
                            model,
                            x,
                            edge_index,
                            val_idx0,
                            val_labels,
                            pos_weight,
                        )
                    except torch.cuda.OutOfMemoryError as e:
                        raise RuntimeError(
                            "CUDA OOM during full-batch MONet validation. "
                            "Do not silently change architecture, sampling, node "
                            "population, or graph semantics."
                        ) from e

                    val_rank_metrics = binary_metrics_gcbrb(
                        val_labels, val_score, threshold=0.5
                    )
                    rec.update({
                        "ValLoss": val_loss,
                        "ValAUPRC": val_rank_metrics["AUPRC"],
                        "ValAUROC": val_rank_metrics["AUROC"],
                    })

                    elapsed_sec = runtime_before_sec + (time.time() - segment_t0)
                    print(
                        f"Epoch {epoch:04d}/{epochs} | "
                        f"train={train_loss.item():.6f} | "
                        f"val_loss={val_loss:.6f} | "
                        f"val_AP={val_rank_metrics['AUPRC']:.6f} | "
                        f"val_AUROC={val_rank_metrics['AUROC']:.6f} | "
                        f"elapsed={elapsed_sec:.1f} s"
                    )

                    if val_loss < best_val_loss - 1e-8:
                        best_val_loss = val_loss
                        best_epoch = epoch
                        best_state = copy.deepcopy(model.state_dict())
                        no_improve_epochs = 0
                    else:
                        no_improve_epochs += val_every

                    if epoch >= min_epochs and no_improve_epochs >= patience:
                        print(
                            f"Early stop: no validation-loss improvement for "
                            f">= {patience} epochs."
                        )
                        stop_now = True

                history.append(rec)
                last_completed_epoch = epoch
                training_loop_finished = bool(stop_now or epoch == epochs)
                save_resume_state(epoch, training_loop_finished)

                if stop_now:
                    break

        except KeyboardInterrupt:
            # The previous fully completed epoch was already saved atomically.
            print("\nTRAINING INTERRUPTED BY USER")
            print(f"Last safely saved epoch : {last_completed_epoch}")
            print(f"Resume checkpoint       : {resume_path}")
            print("Re-run the identical command to continue automatically.")
            return {
                "Status": "INTERRUPTED",
                "LastCompletedEpoch": int(last_completed_epoch),
                "ResumeCheckpoint": str(resume_path),
            }

    # If a resume checkpoint says the training loop is complete, its saved
    # runtime is authoritative. Otherwise include this process segment.
    if resume_path.exists():
        final_ckpt = _torch_load_full(resume_path)
        runtime_sec = float(final_ckpt.get("runtime_seconds_completed", 0.0))
        # Ensure in-memory values are exactly the crash-safe saved values.
        best_val_loss = float(final_ckpt["best_val_loss"])
        best_epoch = int(final_ckpt["best_epoch"])
        best_state = final_ckpt["best_state"]
        history = list(final_ckpt["history"])
    else:
        runtime_sec = runtime_before_sec + (time.time() - segment_t0)

    pd.DataFrame(history).to_csv(history_path, index=False)

    if best_state is None:
        raise RuntimeError("No validation checkpoint was selected")

    model.load_state_dict(best_state)
    best_model_path = out_dir / "best_model.pt"
    _atomic_torch_save(best_state, best_model_path)
    best_model_sha256 = file_sha256(best_model_path)

    # Validation-only threshold selection after checkpoint freeze.
    val_loss, val_score = infer_subset(
        model,
        x,
        edge_index,
        val_idx0,
        val_labels,
        pos_weight,
    )
    threshold, threshold_objective = select_threshold_gcbrb(
        val_labels, val_score, metric_name="MCC"
    )
    val_metrics = binary_metrics_gcbrb(
        val_labels, val_score, threshold=threshold
    )

    val_pred_df = pd.DataFrame({
        "GlobalIndex_1based": val_idx0 + 1,
        "Label": val_labels,
        "MONetProbability": val_score,
        "SelectedValidationMCCThreshold": threshold,
        "Target": target,
        "Run": run,
        "ModelSeed": seed,
    })
    val_pred_df.to_csv(
        out_dir / "validation_predictions.csv", index=False
    )

    common_result = {
        "Status": "PASS",
        "Method": "MONet paper-based same-benchmark adaptation",
        "OfficialCodeReproduction": False,
        "Target": target,
        "Run": int(run),
        "ModelSeed": int(seed),
        "Mode": mode,
        "Device": str(device),
        "ProtocolLock": protocol_lock,
        "BestModelSHA256": best_model_sha256,
        "Resume": {
            "Enabled": True,
            "Checkpoint": str(resume_path),
            "SaveFrequency": "every completed epoch",
            "RestoresRNGState": True,
            "CompletedRunsSkipped": True,
        },
        "SplitProtocol": {
            "Source": "audited exact manifests; no random split generation",
            "ModelRandomSeedAnchor": "exact split.seed from paired frozen GC-BRB model; used only for MONet stochasticity",
            "TestFixedAcrossFiveRunsPerTarget": True,
            "TrainValidationDifferentAcrossRuns": True,
            "FullLabeledUniverseN": N_LABELLED,
        },
        "PopulationPolicy": (
            "global 22659 nodes; current-target PPI edges; all formal "
            "Train/Validation/Test supervision identities retained; "
            "target-PPI-absent nodes retain 64-D features and model self-loops"
        ),
        "Architecture": {
            "Input": 64,
            "GCN": [300, 100, 16],
            "GAT": {
                "HiddenPerHead": 100,
                "HiddenHeads": 5,
                "Output": 16,
                "OutputHeads": 1,
            },
            "GraphEnhanced": 32,
            "MLP": [16, 1],
        },
        "Optimization": {
            "AdamLR": PAPER_LR,
            "WeightDecay": PAPER_WEIGHT_DECAY,
            "Dropout": PAPER_DROPOUT,
            "EpochBudget": int(epochs),
            "EarlyStopMetric": "weighted validation BCE loss",
            "Patience": int(patience),
            "MinEpochs": int(min_epochs),
            "ValidationEvery": int(val_every),
            "TrainPosWeight": float(pos_weight),
            "TrainPosWeightPopulation": "full formal training split",
        },
        "Thresholding": {
            "SelectionPopulation": "Validation only",
            "Metric": "MCC",
            "SelectedThreshold": float(threshold),
            "BestValidationThresholdMetric": float(threshold_objective),
            "TieBreak": "candidate threshold closest to 0.5",
        },
        "Graph": {
            "GlobalNodes": N_GLOBAL,
            "TargetPPIPresentNodes": int(target_presence.sum()),
            "TargetPPIAbsentNodes": int((~target_presence).sum()),
            "DirectedPPIEdgesBeforeModelSelfLoops": int(edge_np.shape[1]),
            "StoredPPIAdjacencyBinary": True,
            "StoredPPIAdjacencyHasSelfLoops": False,
            "PyGModelSelfLoops": True,
        },
        "BestEpoch": int(best_epoch),
        "BestValidationLoss": float(best_val_loss),
        "Validation": {
            **val_metrics,
            "Loss": float(val_loss),
        },
        "TestEvaluated": False,
        "RuntimeSeconds": float(runtime_sec),
        "InputFiles": {
            "PreparedMAT": str(PREPARED_MAT),
            "PreparedMATSHA256": file_sha256(PREPARED_MAT),
            "ManifestRoot": str(manifest_root),
            "TrainManifest": str(split["train"]["path"]),
            "TrainManifestSHA256": file_sha256(split["train"]["path"]),
            "ValidationManifest": str(split["validation"]["path"]),
            "ValidationManifestSHA256": file_sha256(split["validation"]["path"]),
            "TestManifest": str(split["test"]["path"]),
            "TestManifestSHA256": file_sha256(split["test"]["path"]),
            "GC_BRBMetricSources": metric_source_audit,
        },
    }

    if mode == "smoke":
        # CRITICAL: no Test inference, no Test model score, no Test metric.
        with open(
            out_dir / "SMOKE_STATUS_NO_TEST.json",
            "w",
            encoding="utf-8",
        ) as f:
            json.dump(
                common_result, f, indent=2, ensure_ascii=False, default=json_safe
            )

        pd.DataFrame([{
            "Target": target,
            "Run": run,
            "Seed": seed,
            "Mode": mode,
            "BestEpoch": best_epoch,
            "ValidationThreshold": threshold,
            "ValidationAUPRC": val_metrics["AUPRC"],
            "ValidationAUROC": val_metrics["AUROC"],
            "ValidationMCC": val_metrics["MCC"],
            "ValidationF1": val_metrics["F1"],
            "TestEvaluated": False,
            "RuntimeSeconds": runtime_sec,
            "Status": "PASS",
        }]).to_csv(out_dir / "smoke_summary_no_test.csv", index=False)

        print("\n" + "=" * 100)
        print("CPDB/SELECTED RUN SMOKE RESULT — TEST NOT EVALUATED")
        print("=" * 100)
        print(f"Best epoch              : {best_epoch}")
        print(f"Validation threshold    : {threshold:.12f} (MCC-selected)")
        print(f"Validation AUPRC        : {val_metrics['AUPRC']:.6f}")
        print(f"Validation AUROC        : {val_metrics['AUROC']:.6f}")
        print(f"Validation MCC          : {val_metrics['MCC']:.6f}")
        print(f"Training runtime        : {runtime_sec:.1f} s")
        print("Test inference          : NOT RUN")
        print("Test performance output : NONE")
        print(f"Output                  : {out_dir}")
        print("STATUS                  : PASS")
        print("=" * 100)
        return common_result

    # Formal mode only: checkpoint and threshold are now frozen.
    test_idx0 = split["test"]["idx0"]
    test_labels = split["test"]["labels"]

    # Crash-safe Test cache: if final reporting is interrupted after Test
    # inference, an identical restart reuses the frozen scores rather than
    # intentionally performing another Test forward pass.
    test_cache = out_dir / "test_evaluation_cache.npz"
    if test_cache.exists():
        z = np.load(test_cache, allow_pickle=False)
        cached_idx = z["global_idx0"].astype(np.int64)
        cached_labels = z["labels"].astype(np.int64)
        cached_threshold = float(z["threshold"])
        cached_best_epoch = int(z["best_epoch"])
        cached_protocol_fingerprint = str(z["protocol_fingerprint"].item())
        cached_best_model_sha256 = str(z["best_model_sha256"].item())
        if (
            not np.array_equal(cached_idx, test_idx0)
            or not np.array_equal(cached_labels, test_labels)
            or not np.isclose(cached_threshold, threshold, atol=1e-12, rtol=0.0)
            or cached_best_epoch != best_epoch
            or cached_protocol_fingerprint != protocol_fingerprint
            or cached_best_model_sha256 != best_model_sha256
        ):
            raise RuntimeError(
                "Existing Test cache does not match the frozen split/checkpoint/threshold. "
                "Do not overwrite it silently."
            )
        test_loss = float(z["test_loss"])
        test_score = z["test_score"].astype(float)
        print("\nTest evaluation cache found: reusing frozen Test scores; inference NOT repeated.")
    else:
        test_loss, test_score = infer_subset(
            model,
            x,
            edge_index,
            test_idx0,
            test_labels,
            pos_weight,
        )
        tmp_cache = out_dir / "test_evaluation_cache.tmp.npz"
        np.savez_compressed(
            tmp_cache,
            global_idx0=test_idx0.astype(np.int64),
            labels=test_labels.astype(np.int64),
            threshold=np.asarray(threshold, dtype=float),
            best_epoch=np.asarray(best_epoch, dtype=np.int64),
            protocol_fingerprint=np.asarray(protocol_fingerprint),
            best_model_sha256=np.asarray(best_model_sha256),
            test_loss=np.asarray(test_loss, dtype=float),
            test_score=np.asarray(test_score, dtype=float),
        )
        os.replace(tmp_cache, test_cache)

    test_metrics = binary_metrics_gcbrb(
        test_labels, test_score, threshold=threshold
    )

    test_pred_df = pd.DataFrame({
        "GlobalIndex_1based": test_idx0 + 1,
        "Label": test_labels,
        "MONetProbability": test_score,
        "FrozenValidationMCCThreshold": threshold,
        "Target": target,
        "Run": run,
        "ModelSeed": seed,
        "Population": "full_formal_test_all_supervision_identities",
    })
    test_pred_df.to_csv(
        out_dir / "test_predictions_full_formal.csv", index=False
    )

    result = dict(common_result)
    result["TestEvaluated"] = True
    result["Test"] = {
        **test_metrics,
        "Loss": float(test_loss),
    }

    with open(
        out_dir / "FINAL_MONET_STATUS.json",
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            result, f, indent=2, ensure_ascii=False, default=json_safe
        )

    summary = pd.DataFrame([{
        "Target": target,
        "Run": run,
        "Seed": seed,
        "Mode": mode,
        "BestEpoch": best_epoch,
        "ValidationThreshold": threshold,
        "ValidationAUPRC": val_metrics["AUPRC"],
        "ValidationAUROC": val_metrics["AUROC"],
        "ValidationMCC": val_metrics["MCC"],
        "ValidationF1": val_metrics["F1"],
        "TestN": test_metrics["N"],
        "TestPositive": test_metrics["Positive"],
        "TestAUPRC": test_metrics["AUPRC"],
        "TestAUROC": test_metrics["AUROC"],
        "TestMCC": test_metrics["MCC"],
        "TestF1": test_metrics["F1"],
        "TestAccuracy": test_metrics["Accuracy"],
        "TestBalancedAccuracy": test_metrics["BalancedAccuracy"],
        "RuntimeSeconds": runtime_sec,
        "Status": "PASS",
    }])
    summary.to_csv(out_dir / "run_summary.csv", index=False)

    print("\n" + "=" * 100)
    print("FROZEN CHECKPOINT + VALIDATION-THRESHOLD TEST RESULT — FULL FORMAL POPULATION")
    print("=" * 100)
    print(f"Best epoch       : {best_epoch}")
    print(f"Frozen threshold : {threshold:.12f} (Validation MCC)")
    print(f"Test N / Pos     : {test_metrics['N']} / {test_metrics['Positive']}")
    print(f"Test AUPRC       : {test_metrics['AUPRC']:.6f}")
    print(f"Test AUROC       : {test_metrics['AUROC']:.6f}")
    print(f"Test MCC         : {test_metrics['MCC']:.6f}")
    print(f"Test F1          : {test_metrics['F1']:.6f}")
    print(f"Training runtime : {runtime_sec:.1f} s")
    print(f"Output           : {out_dir}")
    print("STATUS           : PASS")
    print("=" * 100)
    return result

# =============================================================================
# CLI
# =============================================================================

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--target", default="CPDB", choices=VIEWS)
    p.add_argument("--run", type=int, default=1, choices=[1, 2, 3, 4, 5])
    p.add_argument("--mode", choices=["smoke", "formal"], default="smoke")
    p.add_argument("--gpu", type=int, default=0)
    p.add_argument(
        "--verify-gat-only",
        action="store_true",
        help="Run the PyG-vs-memory-safe GAT forward/backward equivalence guard and exit.",
    )
    p.add_argument("--epochs", type=int, default=None)
    p.add_argument("--patience", type=int, default=DEFAULT_PATIENCE)
    p.add_argument("--min-epochs", type=int, default=DEFAULT_MIN_EPOCHS)
    p.add_argument("--val-every", type=int, default=1, help="FINAL-LOCKED protocol requires 1; any other value is rejected.")
    p.add_argument(
        "--fresh",
        action="store_true",
        help=(
            "Discard an INCOMPLETE latest_training_state.pt and restart that "
            "unfinished run from epoch 1. Completed runs are still protected."
        ),
    )
    p.add_argument(
        "--manifest-root",
        default=None,
        help=(
            "Directory containing <TARGET>/run_XX/"
            "{train,validation,test}_identity.csv. "
            "If omitted, audited project defaults are searched."
        ),
    )
    return p.parse_args()


def main():
    args = parse_args()

    # This execution-backend patch is intentionally PCNET-only. The other 25
    # FINAL-LOCKED runs remain immutable and must not be regenerated with a
    # different script hash merely because PCNET exceeded 8 GiB VRAM.
    if args.target != "PCNET" and not args.verify_gat_only:
        raise ValueError(
            "This memory-safe FINAL patch is PCNET-only. Keep the 25 completed "
            "non-PCNET v4 runs unchanged."
        )

    # Mandatory semantic guard before any PCNET training/inference.
    verify_sparse_gat_equivalence(device="cpu")
    if args.verify_gat_only:
        return

    manifest_root = resolve_manifest_root(args.manifest_root)

    if torch.cuda.is_available():
        device = torch.device(f"cuda:{args.gpu}")
    else:
        device = torch.device("cpu")

    if args.epochs is not None:
        epochs = int(args.epochs)
    else:
        epochs = 5 if args.mode == "smoke" else PAPER_EPOCHS

    if epochs < 1:
        raise ValueError("epochs must be >= 1")

    if int(args.val_every) != 1:
        raise ValueError(
            "FINAL-LOCKED protocol requires --val-every 1 so every epoch is eligible "
            "for Validation-loss checkpoint selection."
        )
    val_every = 1
    min_epochs = min(max(1, int(args.min_epochs)), epochs)
    patience = max(1, int(args.patience))

    try:
        train_one(
            target=args.target,
            run=args.run,
            mode=args.mode,
            device=device,
            epochs=epochs,
            patience=patience,
            min_epochs=min_epochs,
            val_every=val_every,
            manifest_root=manifest_root,
            fresh=bool(args.fresh),
        )
    except torch.cuda.OutOfMemoryError as e:
        print("\nCUDA OOM. Even the memory-safe mathematically equivalent PCNET backend did not fit on this GPU.")
        print(
            "Do NOT silently change architecture, sampling, global-node "
            "population, or graph semantics and still call it the same run."
        )
        raise e


if __name__ == "__main__":
    main()
